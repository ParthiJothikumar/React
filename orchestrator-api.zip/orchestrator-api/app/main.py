####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Builds the FastAPI `app` object gunicorn serves, and owns everything process-lifecycle.          #
#   1. lifespan(): check the config, warm the Foundry client, start/stop the job reaper.           #
#   2. CORS, with credentials dropped rather than shipping the invalid "*" + credentials pair.     #
#   3. /health -- OUTSIDE the API prefix, and deliberately touching no database and no agent.      #
#   4. The ONE place a domain error becomes an HTTP status code.                                   #
#   5. Mount every route under Settings.API_PREFIX.                                                #
#                                                                                                  #
# Source:-                                                                                         #
#   - asyncio + contextlib.asynccontextmanager implement the lifespan and the reaper task.         #
#   - fastapi / CORSMiddleware / JSONResponse build the app, its CORS policy and error bodies.     #
#   - app.api.routes.router is the aggregated router; app.core supplies settings and the logger.   #
#   - app.deps owns the construction of foundry_client and log_factory; this module owns only      #
#       their LIFECYCLE. app.workers.reaper is the background sweep the lifespan starts.           #
####################################################################################################
"""FastAPI application: lifespan, CORS, routing and domain-error mapping.

What this module is:
    - Exposes `app`, which is what gunicorn serves:

        gunicorn app.main:app --worker-class uvicorn.workers.UvicornWorker   (see startup.sh)

Why this exists:
    - This module only wires things together -- configuration lives in core/config.py,
      endpoints in api/routes/, business logic in services/ and domain/.
    - THE LIFESPAN ACTUALLY RUNS NOW. Under Azure Functions it never did (the ASGI app was
      mounted per invocation), which is why the Foundry client is built lazily on first use
      and why the job reaper had to be a platform timer. On App Service we get real startup
      and shutdown hooks, so the reaper is a task owned by this app -- started here,
      cancelled here. The lazy Foundry build stays: it is still the right behaviour,
      because a transient Entra outage should fail one request rather than prevent the app
      from starting at all.

Security and production notes:
    1. The reaper needs ALWAYS ON to keep running -- see workers/reaper.py. Without it the
       app idles out, no sweeps run, and an abandoned job stays RUNNING forever.
    2. The error handlers are the ONE place a domain error becomes a status code. The
       author-written details of NotFound/ConversationEnded are returned as-is;
       DatabaseUnavailable/UpstreamUnavailable carry internal causes, so those are logged
       and replaced with a generic line.
    3. Credentials require explicit CORS origins (never "*"), so if CORS_ORIGINS is ever
       set to "*" this drops credentials rather than shipping an invalid, insecure pair.
"""

# ============================================ Imports =============================================
import asyncio  # create_task/gather for the reaper's lifecycle                                      # stdlib asyncio
from contextlib import asynccontextmanager  # Turns lifespan() into FastAPI's lifespan hook          # stdlib ctx

from fastapi import FastAPI, Request  # The app object, and the Request each handler gets            # fastapi
from fastapi.middleware.cors import CORSMiddleware  # Browser origin policy                          # fastapi
from fastapi.responses import JSONResponse  # The error bodies the handlers return                   # fastapi

from app.api.routes import router  # Every endpoint, aggregated into one router                      # api
from app.core.config import logger, settings  # The shared logger and parsed configuration           # config
from app.core.errors import (  # The domain errors this module maps to status codes                  # errors
    AppError,  # Catch-all: an unmapped subclass still gets a NAMED log line                         # -> 500
    ConversationEnded,  # The conversation is terminal; a new one must be started                    # -> 409
    DatabaseUnavailable,  # The state store is unreachable or not configured                         # -> 503
    NotFound,  # No such session/conversation for this user                                          # -> 404
    UpstreamUnavailable,  # An agent failed or cannot answer at all                                  # -> 502
)
# The process-wide Foundry client and log factory, so the lifespan can warm/release them.
# deps.py owns their construction; this module only owns their lifecycle.
from app.deps import foundry_client, log_factory  # Constructed in deps; LIFECYCLE owned here        # singletons
from app.workers import reaper  # The background sweep the lifespan starts and cancels               # workers


# ============================================ Lifespan ============================================
@asynccontextmanager  # FastAPI awaits up to `yield` before serving, and past it on shutdown
async def lifespan(app: FastAPI):
    """Everything that happens once at startup, and once at shutdown.

    What this does:
            startup   check the config, build the Foundry client, start the job reaper
            shutdown  cancel the reaper, close the Foundry client, close the log factory

    Why it exists:
        - The config check runs here rather than at import so it is logged once per worker
          process at a point that appears in the log stream, instead of during module import
          where the platform may swallow it.

    Security and production notes:
        1. ORDER MATTERS ON THE WAY OUT: the reaper is stopped BEFORE the Foundry client is
           closed, because a sweep calls agents that use that client. Closing first would
           leave a sweep talking to a dead transport. The log factory closes LAST for the
           same reason in reverse -- everything above it may log on its way down.
        2. foundry_client.warm() never raises, so a Foundry outage delays the first agent
           call instead of preventing the app from starting -- which would make the platform
           restart it, hit the same failure, and take /health down with it.

    Args:
        app: The FastAPI application; unused, but required by the lifespan protocol.

    Yields:
        Control to FastAPI for the whole serving period.
    """
    settings.warn_on_risky_config()  # Once per worker, into the log stream where it is seen         # config check

    # Blocking, and deliberately so: uvicorn accepts no connection until this coroutine
    # reaches `yield`, so there is no request and no event-loop work to hold up. It never
    # raises -- see FoundryClient.warm -- so a Foundry outage delays the first agent call
    # instead of preventing the app from starting.
    foundry_client.warm()  # Pay the Entra handshake now, not on a user's first turn                 # warm client

    reaper_task = None  # Stays None when the reaper is disabled, which the teardown checks          # task handle
    if settings.REAPER_ENABLED:  # Off only for a local run; warn_on_risky_config complains          # reaper on?
        # create_task, not await: run_forever() never returns, so awaiting it here would
        # mean the app never finishes starting. The handle is kept for cancel() below --
        # a task nothing references can also be garbage-collected mid-run.
        reaper_task = asyncio.create_task(  # Fire-and-hold: never awaited here                      # start reaper
            reaper.run_forever(settings.REAPER_INTERVAL_SECONDS), name="job-reaper"
        )
        logger.info(  # Names the Always On dependency, so a silent reaper is explainable            # log info
            "job reaper started: sweeping every %ss (needs Always On to keep running)",
            settings.REAPER_INTERVAL_SECONDS,
        )
    try:  # Everything between here and the finally is the app's serving lifetime                    # serve
        yield  # FastAPI serves requests for as long as this is suspended                            # serving
    finally:  # Shutdown, in the REVERSE order of construction                                       # teardown
        if reaper_task is not None:  # Only if we actually started one                               # started?
            reaper_task.cancel()  # Ask the sweep loop to stop at its next await                     # cancel
            # return_exceptions so the expected CancelledError does not surface as an
            # error during a normal shutdown. This waits for the CANCELLATION, not for
            # any thread the task handed work to -- a thread cannot be cancelled, so an
            # in-flight sweep finishes on its own. That is safe: every write is inside a
            # transaction, and claiming a job is a compare-and-swap.
            await asyncio.gather(reaper_task, return_exceptions=True)  # Await the cancellation      # wait
            logger.info("job reaper stopped")  # Confirms a clean shutdown in the log                # log info
        foundry_client.close()  # AFTER the reaper: a sweep uses this client                         # close client
        # Last: releases the Event Hub producer and its credential. A no-op when Event Hub
        # forwarding is off, which is the default.
        log_factory.close()  # LAST: everything above may log on its way down                        # close logs


# ========================================== Application ===========================================
app = FastAPI(title="IT Support Orchestrator API", lifespan=lifespan)  # What gunicorn serves        # app

# ========================================== CORS policy ===========================================
# Credentials require explicit origins (never "*") per browser rules and Snyk; if
# CORS_ORIGINS is ever set to "*", drop credentials rather than ship the invalid,
# insecure "*" + credentials combination.
_allow_credentials = "*" not in settings.CORS_ORIGINS  # False the moment a wildcard appears         # creds ok?
if not _allow_credentials:  # Make the downgrade visible rather than silent                          # wildcard?
    logger.warning("CORS_ORIGINS contains '*'; disabling allow_credentials")  # Log it               # log warn

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,  # Explicit origins from configuration                      # origins
    allow_credentials=_allow_credentials,  # Dropped rather than paired with a wildcard              # credentials
    allow_methods=["GET", "POST"],  # The only two verbs this API exposes                            # methods
    allow_headers=["*"],  # Request headers only; harmless without a wildcard origin                 # headers
)


# ========================================== Health probe ==========================================
@app.get("/health", include_in_schema=False)
def health():
    """Liveness probe, for the App Service health check and any load balancer.

    What this endpoint does:
        - Returns a fixed {"status": "ok"} and touches nothing else.

    Why it exists:
        - Deliberately OUTSIDE the API prefix, so the probe path does not move if
          API_PREFIX changes.

    Security and production notes:
        1. Deliberately does NOT touch the database or any agent. A probe runs every few
           seconds from every instance: if it opened a SQL connection it would consume pool
           capacity that real requests need, and a brief SQL blip would make the platform
           recycle healthy instances -- turning a small outage into a large one. This
           answers "is this process serving?", which is the question the platform is asking.
        2. include_in_schema=False keeps it out of /docs: it is a platform contract, not
           part of the public API.

    Returns:
        {"status": "ok"}.
    """
    return {"status": "ok"}  # Fixed body; no state is read at all                                   # ok


# ---------------------------------------------------------------------------
# Domain error -> HTTP status. The ONE place that translation happens, so the
# layers below (services/, domain/, db/, agents/) can raise the framework-free
# errors in core/errors.py and stay callable without a web server.
#
# The detail text of NotFound/ConversationEnded is author-written and safe to
# show; DatabaseUnavailable/UpstreamUnavailable carry internal causes, so those
# are logged and replaced with a generic line.
#
# A handler only fires if nothing caught the exception on the way up -- the
# controllers in api/routes/ deliberately re-raise NotFound/ConversationEnded so
# they reach here, and swallow everything else into a user-facing fallback.
#
# Starlette matches the CLOSEST registered class, walking up the hierarchy. So the
# four specific handlers below win over the AppError catch-all at the end.
# ---------------------------------------------------------------------------
@app.exception_handler(NotFound)
async def _handle_not_found(request: Request, exc: NotFound):
    """No such session/conversation for this user -> 404, with the author-written text."""
    return JSONResponse(status_code=404, content={"detail": str(exc)})  # Safe to return as-is       # 404


@app.exception_handler(ConversationEnded)
async def _handle_conversation_ended(request: Request, exc: ConversationEnded):
    """The conversation is terminal -> 409, with the author-written text.

    NOTE: the chat controllers answer this with a 200 payload instead (see
    api/responses.ended_chat_response), so in practice this fires only for a caller that
    reaches the flow by some other route.
    """
    return JSONResponse(status_code=409, content={"detail": str(exc)})  # Safe to return as-is       # 409


@app.exception_handler(UpstreamUnavailable)
async def _handle_upstream_unavailable(request: Request, exc: UpstreamUnavailable):
    """An agent failed or cannot answer -> 502, with a GENERIC body.

    The cause is logged, not returned: an SDK message can name endpoints and headers.
    """
    logger.error("upstream unavailable path=%s: %s", request.url.path, exc)  # Detail for us         # log error
    return JSONResponse(status_code=502, content={"detail": "Agent call failed"})  # Generic         # 502


@app.exception_handler(DatabaseUnavailable)
async def _handle_database_unavailable(request: Request, exc: DatabaseUnavailable):
    """The state store is unreachable -> 503, with a GENERIC body.

    The cause is logged, not returned: it routinely contains driver text and can contain
    the connection string.
    """
    logger.error("database unavailable path=%s: %s", request.url.path, exc)  # Detail for us         # log error
    return JSONResponse(status_code=503, content={"detail": "Database unavailable"})  # Generic      # 503


@app.exception_handler(AppError)
async def _handle_unmapped_domain_error(request: Request, exc: AppError):
    """Last resort: a domain error with no handler of its own.

    What this handler does:
        - Logs the exception's TYPE and path, then returns a generic 500.

    Why it exists:
        - The four handlers above take priority, so reaching here means a subclass was
          added to core/errors.py and never mapped. The status stays 500 because we
          genuinely don't know what an unmapped error means -- inventing a 4xx would be
          worse. The value is the log line: it names the type, instead of leaving an
          anonymous 500 to be guessed at.

    Security and production notes:
        1. Reaching this handler in production IS the signal that a new subclass needs its
           own mapping added above.
    """
    logger.error(  # Names the type, so the missing mapping is discoverable                          # log error
        "unmapped domain error %s on %s: %s",
        type(exc).__name__, request.url.path, exc,
    )
    return JSONResponse(status_code=500, content={"detail": "Internal error"})  # Generic            # 500


# ========================================= Route mounting =========================================
# Every route lives under the prefix (default /api), so the endpoints are /api/chat,
# /api/jobs/status and so on. The frontend's VITE_API_URL must include it. /health above
# is outside it on purpose, so a platform probe survives a prefix change.
app.include_router(router, prefix=settings.API_PREFIX)  # The one place the prefix is applied        # mount
