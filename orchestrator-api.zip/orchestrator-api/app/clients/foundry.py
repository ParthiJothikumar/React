####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Owns the Azure AI Foundry client for this worker process, with a real lifecycle.                 #
#   1. Build the AIProjectClient ONCE per process, lazily and thread-safely.                       #
#   2. warm() at startup and close() at shutdown, both driven by the lifespan in main.py.          #
#   3. Bound every Foundry request with an explicit timeout and retry count.                       #
#   4. Translate every SDK failure into the domain error UpstreamUnavailable.                      #
#                                                                                                  #
# Source:-                                                                                         #
#   - threading.Lock serialises the first concurrent builders on a cold start.                     #
#   - azure.ai.projects.AIProjectClient and azure.identity.DefaultAzureCredential are imported     #
#       LAZILY inside _ensure(), so importing this module does not require the Azure SDKs.         #
#   - app.core.config.logger records the build / warm-up / close outcomes.                         #
#   - app.core.errors.UpstreamUnavailable is what every SDK exception is re-raised as.             #
####################################################################################################
"""Azure AI Foundry client -- one per worker process, with a real lifecycle.

What this module is:
    - FoundryClient, whose three public members are the whole lifecycle:

        warm()   build it at startup      (main.py lifespan, before serving)
        openai   use it                   (services and agents)
        close()  release it at shutdown   (main.py lifespan, after serving)

Why this exists:
    - WHY IT IS STILL LAZY UNDERNEATH. warm() is an optimisation, not the contract:
      `openai` builds the client on first use if nothing warmed it. That matters because a
      brief Entra outage at boot must not stop the app from starting -- if it did, the
      platform would restart the app, hit the same failure, and take /health down with it.
      So a failed warm-up is logged and the next request tries again.
    - This replaced a module-level `state` dict plus a `_state_ready` flag and a `global`
      statement -- an object written without a class, where two threads could enter at once
      and a failed init left the flag set.

Security and production notes:
    1. It has to be thread-safe: 40 request threads share this object, so without the Lock
       several of them could each build a client on a cold start. `_openai_client` is
       assigned LAST, so a failed build leaves the object un-initialised and is retried
       rather than cached half-built.
    2. Authentication is DefaultAzureCredential, so production uses the App Service managed
       identity and no secret sits in configuration. That identity needs the Foundry
       DATA-PLANE role; Owner/Contributor on the resource is not enough.
    3. Timeout and retries are both set explicitly. The worst case for one call is
       timeout x (1 + max_retries), and the SDK defaults to 2 retries -- which would
       silently triple the ceiling if it were left unset.
"""

# ============================================ Imports =============================================
import threading  # Lock that serialises the first concurrent builders on a cold start               # stdlib threading

from app.core.config import logger  # Shared logger for build / warm / close outcomes                # config
from app.core.errors import UpstreamUnavailable  # Domain error every SDK failure becomes            # errors


# ========================================= Foundry client =========================================
class FoundryClient:
    """Lazily builds and caches the AIProjectClient for this worker process.

    What this class is:
        - A holder for two SDK objects: the AIProjectClient and the OpenAI-compatible
          client obtained from it. Both are built on first use, under a lock, and released
          together by close().

    Why it exists:
        - The credential handshake is expensive, so it must happen once per process rather
          than per request -- but it must also be allowed to FAIL at startup without
          preventing the app from serving /health.

    Security and production notes:
        1. Constructing this object costs nothing and touches no network, which is what
           lets deps.py create it at import time before any configuration is validated.
        2. `_openai_client` doubles as the "already built?" flag and is assigned last, so a
           half-built client is never cached and never handed to a caller.

    Example:
        >>> client = FoundryClient("https://proj.services.ai.azure.com", 20, 1)  # doctest: +SKIP
        >>> client.warm()  # doctest: +SKIP
    """

    def __init__(self, endpoint: str, timeout: int = 20, max_retries: int = 1) -> None:
        """Record the endpoint and request bounds; build nothing.

        What this method does:
            - Stores the endpoint, per-request timeout and retry count, then initialises
              both client slots to None and creates the build lock.

        Why it exists:
            - Nothing is built here, so CONSTRUCTING this object costs nothing and touches
              no network. That is what lets deps.py create it at import time.

        Security and production notes:
            1. `_openai_client` MUST start as None: _ensure() reads it as its "have I built
               this already?" check.
            2. `_project_client` is held for two reasons: it keeps the client that produced
               the OpenAI client alive for the life of the process, and close() needs it to
               release the connection pool.

        Args:
            endpoint: The Azure AI Foundry project data-plane endpoint.
            timeout: Seconds allowed for ONE request; see Settings.FOUNDRY_HTTP_TIMEOUT.
            max_retries: SDK retry count, set explicitly so the worst case is visible.

        Returns:
            None.
        """
        self._endpoint = endpoint  # Foundry project data-plane endpoint from Settings               # endpoint
        # Bounds ONE request; see Settings.FOUNDRY_HTTP_TIMEOUT for the worst-case math.
        self._timeout = timeout  # Per-request ceiling, in seconds                                   # timeout
        self._max_retries = max_retries  # Explicit, because the SDK default of 2 triples it         # retries
        self._project_client = None  # Kept alive for the process; close() releases its pool         # project
        self._openai_client = None  # ALSO the "already built?" flag -- must start as None           # openai
        self._lock = threading.Lock()  # Serialises the first builders on a cold start               # build lock

    # ============================================ Public API ======================================
    @property
    def openai(self):
        """The OpenAI-compatible client, building it on first use."""
        self._ensure()  # No-op once built; builds under the lock on a cold start                    # ensure built
        return self._openai_client  # Shared across every request thread in this process             # return client

    def warm(self) -> None:
        """Build the client NOW, so the first real request doesn't pay for it.

        What this method does:
            - Calls _ensure() inside a try/except and logs a warning if it fails.

        Why it exists:
            - Called once at startup from the lifespan. NEVER RAISES: a warm-up failure is
              logged and left to the lazy path, because the app must be able to start while
              Azure is briefly unreachable -- see the module docstring.

        Security and production notes:
            1. Blocking (it performs the Entra handshake), which is fine where it is
               called: the lifespan runs before uvicorn accepts any connection, so there is
               no request and no event-loop work to hold up.
            2. The log line names the exception TYPE, so an auth failure is distinguishable
               from a network failure without exposing a full traceback at WARNING.

        Returns:
            None.

        Example:
            >>> FoundryClient("").warm()  # doctest: +SKIP
        """
        try:  # Build eagerly, but never let a failure escape                                        # warm try
            self._ensure()  # Performs the credential handshake and builds both clients              # build now
        except Exception as exc:  # Entra blip, bad endpoint, missing role -- all tolerated          # warm failed
            logger.warning(  # The lazy path on the first request will try again                     # log warn
                "Foundry warm-up failed (%s: %s); the first request will retry",
                type(exc).__name__, exc,
            )

    def close(self) -> None:
        """Release the client's HTTP transport at shutdown. Best-effort.

        What this method does:
            - Swaps both client references out for None, then closes the captured project
              client inside a try/except.

        Why it exists:
            - The AIProjectClient holds a connection pool; closing it lets a graceful
              shutdown finish without leaving sockets to be reclaimed by process death.

        Security and production notes:
            1. The references are cleared FIRST, so a request that somehow arrives during
               shutdown rebuilds a fresh client instead of using a closed one -- `openai`
               would otherwise hand back a client whose transport is gone.
            2. Best-effort: a failure to close is logged, never raised, because raising
               here would turn a clean shutdown into a crash.

        Returns:
            None.

        Example:
            >>> FoundryClient("").close()  # doctest: +SKIP
        """
        project_client, self._project_client = self._project_client, None  # Capture, then clear     # take ref
        self._openai_client = None  # Cleared too, so `openai` rebuilds rather than reusing          # clear openai
        if project_client is None:  # Never built (or already closed) -> nothing to release          # anything?
            return  # Idempotent: calling close() twice is harmless                                  # no-op
        try:  # Best-effort release of the SDK's connection pool                                     # close try
            project_client.close()  # Return the sockets instead of leaking them to exit             # close pool
            logger.info("Foundry client closed")  # Confirms a clean shutdown in the log             # log info
        except Exception:  # A failed close must not turn shutdown into a crash                      # close failed
            logger.exception("could not close the Foundry client")  # Record and move on             # log error

    # ========================================= Internal build =====================================
    def _ensure(self) -> None:
        """Build the client once per process, under a lock.

        What this method does:
            - Returns immediately if already built; otherwise takes the lock, re-checks,
              lazily imports the Azure SDKs, builds both clients and assigns them.

        Why it exists:
            - Double-checked locking: the fast path is a plain attribute read with no lock,
              and only the first callers serialise. A process starts, the first request in
              builds the Foundry client while a couple of others briefly wait on the lock,
              and every request after that reuses it with no waiting.

        Security and production notes:
            1. `_openai_client` is assigned LAST, so a failed build leaves the object
               un-initialised and the next request retries instead of finding a half-built
               client cached.
            2. The SDKs are imported here rather than at module scope so importing this
               module (and therefore the app) doesn't require the Azure SDKs to be
               installed -- which is what lets the SQLite/offline mode run.

        Returns:
            None.

        Raises:
            Exception: Whatever the SDK raises; warm() tolerates it, `openai` propagates it.
        """
        if self._openai_client is not None:  # Fast path: already built, no lock taken               # built?
            return  # The common case on every request after the first                               # reuse
        with self._lock:  # Only the first concurrent callers serialise here                         # take lock
            if self._openai_client is not None:  # Re-check: another thread may have won             # built now?
                return  # Someone else built it while we waited for the lock                         # reuse
            # Imported here rather than at module scope so importing this module (and
            # therefore the app) doesn't require the Azure SDKs to be installed.
            from azure.ai.projects import AIProjectClient  # Foundry project data-plane client       # sdk import
            from azure.identity import DefaultAzureCredential  # Managed identity in production      # sdk import

            project_client = AIProjectClient(  # Built into a LOCAL name, not self, until it succeeds  # build project
                credential=DefaultAzureCredential(),  # Managed identity on App Service              # credential
                endpoint=self._endpoint,  # The project data-plane endpoint from Settings            # endpoint
                # azure-core transport options, for AIProjectClient's own calls.
                connection_timeout=self._timeout,  # Cap the TCP/TLS connect phase                   # connect to
                read_timeout=self._timeout,  # Cap waiting for the response body                     # read to
            )
            # get_openai_client() passes its keyword arguments straight to the OpenAI
            # client constructor, so this is what actually bounds conversations.create()
            # -- the first network call of every new chat. max_retries is set explicitly
            # because the SDK defaults to 2, which would silently triple the ceiling.
            openai_client = project_client.get_openai_client(  # Also into a local name first        # build openai
                timeout=self._timeout, max_retries=self._max_retries  # Worst case = t x (1+r)       # bounds
            )
            self._project_client = project_client  # Assigned first: close() needs this one          # keep project
            self._openai_client = openai_client  # Assigned LAST: this is the "built?" flag          # keep openai
            logger.info(  # Record the effective bounds, so the ceiling is auditable                 # log info
                "Foundry client initialized (lazy) timeout=%ss max_retries=%s",
                self._timeout, self._max_retries,
            )

    # ======================================== Foundry operations ==================================
    def create_conversation(self):
        """Create a new, empty Foundry conversation.

        What this method does:
            - Calls conversations.create() on the OpenAI-compatible client and returns the
              result, converting any failure into UpstreamUnavailable.

        Why it exists:
            - Every failure below this line becomes UpstreamUnavailable, so this client
              raises the same domain error the agents raise instead of leaking SDK types
              (openai's APITimeoutError, azure-core's ServiceRequestError,
              azure-identity's ClientAuthenticationError). Two reasons that matters:
                * the log line names the cause -- callers used to see only a generic
                  "chat failed" with a raw traceback;
                * nothing above this layer has to import openai or azure.core to reason
                  about a failure, and a non-HTTP caller (the job reaper, a script) gets an
                  error it can recognise.

        Security and production notes:
            1. The `except` also covers the LAZY BUILD in _ensure(), which runs on the first
               call -- so an auth or endpoint misconfiguration surfaces here as a normal
               upstream failure rather than an unhandled SDK exception.
            2. The chat controller still turns this into the user-facing fallback bubble; it
               catches Exception, and UpstreamUnavailable is one.

        Returns:
            The SDK's newly created conversation object.

        Raises:
            UpstreamUnavailable: The conversation could not be created, for any reason.

        Example:
            >>> client.create_conversation().id  # doctest: +SKIP
            'conv_abc123'
        """
        try:  # One Foundry call, bounded by the timeout/retries set at build time                   # create try
            return self.openai.conversations.create()  # Empty conversation, normally sub-second     # create conv
        except Exception as exc:  # Includes the lazy build in _ensure() on the first call           # create failed
            logger.error(  # Name the SDK exception type, which the generic body will not            # log error
                "foundry create_conversation failed (%s): %s", type(exc).__name__, exc
            )
            raise UpstreamUnavailable("Foundry conversation could not be created")  # -> 502         # raise 502
