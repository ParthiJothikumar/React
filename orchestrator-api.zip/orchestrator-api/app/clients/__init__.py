####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Package marker and map for `app.clients`, the third-party SDK wrappers.                          #
#   1. Declare app.clients as a package so `from app.clients.foundry import FoundryClient` works.  #
#   2. Explain why the one remaining client is a class: it holds state that outlives a call.       #
#   3. Record where the OLD HTTP client layer went, now that the agents are in-process.            #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported here. The only module left is foundry.py; the retired HTTP clients are   #
#       parked under ../../legacy-functions/dead-clients/ and nothing in this app imports them.    #
####################################################################################################
"""Third-party SDK clients.

What this package is:
    - One module:

        foundry.py   FoundryClient -- the Azure AI Foundry AIProjectClient, lazy and
                     thread-safe

Why this exists:
    - A class because it holds something that must outlive a single call: the built
      client. It is instantiated once per worker process in deps.py and handed to the
      services and to every agent, so the credential handshake happens once rather than
      per request.

Security and production notes:
    1. The client authenticates with DefaultAzureCredential, so in production it uses the
       App Service managed identity and no secret is stored in configuration. That
       identity still needs the Azure AI Foundry DATA-PLANE role -- Owner/Contributor on
       the resource is not sufficient.
    2. Sharing one client across 40 request threads is only safe because FoundryClient
       builds it under a lock; see the thread-safety note in foundry.py.

WHAT USED TO BE HERE, and where its behaviour went. http.py (HttpClient and its pooled
requests.Session), agents.py (AgentClient), servicenow.py, multilingual.py and
jobs_agent.py all existed to POST to the sibling agent Function Apps. Those agents are
now classes under app/agents/, called directly, so the whole transport layer is gone --
with it the connection pooling, the ?code= function keys and the URL -> agent-name
mapping in core/tracing.py. The behaviour those modules protected did NOT go with them:

    the ServiceNow best-effort / must-raise split   -> agents/servicenow/main.py
    "translation must never break a conversation"   -> agents/multilingual/main.py
    the {"success": false} failure shape            -> agents/classification_second/
    message vs output, and the no-simulation rule   -> domain/run_state.py, domain/jobs.py

The originals are parked in ../../legacy-functions/dead-clients/ rather than deleted, so
the diff is recoverable while this is still settling. Nothing imports them.
"""
