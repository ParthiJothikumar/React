####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Public face of `app.db.repositories`: all SQL for the five tables this app writes.               #
#   1. Re-export the five repository classes, so callers import from the package not the module.   #
#   2. Name which table group each repository owns.                                                #
#   3. Record the three rules that keep the SQL safe: class-constant statements, ? binding, and    #
#        the commit / transaction() convention the service layer relies on.                        #
#                                                                                                  #
# Source:-                                                                                         #
#   - The five sibling modules hold the statements; only their classes are re-exported here, so a  #
#       later split of one module does not touch any of its callers.                               #
####################################################################################################
"""Repositories: all SQL for the conversations, sessions, transcript and trace tables.

What this package is:
    - Five repositories, one per table group:

        base.py            BaseRepository -- shared connection, commit and transaction()
        conversations.py   conversations + conversation_turns: flow state, job state, transcript
        sessions.py        sessions: the chat list in the frontend's left panel
        agent_calls.py     agent_calls: the internal trace of every agent call
        api_requests.py    api_requests: one row per HTTP request we serve

Why this exists:
    - Each repository is constructed with an open connection and owns the queries for one
      table group. Holding the connection is the reason these are classes -- it stops every
      call site threading `conn` (and usually `user_id`) through as parameters, and it gives
      the transaction boundary somewhere to live.
    - Imported from here rather than from the individual modules, so a caller writes
      `from app.db.repositories import ConversationRepository` and a later split of one
      module does not touch its callers.

Security and production notes:
    1. The SELECT column lists are kept as class constants so the dialect variants stay in
       sync, and the full statements are assembled from them at class level -- never with an
       f-string at the execute() call -- so static analysis (Snyk) doesn't flag SQL built by
       string formatting. Those constants are fixed literals, never user input; every user
       value is bound with ?.
    2. COMMITS: a write method calls self._commit(), which commits immediately when used on
       its own but defers to the enclosing transaction() block when there is one. The
       service layer wraps the sequences that must agree with each other -- completing a
       job, and persisting a chat turn -- so those commit exactly once instead of two or
       three times. The two trace tables are the exception and say so in their own
       docstrings.
    3. ConversationRepository.advance_after_job() is the other half of that: it folds the
       job outcome and the new stage into ONE conditional UPDATE, which doubles as the
       compare-and-swap that stops two concurrent pollers both completing the same job.

Example:
    >>> from app.db.repositories import ConversationRepository  # doctest: +SKIP
"""

# ============================================ Imports =============================================
from app.db.repositories.agent_calls import AgentCallRepository  # agent_calls: per-call trace       # trace repo
from app.db.repositories.api_requests import ApiRequestRepository  # api_requests: per-request timing  # timing repo
from app.db.repositories.base import BaseRepository  # Shared connection, commit, transaction()      # base repo
from app.db.repositories.conversations import ConversationRepository  # Flow, job and transcript state  # conv repo
from app.db.repositories.sessions import SessionRepository  # sessions: the frontend's chat list     # session repo

# =========================================== Public API ===========================================
# Explicit, so `import *` and the linters agree on the surface area of this package.
__all__ = [
    "AgentCallRepository",  # Insert-only trace; commits on its own, never raises                    # export
    "ApiRequestRepository",  # Insert-only timing; commits on its own, never raises                  # export
    "BaseRepository",  # Exported for subclassing and for typing in tests                            # export
    "ConversationRepository",  # The busiest one: flow state, job state and transcript               # export
    "SessionRepository",  # Session list and its "current conversation" pointer                      # export
]
