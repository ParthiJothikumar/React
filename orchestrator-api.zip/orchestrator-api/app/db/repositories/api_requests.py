####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# All SQL for the api_requests table -- one row per HTTP request this app serves.                  #
#   1. add(): record endpoint, total duration, agent time, status and error flag. Never raises.    #
#   2. list_for_conversation(): read every request served for one conversation, oldest first.      #
#   3. Commit on its OWN, never inside the caller's transaction() -- same rule as agent_calls.     #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.core.config.logger records a dropped row; timing must never fail the request it times.   #
#   - app.db.database.fetchall_dicts turns the read's cursor tuples into name-keyed dicts.         #
#   - app.db.repositories.base supplies the shared connection and the now_iso() timestamp.         #
####################################################################################################
"""api_requests: one row per HTTP request we serve.

What this module is:
    - ApiRequestRepository: one insert and one read, plus the statements they use.

Why this exists:
    - duration_ms minus agent_ms is our OWN overhead, which is the number this table exists
      to make answerable. Neither conversation_turns nor agent_calls can produce it.

Security and production notes:
    1. Same rules as AgentCallRepository -- insert-only, its own commit, never raises -- and
       for the same reasons. See that class for the ordering rule; this one is written from
       the same finally block.
    2. The row carries no message content: only an endpoint name, ids, durations and a
       status. That is what makes it safe to keep for as long as capacity review needs.
"""

# ============================================ Imports =============================================
from app.core.config import logger  # Records a dropped row; the request still succeeds              # config
from app.db.database import fetchall_dicts  # Cursor tuples -> name-keyed dicts on the read          # row adapter
from app.db.repositories.base import BaseRepository, now_iso  # Shared connection + UTC clock        # base repo


# ========================================= Request timing =========================================
class ApiRequestRepository(BaseRepository):
    """api_requests: one row per HTTP request we serve.

    What this class is:
        - An insert-only timing table (plus one read for support): endpoint, total duration,
          time spent inside agents, HTTP status and an error flag.

    Why it exists:
        - Same rules as AgentCallRepository -- insert-only, its own commit, never raises --
          and for the same reasons. See that class for the ordering rule; this one is
          written from the same finally block.
        - The one difference is that a row is written even when NOTHING else happened: a
          status poll that returns early, or a request that failed before reaching an agent,
          still gets its timing recorded. That is the whole point of the table. Building
          latency charts from conversation_turns or agent_calls silently omits those, and
          they are the slow and broken requests.

    Security and production notes:
        1. Its commit is the shared connection's commit, so add() must be called AFTER any
           enclosing transaction() block has exited -- exactly as for agent_calls.
        2. No message content is stored, only ids and numbers, so this table needs no
           redaction before it is queried for capacity planning.

    Example:
        >>> ApiRequestRepository(conn).add("u1", "c1", "/api/chat", 3204, agent_ms=2900)  # doctest: +SKIP
    """

    # -- Statements. Class constants assembled at class level, so no SQL is ever built with an
    # -- f-string at the execute() call; every user value below is bound with ?.
    _SQL_INSERT = (  # One row per served request; the database assigns the id                       # insert sql
        "INSERT INTO api_requests (user_id, conversation_id, endpoint, duration_ms, "
        "agent_ms, http_status, is_error, started_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    )
    _COLS = (  # Shared column list, so the read's shape is declared in exactly one place            # column list
        "id, conversation_id, endpoint, duration_ms, agent_ms, http_status, "
        "is_error, started_at"
    )
    _SQL_BY_CONVERSATION = (  # Ordered by id, which is also insertion order                         # select sql
        "SELECT " + _COLS + " FROM api_requests "
        "WHERE user_id = ? AND conversation_id = ? ORDER BY id ASC"
    )

    def add(
        self, user_id: str, conv_id, endpoint: str, duration_ms: int,
        agent_ms=None, http_status=None, is_error: bool = False,
        started_at=None,
    ) -> None:
        """Record one served request. Never raises.

        What this method does:
            - Inserts a single row, coercing duration to an int, agent_ms to an int or NULL,
              the error flag to 0/1, and defaulting started_at to now.

        Why it exists:
            - So EVERY request is timed, including the ones that returned early or failed
              before any agent ran -- which are the interesting ones.

        Security and production notes:
            1. Swallows its own failures for the same reason append_calls does: a timing
               table must not be able to fail the request it is timing.
            2. self._conn.commit() is called DIRECTLY, not self._commit(), so the row
               survives a rolled-back turn. It must therefore be called after the turn's
               transaction() block has exited.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation, or None for a request with no conversation yet.
            endpoint: Route name, e.g. "/api/chat". A fixed literal, never user input.
            duration_ms: Total wall-clock time for the request.
            agent_ms: Of that, the time spent inside agents; NULL when none ran.
            http_status: The status returned, when the caller knows it.
            is_error: True when the request did not succeed; stored as 0/1.
            started_at: ISO-8601 start stamp; defaults to now when omitted.

        Returns:
            None.

        Example:
            >>> repo.add("u1", "c1", "/api/jobs/status", 42, http_status=200)  # doctest: +SKIP
        """
        try:  # Best-effort: a timing failure must never fail the request being timed                # write try
            self._cursor().execute(
                self._SQL_INSERT,
                (
                    user_id,  # Bound, never interpolated                                            # user id
                    conv_id,  # May be None for a request with no conversation yet                   # conv id
                    endpoint,  # Fixed route literal from the caller, not user input                 # endpoint
                    int(duration_ms or 0),  # Never NULL: the column is NOT NULL                     # duration
                    None if agent_ms is None else int(agent_ms),  # NULL when no agent ran           # agent ms
                    http_status,  # None when the caller does not know the status yet                # status
                    1 if is_error else 0,  # 0/1 reads the same on both engines                      # error flag
                    started_at or now_iso(),  # Caller's stamp, or now                               # started at
                ),
            )
            self._conn.commit()  # DIRECT commit, not _commit(): must survive a rolled-back turn     # commit
        except Exception:  # Drop the timing row rather than break the request                       # write failed
            logger.exception(  # Name the conversation and endpoint so the gap is explainable        # log drop
                "could not write api_requests row conv_id=%s endpoint=%s (dropped)",
                conv_id, endpoint,
            )

    def list_for_conversation(self, user_id: str, conv_id: str) -> list:
        """Every request served for one conversation, oldest first.

        What this method does:
            - Selects all api_requests rows for one user's conversation, ordered by id.

        Why it exists:
            - So the per-turn latency of a specific conversation can be reconstructed,
              including the polls, when a user reports that something felt slow.

        Security and production notes:
            1. Scoped by user_id as well as conversation_id, so one user's id cannot be used
               to read another user's timings.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation to read timings for.

        Returns:
            One dict per served request, oldest first; empty list when there are none.

        Example:
            >>> repo.list_for_conversation("u1", "c1")  # doctest: +SKIP
            [{'id': 1, 'endpoint': '/api/chat', 'duration_ms': 3204}]
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_BY_CONVERSATION, (user_id, conv_id))  # Both values bound with ?       # select
        return fetchall_dicts(cur)  # Name-keyed rows; empty list when nothing matched               # to dicts
