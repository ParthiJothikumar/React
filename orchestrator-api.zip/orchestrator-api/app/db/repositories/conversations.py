####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# All SQL for conversations + conversation_turns: flow state, job state and the transcript.        #
#   1. load() / save(): the stage machine's state, with flow_vars split across JSON and columns.   #
#   2. append_turns() / load_turns(): the exact FE-visible transcript, in display order.           #
#   3. start_job() / update_job_message() / get_job(): the job_* columns on the conversation row.  #
#   4. advance_after_job(): ONE conditional UPDATE that is also the compare-and-swap.              #
#   5. find_running(): the reaper's list of jobs nobody is watching any more.                      #
#                                                                                                  #
# Source:-                                                                                         #
#   - json serialises whatever is left of flow_vars into the `vars` text column.                   #
#   - app.core.constants supplies the stage / job-status literals the statements bind.             #
#   - app.db.database supplies fetchone_dict / fetchall_dicts for the reads.                       #
#   - app.db.repositories.base supplies the shared connection, _commit() and now_iso().            #
####################################################################################################
"""conversations + conversation_turns: flow state, job state and the transcript.

What this module is:
    - ConversationRepository, plus four module-level helpers that move the "promoted"
      flow_vars keys between the JSON blob and their own indexed columns.

Why this exists:
    - This is the busiest table in the app: it holds where the stage machine is, what the
      flow remembers, which ServiceNow records exist, how the conversation ended, and the
      state of any async job attached to it.

Security and production notes:
    1. job_output holds RAW device script output (profile paths, mailbox addresses,
       internal host names). It is deliberately NOT selected by get_job(); support reads it
       through load_job_output(), and its value must never reach an HTTP response.
    2. advance_after_job() is the concurrency boundary for the whole job pipeline. Its
       `AND stage = ?` is what stops two pollers, two browser tabs or the reaper on a second
       instance from both completing the same job.
    3. Every user value is bound with ?; the statements are class constants assembled at
       class level, never f-strings at the execute() call.
"""

# ============================================ Imports =============================================
import json  # Serialise / parse the `vars` column that carries the rest of flow_vars                # stdlib json
from typing import Optional  # load() may legitimately find no row                                   # stdlib typing

from app.core.constants import (  # The stage and job-status literals the statements bind            # constants
    DIAGNOSTICS_RUNNING,  # One of the two stages find_running() looks for                           # stage
    DONE,  # Terminal stage; triggers the write-once ended_at stamp                                  # stage
    JOB_RUNNING,  # job_status value written by start_job / update_job_message                       # job status
    TROUBLESHOOT_RUNNING,  # The other stage find_running() looks for                                # stage
)
from app.db.database import fetchall_dicts, fetchone_dict  # Cursor tuples -> name-keyed dicts       # row adapters
from app.db.repositories.base import BaseRepository, now_iso  # Shared connection + UTC clock        # base repo


# ======================================= flow_vars helpers ========================================
def _vars_json(vars_val):
    """Serialize flow_vars for the `vars` column (already-serialized values pass through).

    Args:
        vars_val: A dict/list to encode, or already-encoded text to pass through.

    Returns:
        JSON text, or the input unchanged when it was not a dict/list.
    """
    return (  # default=str so an exotic value degrades to its repr instead of raising               # encode
        json.dumps(vars_val, default=str)
        if isinstance(vars_val, (dict, list))
        else vars_val  # Already text (a re-save of a loaded row) -> leave it alone                  # pass through
    )


# Keys the flow keeps in flow_vars but which are stored in their OWN columns, so they can
# be indexed, joined and reported on instead of being buried in a JSON blob.
#
# The flow is unchanged by this: it still reads flow_vars.get("incident_id") in ~15
# places. Only the storage moved. save() lifts these out of flow_vars into the columns
# and strips them from the JSON (so there is one copy, not two), and load() merges them
# back in -- so what the flow receives looks exactly as it always did.
_PROMOTED = ("interaction_id", "incident_id", "resolved", "escalated")  # Lifted into columns        # promoted
_PROMOTED_FLAGS = ("resolved", "escalated")  # Of those, the two stored as 0/1 NOT NULL flags        # flags


def _split_vars(flow_vars):
    """-> (values for the promoted columns, JSON text for whatever is left).

    What this function does:
        - Pulls the four promoted keys out of flow_vars, coercing the two flags to 0/1, and
          JSON-encodes only the REMAINING keys.

    Why it exists:
        - So each value is stored exactly once. Leaving a copy in the JSON as well would
          create two places that can disagree about whether a conversation was escalated.

    Security and production notes:
        1. The flags are coerced to 0/1 rather than passed through: the columns are NOT
           NULL, and a mid-conversation turn has no "escalated" key at all. Without this a
           normal turn would try to write NULL and fail the constraint.

    Args:
        flow_vars: The flow's variables dict, or already-serialized text.

    Returns:
        A (promoted_values, vars_json) pair.

    Example:
        >>> _split_vars({"incident_id": "IN1", "kb_id": "KB2"})[0]["incident_id"]
        'IN1'
    """
    if not isinstance(flow_vars, dict):  # Already-serialized vars: nothing to lift out              # a dict?
        # Already-serialized vars (a re-save of a loaded row): nothing to lift out.
        return {k: None for k in _PROMOTED}, flow_vars  # All columns NULL, text unchanged           # pass through
    promoted = {}  # Accumulator for the four column values                                          # accumulator
    for key in _PROMOTED:  # Lift each promoted key out of flow_vars                                 # each key
        value = flow_vars.get(key)  # Absent keys become None (or 0 for the two flags)               # read value
        promoted[key] = (1 if value else 0) if key in _PROMOTED_FLAGS else value  # NOT NULL flags   # coerce
    rest = {k: v for k, v in flow_vars.items() if k not in _PROMOTED}  # Everything else             # remainder
    return promoted, _vars_json(rest)  # One copy of each value, never two                           # return pair


def _merge_promoted(row):
    """Put the promoted columns back into row["vars"], in place.

    What this function does:
        - Copies row["vars"], overlays the four promoted columns onto it (converting the two
          flags to real booleans), and assigns the result back to row["vars"].

    Why it exists:
        - Keeps the flow's view of flow_vars identical to before the columns existed, so the
          ~15 places that read flow_vars.get("incident_id") did not have to change.

    Security and production notes:
        1. The flags come back as real booleans, because 0/1 from SQLite and True/False from
           Azure SQL would otherwise behave differently in `if flow_vars.get("escalated")`.

    Args:
        row: A loaded conversation row whose "vars" has already been JSON-parsed.

    Returns:
        The same row, mutated, for convenient chaining.

    Example:
        >>> _merge_promoted({"vars": {}, "resolved": 1, "escalated": 0,
        ...                  "interaction_id": None, "incident_id": None})["vars"]["resolved"]
        True
    """
    merged = dict(row.get("vars") or {})  # Copy, so the caller's dict is not aliased                # copy vars
    for key in _PROMOTED:  # Overlay each promoted column back onto the flow's view                  # each key
        value = row.get(key)  # The column value as the driver returned it                           # read column
        merged[key] = bool(value) if key in _PROMOTED_FLAGS else value  # Real bools, both engines   # coerce
    row["vars"] = merged  # The flow now sees exactly what it always did                             # write back
    return row  # Returned for chaining in load()                                                    # return row


# ==================================== Conversation repository =====================================
class ConversationRepository(BaseRepository):
    """conversations + conversation_turns: flow state, job state and the transcript.

    What this class is:
        - The owner of both tables: the conversation row (stage, flow_vars, ServiceNow ids,
          outcome flags, job_* columns) and the transcript rows the frontend replays.

    Why it exists:
        - Takes `use_sqlite` because find_running() needs a row limit, and that is the one
          thing the two dialects spell differently (LIMIT vs TOP).
        - The job_* columns live on the conversation row (a job belongs to a conversation)
          rather than in a separate table: the FE reads job status by conversation_id, which
          this row already supports. The job methods touch ONLY the job_* columns via
          targeted UPDATEs, so they never clash with save() (which does not name them).

    Security and production notes:
        1. advance_after_job() is the compare-and-swap that makes job completion idempotent
           across two browser tabs, several gunicorn workers and the reaper on another
           instance. Read its docstring before changing any WHERE clause here.
        2. job_output is raw device output and is NOT part of get_job(); load_job_output()
           is the support-only door to it.

    Example:
        >>> ConversationRepository(conn, use_sqlite=True).load("u1", "c1")  # doctest: +SKIP
    """

    # THREE TIMESTAMPS, one job each:
    #   started_at        when the conversation began. Written once, never moves.
    #   last_updated_at   last activity of any kind -- every turn AND every job poll bump
    #                     it. The reaper's staleness filter and its ordering both depend
    #                     on that, which is why it is separate from the other two.
    #   ended_at          when the conversation reached DONE. Written once; NULL while
    #                     active, so "still open" is a plain IS NULL test.
    #
    # ended_at is stamped by the repository, not by the flow: the flow returns DONE from
    # TEN branches, plus an eleventh (job expiry) that lives in the service. One
    # write-once rule here cannot be forgotten by a branch added later.
    _COLS = (  # Shared column list, so load()'s shape is declared in exactly one place              # column list
        "id, user_id, conversation_id, stage, vars, question, answer, "
        "session_id, seq, title, started_at, last_updated_at, ended_at, "
        "interaction_id, incident_id, resolved, escalated"
    )
    _SQL_LOAD = (  # By primary key (user_id + id)                                                   # load sql
        "SELECT " + _COLS + " FROM conversations WHERE user_id = ? AND id = ?"
    )
    # ended_at = COALESCE(ended_at, ?) is the write-once rule. The bound value is the
    # current time only when this save lands on DONE, otherwise NULL -- and
    # COALESCE(ended_at, NULL) leaves an already-set value alone. So the first save that
    # ends the conversation stamps it and nothing later can move it, with no extra read.
    _SQL_UPDATE = (  # Half of the upsert; tried first, because a turn on an existing row is common  # update sql
        "UPDATE conversations SET conversation_id = ?, stage = ?, vars = ?, "
        "question = ?, answer = ?, session_id = ?, seq = ?, "
        "title = ?, started_at = ?, last_updated_at = ?, "
        "ended_at = COALESCE(ended_at, ?), "
        "interaction_id = ?, incident_id = ?, resolved = ?, escalated = ? "
        "WHERE user_id = ? AND id = ?"
    )
    _SQL_INSERT = (  # Other half of the upsert; only runs when the UPDATE matched no row            # insert sql
        "INSERT INTO conversations (id, user_id, conversation_id, stage, vars, "
        "question, answer, session_id, seq, title, started_at, last_updated_at, "
        "ended_at, interaction_id, incident_id, resolved, escalated) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )
    _SQL_BY_SESSION = (  # Still-active conversations of one session, oldest first                   # by session
        "SELECT conversation_id, session_id, seq FROM conversations "
        "WHERE user_id = ? AND session_id = ? "
        "AND (stage IS NULL OR stage <> 'DONE') ORDER BY seq ASC"
    )
    _SQL_JOB = (  # NOTE: job_output is deliberately absent -- see the comment below                 # job sql
        "SELECT job_id, job_status, job_message, job_baseline, job_started_at "
        "FROM conversations WHERE user_id = ? AND id = ?"
    )
    # Rows the reaper must look at: a job still marked running, on a conversation still
    # parked in a RUNNING stage, that NOBODY HAS TOUCHED for a while.
    #
    # That last condition is what keeps the reaper a backstop instead of a second poller.
    # last_updated_at is bumped by every poll, so a browser polling every ~30s keeps its
    # own conversation out of this result set. Without it the reaper re-checked every
    # running job on every sweep, duplicating work the browser was already doing.
    #
    # ORDER BY last_updated_at, i.e. "whoever we have not looked at for the longest goes
    # first". This is what stops the batch limit starving anyone. Ordering by
    # job_started_at instead looked reasonable but never changed, so with more stuck jobs
    # than `limit` the same oldest-started rows were picked every sweep and the remainder
    # were never reached. Because a sweep bumps last_updated_at on everything it touches,
    # this ordering rotates by itself -- no extra state, and every job is eventually seen.
    _FIND_RUNNING_FROM = (  # Shared tail, so the two dialect variants cannot drift                  # find from
        "FROM conversations WHERE job_status = ? AND stage IN (?, ?) "
        "AND last_updated_at < ? ORDER BY last_updated_at ASC"
    )
    _SQL_FIND_RUNNING_SQLITE = (  # SQLite: LIMIT ? goes at the END, after the WHERE values          # sqlite sql
        "SELECT user_id, id, job_started_at " + _FIND_RUNNING_FROM + " LIMIT ?"
    )
    _SQL_FIND_RUNNING_AZURE = (  # T-SQL: TOP (?) goes FIRST, before the WHERE values                # azure sql
        "SELECT TOP (?) user_id, id, job_started_at " + _FIND_RUNNING_FROM
    )
    _SQL_TURNS = (  # The FE-visible transcript, in the order the user saw it                        # turns sql
        "SELECT role, content FROM conversation_turns "
        "WHERE user_id = ? AND conversation_id = ? ORDER BY seq ASC"
    )
    _SQL_MAX_SEQ = (  # Read before appending, because the FE replays turns in display order         # max seq sql
        "SELECT MAX(seq) FROM conversation_turns "
        "WHERE user_id = ? AND conversation_id = ?"
    )
    _SQL_INSERT_TURN = (  # One row per FE-visible message                                           # turn insert
        "INSERT INTO conversation_turns "
        "(user_id, conversation_id, seq, role, content, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)"
    )
    # The compare-and-swap that makes job completion idempotent. Note the extra
    # `AND stage = ?` -- see advance_after_job().
    # ended_at gets the same write-once COALESCE as _SQL_UPDATE: a job finishing can end
    # the conversation outright (a failed diagnostic routes to the support team and goes
    # straight to DONE), and this UPDATE is the only write on that path.
    _SQL_ADVANCE_AFTER_JOB = (  # ONE statement: job outcome + new stage + outcome flags             # advance sql
        "UPDATE conversations SET stage = ?, vars = ?, question = ?, answer = ?, "
        "job_status = ?, job_message = ?, job_output = ?, "
        "last_updated_at = ?, ended_at = COALESCE(ended_at, ?), "
        "interaction_id = ?, incident_id = ?, resolved = ?, escalated = ? "
        "WHERE user_id = ? AND id = ? AND stage = ?"
    )
    # job_output is deliberately NOT selected here. get_job() feeds user-facing paths
    # (_already_advanced, and the "no active job" branch), and raw device output must
    # never reach the browser. Support reads it with load_job_output().
    _SQL_JOB_OUTPUT = (  # Support-only door to the raw device output column                         # output sql
        "SELECT job_output FROM conversations WHERE user_id = ? AND id = ?"
    )

    def __init__(self, conn, use_sqlite: bool = True) -> None:
        """Adopt the request's connection and remember which SQL dialect to use.

        Args:
            conn: The request's open DB-API 2.0 connection.
            use_sqlite: True to use the LIMIT variant in find_running(), False for TOP.

        Returns:
            None.
        """
        super().__init__(conn)  # BaseRepository owns the connection and the commit rule             # base init
        self._use_sqlite = use_sqlite  # Picks the LIMIT vs TOP variant in find_running()            # dialect

    # ============================================ Flow state ======================================
    def load(self, user_id: str, conv_id: str) -> Optional[dict]:
        """Load one conversation's saved state row, or None if it doesn't exist.

        What this method does:
            - Selects the row, JSON-parses the `vars` column (empty dict when absent), then
              merges the promoted columns back into it.

        Why it exists:
            - Returns a dict keyed by column name, with `vars` already parsed from its JSON
              text back into a Python dict AND the promoted columns merged into it -- so the
              flow sees the same flow_vars it always did, whether a value is stored in the
              JSON or in its own column.

        Args:
            user_id: Owner of the conversation; part of the primary key.
            conv_id: The conversation to load.

        Returns:
            The row as a dict with `vars` as a real dict, or None when it does not exist.

        Example:
            >>> repo.load("u1", "c1")["stage"]  # doctest: +SKIP
            'AWAITING_CLASSIFY'
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_LOAD, (user_id, conv_id))  # Both values bound with ?                  # select
        row = fetchone_dict(cur)  # None when this conversation does not exist yet                   # to dict
        if row is None:  # First turn of a new conversation -> the caller starts fresh               # exists?
            return None  # Distinguishes "new" from "exists but empty"                               # return none
        row["vars"] = json.loads(row["vars"]) if row.get("vars") else {}  # Text -> dict             # parse vars
        return _merge_promoted(row)  # Overlay the promoted columns, so the flow's view is unchanged  # merge

    def save(
        self,
        user_id: str,
        conv_id: str,
        *,
        stage: str,
        flow_vars: dict,
        question: str,
        answer: str,
        session_id: Optional[str] = None,
        seq: Optional[int] = None,
    ) -> None:
        """Save a conversation turn: merge the given fields with any existing row.

        What this method does:
            - Reads any existing row, builds the full item (falling back to stored lineage
              values), stamps ended_at only when this save lands on DONE, then upserts.

        Why it exists:
            - Lineage fields (session_id, seq) fall back to whatever is already stored when
              passed as None, so a normal turn need not re-supply them. On first save it
              stamps started_at and title (= the question), then upserts.

        Security and production notes:
            1. ended_at is stamped here whenever `stage` is DONE -- including on a first
               save that ends immediately, which the non_outlook_it branch does (ticket
               raised, user thanked, conversation over in one turn). The COALESCE in
               _SQL_UPDATE then makes it write-once.
            2. This statement does NOT name any job_* column, so it can never clash with a
               concurrent job update on the same row.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation to save; also its `id`.
            stage: The new stage; DONE triggers the ended_at stamp.
            flow_vars: The flow's variables; the promoted keys are lifted into columns.
            question: The user's message this turn.
            answer: What we replied this turn.
            session_id: Lineage; keeps the stored value when None.
            seq: Lineage; keeps the stored value (or 0) when None.

        Returns:
            None.

        Example:
            >>> repo.save("u1", "c1", stage="DONE", flow_vars={}, question="q", answer="a")  # doctest: +SKIP
        """
        now = now_iso()  # One stamp for last_updated_at, and for a first started_at                 # stamp
        existing = self.load(user_id, conv_id) or {}  # {} means "creating it now"                   # read current
        item = {
            "id": conv_id,  # Primary key, together with user_id                                     # id
            "user_id": user_id,  # Owner; scopes every statement in this class                       # user id
            "conversation_id": conv_id,  # Kept as its own column for the FE's convenience           # conv id
            "stage": stage,  # Where the stage machine now is                                        # stage
            "vars": flow_vars,  # Split by _split_vars() inside _upsert()                            # vars
            "question": question,  # The user's message this turn                                    # question
            "answer": answer,  # What we replied this turn                                           # answer
            "last_updated_at": now,  # Bumped every turn AND every poll; the reaper reads it         # updated at
            # lineage: use the passed value, else keep what's already stored
            "session_id": (  # None means "don't change it"                                          # session id
                session_id if session_id is not None else existing.get("session_id")
            ),
            "seq": seq if seq is not None else existing.get("seq", 0),  # None -> keep stored        # seq
            "title": question if not existing else existing.get("title"),  # First write wins        # title
            "started_at": now if not existing else existing.get("started_at", now),  # Write once    # started at
            # Only non-NULL on the save that ends the conversation; the COALESCE in
            # _SQL_UPDATE then makes it write-once.
            "ended_at": now if stage == DONE else None,  # NULL while still active                   # ended at
        }
        self._upsert(item)  # UPDATE, then INSERT on miss; commits via _commit()                     # upsert

    def _upsert(self, item: dict) -> None:
        """Insert or update a conversation row.

        What this method does:
            - Splits flow_vars into promoted column values plus the remaining JSON, tries
              the UPDATE by primary key, INSERTs when it matched no row, then commits.

        Why it exists:
            - Lifts the promoted keys (the ServiceNow ids and the two outcome flags) out of
              flow_vars into their own columns and serializes only what is LEFT into `vars`,
              so each value is stored once rather than in two places that can disagree.
              Then tries an UPDATE by primary key (user_id + id); if it matched no row
              (rowcount == 0), INSERTs instead. One code path that works on both SQLite and
              Azure SQL.

        Security and production notes:
            1. Every value is bound with ?; the statements are class constants, never built
               with an f-string at the execute() call.

        Args:
            item: The full row as a dict, already resolved by save().

        Returns:
            None.
        """
        promoted, vars_json = _split_vars(item.get("vars"))  # One copy of each value, never two     # split vars
        cur = self._cursor()  # One cursor for both statements, so rowcount refers to the UPDATE     # cursor
        cur.execute(  # Try the UPDATE first: a turn on an existing row is the common case           # try update
            self._SQL_UPDATE,
            (
                item.get("conversation_id"), item.get("stage"), vars_json,  # State columns          # set cols
                item.get("question"), item.get("answer"), item.get("session_id"),  # Turn + lineage  # set cols
                item.get("seq"), item.get("title"), item.get("started_at"),  # Lineage + write-once  # set cols
                item.get("last_updated_at"), item.get("ended_at"),  # Stamps; ended_at is COALESCEd  # set cols
                promoted["interaction_id"], promoted["incident_id"],  # Promoted ServiceNow ids      # set cols
                promoted["resolved"], promoted["escalated"],  # Promoted outcome flags, as 0/1       # set cols
                item.get("user_id"), item.get("id"),  # WHERE: the primary key                       # where
            ),
        )
        if cur.rowcount == 0:  # No such conversation yet -> create it                               # existed?
            cur.execute(
                self._SQL_INSERT,
                (
                    item.get("id"), item.get("user_id"), item.get("conversation_id"),  # Keys        # insert vals
                    item.get("stage"), vars_json, item.get("question"),  # State + turn              # insert vals
                    item.get("answer"), item.get("session_id"), item.get("seq"),  # Turn + lineage   # insert vals
                    item.get("title"), item.get("started_at"),  # Write-once values                  # insert vals
                    item.get("last_updated_at"), item.get("ended_at"),  # Both remaining stamps      # insert vals
                    promoted["interaction_id"], promoted["incident_id"],  # Promoted ids             # insert vals
                    promoted["resolved"], promoted["escalated"],  # Promoted flags, as 0/1           # insert vals
                ),
            )
        self._commit()  # Commits now, or defers to the caller's transaction() block                 # commit

    def list_by_session(self, user_id: str, session_id: str) -> list:
        """Return the session's still-active conversations, oldest first.

        Args:
            user_id: Owner of the session.
            session_id: The session whose conversations to list.

        Returns:
            One dict per still-active conversation, ordered by seq.

        Example:
            >>> repo.list_by_session("u1", "s1")  # doctest: +SKIP
            [{'conversation_id': 'c1', 'session_id': 's1', 'seq': 0}]
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_BY_SESSION, (user_id, session_id))  # DONE rows are excluded           # select
        return fetchall_dicts(cur)  # Oldest first, by seq                                           # to dicts

    # ============================================ Transcript ======================================
    def append_turns(self, user_id: str, conv_id: str, turns) -> None:
        """Append FE-visible messages to conversation_turns (Approach A).

        What this method does:
            - Drops blank contents, reads MAX(seq) once, then inserts each remaining message
              with the next sequential seq and a single shared timestamp.

        Why it exists:
            - `turns` is a list of (role, content) pairs in display order -- typically the
              user's message followed by each assistant line we return that turn. This is
              the EXACT text shown to the user (post-translation, no agent JSON), so the
              conversations API can replay it verbatim. Each row gets the next sequential
              seq for this conversation, so history always reads back in the order the user
              saw it.

        Security and production notes:
            1. The MAX(seq)+1 read is why this is two statements rather than one. It is safe
               because the only concurrent writer on one conversation is guarded by
               advance_after_job()'s compare-and-swap -- the loser writes nothing.
            2. Call this inside the caller's transaction() so the stage move and the
               transcript rows commit as one unit.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation to append to.
            turns: Iterable of (role, content) pairs in display order.

        Returns:
            None.

        Example:
            >>> repo.append_turns("u1", "c1", [("user", "hi"), ("assistant", "hello")])  # doctest: +SKIP
        """
        rows = [(role, content) for role, content in turns if content and content.strip()]  # Skip blanks  # filter
        if not rows:  # Nothing FE-visible this turn -> no round trip at all                         # any rows?
            return  # e.g. a turn whose only output was a job status update                          # skip
        now = now_iso()  # One stamp for the whole batch, so the rows sort together                  # batch stamp
        cur = self._cursor()  # One cursor for the seq read and every insert                         # cursor
        # Next seq = one past the current max for this conversation (0 on first write).
        cur.execute(self._SQL_MAX_SEQ, (user_id, conv_id))  # Display order matters to the FE        # read max seq
        row = cur.fetchone()  # (None,) when the conversation has no turns yet                       # fetch max
        next_seq = (row[0] + 1) if row and row[0] is not None else 0  # 0 on the first write         # next seq
        for role, content in rows:  # Insert in display order, incrementing as we go                 # each turn
            cur.execute(
                self._SQL_INSERT_TURN,
                (user_id, conv_id, next_seq, role, content, now),  # All values bound with ?         # insert
            )
            next_seq += 1  # Keep the display order the user actually saw                            # bump seq
        self._commit()  # Commits now, or defers to the caller's transaction() block                 # commit

    def load_turns(self, user_id: str, conv_id: str) -> list:
        """Return a conversation's FE-visible transcript as [{role, content}], oldest
        first. Empty list when nothing was recorded (e.g. chats created before Approach A).

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation whose transcript to read.

        Returns:
            One {role, content} dict per message, oldest first.

        Example:
            >>> repo.load_turns("u1", "c1")  # doctest: +SKIP
            [{'role': 'user', 'content': 'hi'}, {'role': 'assistant', 'content': 'hello'}]
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_TURNS, (user_id, conv_id))  # Ordered by seq, i.e. display order       # select
        return [{"role": r[0], "content": r[1]} for r in cur.fetchall()]  # Two columns, so no adapter  # to dicts

    # ===================== Job state (the job_* columns on the conversation row) ==================
    def start_job(
        self, user_id: str, conv_id: str, job_id: str, baseline: str = None
    ) -> None:
        """Mark the conversation's job as just-started (running).

        What this method does:
            - Sets job_id, job_status=running, a placeholder message, clears job_output, and
              stamps both job_started_at and last_updated_at.

        Why it exists:
            - `baseline` is the trigger-time timestamp (see JobRunner.baseline_stamp);
              check_status uses it to tell OUR fresh result from a stale run-state row.

        Security and production notes:
            1. job_output is explicitly set to NULL, so a re-run cannot show the PREVIOUS
               run's device output while the new one is still in flight.
            2. job_started_at is what JOB_TIMEOUT_MINUTES is measured from, in wall-clock
               time -- so a user who closes their browser still has their job expire.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation the job belongs to.
            job_id: The id the agent returned from start().
            baseline: Trigger-time stamp used to reject a stale run-state row.

        Returns:
            None.

        Example:
            >>> repo.start_job("u1", "c1", "job-42", baseline="2026-09-09T10:00:00+00:00")  # doctest: +SKIP
        """
        now = now_iso()  # One stamp for both job_started_at and last_updated_at                     # stamp
        self._cursor().execute(  # Targeted UPDATE: touches ONLY the job_* columns + the stamp       # update
            "UPDATE conversations SET job_id = ?, job_status = ?, job_message = ?, "
            "job_output = NULL, job_baseline = ?, job_started_at = ?, "
            "last_updated_at = ? WHERE user_id = ? AND id = ?",
            (job_id, JOB_RUNNING, "Starting...", baseline, now, now, user_id, conv_id),  # All bound  # values
        )
        self._commit()  # Commits now, or defers to the caller's transaction() block                 # commit

    def find_running(self, limit: int, stale_before: str) -> list:
        """Running jobs that nobody has touched since `stale_before` -- the reaper's list.

        What this method does:
            - Runs the dialect-appropriate query for rows whose job_status is running, whose
              stage is one of the two RUNNING stages, and whose last_updated_at is older
              than `stale_before`; capped at `limit` and ordered oldest-touched first.

        Why it exists:
            - `stale_before` is an ISO-8601 UTC timestamp; anything updated more recently is
              assumed to have a browser watching it and is skipped. This only FINDS them;
              the caller decides what to do with each.

        Security and production notes:
            1. The staleness filter is what keeps the reaper a backstop rather than a second
               poller -- see the comment above _FIND_RUNNING_FROM for why the ordering
               matters too.
            2. `limit` bounds how long one sweep can run; a backlog drains over the next few
               sweeps rather than making a single sweep unbounded.

        Args:
            limit: Maximum rows to return (Settings.REAPER_BATCH_SIZE).
            stale_before: ISO-8601 UTC cut-off; only rows older than this are returned.

        Returns:
            One dict per stale job, with user_id, id and job_started_at.

        Example:
            >>> repo.find_running(50, "2026-09-09T09:58:00+00:00")  # doctest: +SKIP
            [{'user_id': 'u1', 'id': 'c1', 'job_started_at': '...'}]
        """
        cur = self._cursor()  # Fresh cursor on the reaper's own connection                          # cursor
        # TOP (?) comes BEFORE the WHERE values in T-SQL; LIMIT ? comes after them.
        where = (JOB_RUNNING, DIAGNOSTICS_RUNNING, TROUBLESHOOT_RUNNING, stale_before)  # Shared tuple  # where vals
        if self._use_sqlite:  # SQLite: the limit is the LAST bound value                            # sqlite?
            cur.execute(self._SQL_FIND_RUNNING_SQLITE, where + (limit,))  # LIMIT ? at the end       # sqlite exec
        else:  # T-SQL: the limit is the FIRST bound value                                           # azure
            cur.execute(self._SQL_FIND_RUNNING_AZURE, (limit,) + where)  # TOP (?) up front          # azure exec
        return fetchall_dicts(cur)  # Oldest-touched first, so nobody is starved                     # to dicts

    def update_job_message(self, user_id: str, conv_id: str, message: str) -> None:
        """Record the progress line for one still-running poll. ONE column, ONE statement.

        What this method does:
            - Updates job_status, job_message and last_updated_at, and nothing else.

        Why it exists:
            - This used to be two calls and two commits -- update_job_message + save() --
              because the poll COUNTER lived inside vars. Expiry is now measured from
              job_started_at in wall-clock time, so there is no counter, nothing to write
              into vars, and nothing that can be left half-updated.

        Security and production notes:
            1. It also does not touch question/answer. save() used to stamp
               question="[job-poll]" over the user's real last message on every poll.
               Nothing reads those columns -- the transcript lives in conversation_turns --
               so it was pure noise.
            2. Bumping last_updated_at here is what keeps an actively-watched job out of the
               reaper's find_running() result set.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation whose job is still running.
            message: The user-safe progress line to store.

        Returns:
            None.

        Example:
            >>> repo.update_job_message("u1", "c1", "Still running...")  # doctest: +SKIP
        """
        self._cursor().execute(  # Targeted UPDATE: three columns, nothing else                      # update
            "UPDATE conversations SET job_status = ?, job_message = ?, "
            "last_updated_at = ? WHERE user_id = ? AND id = ?",
            (JOB_RUNNING, message, now_iso(), user_id, conv_id),  # All values bound with ?          # values
        )
        self._commit()  # Commits now, or defers to the caller's transaction() block                 # commit

    def advance_after_job(
        self,
        user_id: str,
        conv_id: str,
        *,
        expected_stage: str,
        new_stage: str,
        flow_vars: dict,
        question: str,
        answer: str,
        job_status: str,
        job_message: str,
        job_output=None,
    ) -> bool:
        """Move the conversation off a RUNNING stage and record the job outcome.

        What this method does:
            - Runs ONE conditional UPDATE that writes the new stage, the flow vars, the turn
              text, the job outcome and the promoted columns, but only while the row is
              still on `expected_stage`. Returns whether it matched a row.

        Why it exists:
            - This is ONE conditional UPDATE, and that is the whole point. It replaces the
              old finish_job/fail_job + save pair, which wrote the job outcome and the new
              stage separately -- so a crash between them left job_status='done' with the
              stage never advanced.

        Security and production notes:
            1. The `AND stage = ?` in the WHERE clause is a compare-and-swap: only the FIRST
               caller still sees the RUNNING stage and updates 1 row. A second poller -- two
               browser tabs, a refresh mid-poll, another worker process, or the reaper
               running on a second instance -- updates 0 rows and must NOT advance the flow
               or write the transcript again.
            2. Call it inside transaction() together with append_turns, so the stage move
               and the transcript rows commit as one unit. A concurrent caller then blocks
               on the row lock and correctly sees 0 rows once the winner commits.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation to advance.
            expected_stage: The RUNNING stage the row must still be on; the CAS condition.
            new_stage: The stage to move to.
            flow_vars: The flow's variables after the job completed.
            question: The turn's question text to store.
            answer: The turn's answer text to store.
            job_status: Terminal job status to record (done / failed).
            job_message: User-safe outcome line.
            job_output: RAW device output; stored, never returned to a browser.

        Returns:
            True if this caller won the race, False if another caller already advanced it.

        Example:
            >>> repo.advance_after_job("u1", "c1", expected_stage="DIAGNOSTICS_RUNNING",
            ...     new_stage="AWAITING_PROCEED", flow_vars={}, question="q", answer="a",
            ...     job_status="done", job_message="ok")  # doctest: +SKIP
            True
        """
        now = now_iso()  # One stamp for last_updated_at and a possible ended_at                     # stamp
        # Same split as _upsert: the ServiceNow ids and the outcome flags go to their own
        # columns, and only what is left is serialized into `vars`. A job finishing can
        # end the conversation outright (a failed diagnostic routes to the support team),
        # so escalated/resolved must be written on this path too.
        promoted, vars_json = _split_vars(flow_vars)  # One copy of each value, never two            # split vars
        cur = self._cursor()  # Fresh cursor; rowcount below is this statement's                     # cursor
        cur.execute(
            self._SQL_ADVANCE_AFTER_JOB,
            (
                new_stage, vars_json, question, answer,  # Stage + flow state + turn text            # set cols
                job_status, job_message, job_output,  # Job outcome; output is support-only          # set cols
                now,  # last_updated_at                                                              # set col
                now if new_stage == DONE else None,  # ended_at, made write-once by COALESCE         # set col
                promoted["interaction_id"], promoted["incident_id"],  # Promoted ServiceNow ids      # set cols
                promoted["resolved"], promoted["escalated"],  # Promoted outcome flags, as 0/1       # set cols
                user_id, conv_id, expected_stage,  # WHERE: primary key + the CAS condition          # where
            ),
        )
        won = cur.rowcount == 1  # 1 = we won the race; 0 = somebody already advanced it             # won race?
        self._commit()  # Commits now, or defers to the caller's transaction() block                 # commit
        return won  # The caller must not write the transcript again when this is False              # return won

    def get_job(self, user_id: str, conv_id: str) -> dict:
        """Return {job_id, job_status, job_message, job_baseline, job_started_at}.

        What this method does:
            - Selects the job_* columns EXCEPT job_output, as a dict; {} when no row.

        Why it exists:
            - job_output is deliberately excluded -- see _SQL_JOB. This method feeds
              user-facing paths, and raw device output must never reach the browser.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation whose job state to read.

        Returns:
            The job columns as a dict, or {} when the conversation does not exist.

        Example:
            >>> repo.get_job("u1", "c1")["job_status"]  # doctest: +SKIP
            'running'
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_JOB, (user_id, conv_id))  # job_output is NOT in this SELECT           # select
        return fetchone_dict(cur) or {}  # {} so callers can .get() without a None check             # to dict

    def load_job_output(self, user_id: str, conv_id: str):
        """The raw device script output, for SUPPORT use only.

        What this method does:
            - Selects the single job_output column and returns its value, or None.

        Why it exists:
            - Deliberately a separate method from get_job(): nothing on a user-facing path
              should be able to read this column by accident.

        Security and production notes:
            1. IF YOU CALL THIS, THE VALUE MUST NOT END UP IN AN HTTP RESPONSE. It carries
               profile paths, mailbox addresses and internal host names.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation whose device output to read.

        Returns:
            The raw output text, or None when there is none.

        Example:
            >>> repo.load_job_output("u1", "c1")  # doctest: +SKIP
            'Outlook profile C:\\\\Users\\\\... repaired'
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_JOB_OUTPUT, (user_id, conv_id))  # One column, both values bound       # select
        row = cur.fetchone()  # (value,) or None                                                     # fetch row
        return row[0] if row else None  # None when the conversation does not exist                  # return text
