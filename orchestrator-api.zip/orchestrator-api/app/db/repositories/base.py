####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The shared connection, commit and transaction handling every repository inherits.                #
#   1. Hold the request's single open connection, so no call site threads `conn` around.           #
#   2. _commit(): commit a lone write immediately, but defer inside a transaction() block.         #
#   3. transaction(): group several writes into ONE commit -- all of them, or none.                #
#   4. now_iso(): one clock and one format for every timestamp column in every table.              #
#                                                                                                  #
# Source:-                                                                                         #
#   - contextlib.contextmanager turns transaction() into a `with` block that commits on success    #
#       and rolls back on any exception.                                                           #
#   - datetime (UTC) provides the single ISO-8601 timestamp format every table stores.             #
####################################################################################################
"""Shared connection, commit and transaction handling for the repositories.

What this module is:
    - BaseRepository, which every repository subclasses, plus now_iso(), the one timestamp
      helper they all write with.

Why this exists:
    - Holding the connection is what makes the repositories classes rather than functions:
      it stops every call site threading `conn` (and usually `user_id`) through as
      parameters, and it gives the transaction boundary somewhere to live.

Security and production notes:
    1. The connection is the REQUEST's connection, shared by every repository built for
       that request -- so `transaction()` on one repository is the same database
       transaction as a write through another. That is deliberate, and it is why
       AgentCallRepository and ApiRequestRepository must NOT be called inside a
       transaction() block (see their own docstrings).
    2. No SQL lives here. This class only owns the connection lifecycle, so a subclass
       cannot accidentally inherit a statement it did not declare.
"""

# ============================================ Imports =============================================
from contextlib import contextmanager  # Turns transaction() into a commit/rollback `with` block     # stdlib ctx
from datetime import datetime, timezone  # UTC clock behind now_iso()                                # stdlib datetime


# ========================================== Time helper ===========================================
def now_iso() -> str:
    """Current time as an ISO-8601 UTC string (how every timestamp column is stored).

    What this function does:
        - Returns datetime.now(timezone.utc).isoformat(), i.e. an offset-aware UTC stamp.

    Why it exists:
        - Public (no underscore) because every repository module uses it: timestamps are
          written by the repository rather than the caller, so that "when did this happen?"
          means one clock and one format across every table.

    Security and production notes:
        1. Always UTC, never local time. App Service instances and Azure SQL can disagree
           about the local zone, and the reaper's staleness comparison would be wrong if a
           row were ever written with a local stamp.

    Returns:
        The current UTC time as an ISO-8601 string.

    Example:
        >>> now_iso()  # doctest: +SKIP
        '2026-09-09T11:22:33.123456+00:00'
    """
    return datetime.now(timezone.utc).isoformat()  # UTC only: instances disagree on local time      # utc stamp


# ======================================== Base repository =========================================
class BaseRepository:
    """Shared connection and commit handling for the repositories.

    What this class is:
        - The connection holder: a cursor factory, a commit that respects an enclosing
          transaction, and the transaction() context manager itself.

    Why it exists:
        - So the commit convention is defined once. Every write method in every repository
          calls self._commit(), which means a lone write still commits on its own while a
          group wrapped in transaction() commits exactly once.

    Security and production notes:
        1. `_in_transaction` is per INSTANCE, so the flag reflects this repository's own
           block. Because repositories for one request share a connection, an outer
           transaction() on one of them still governs the underlying database transaction.
        2. Never hold a transaction across an agent call -- an open transaction holds row
           locks, and an agent call can take minutes.

    Example:
        >>> repo = BaseRepository(conn)  # doctest: +SKIP
        >>> with repo.transaction(): pass  # doctest: +SKIP
    """

    def __init__(self, conn) -> None:
        """Adopt the request's open connection; open nothing of our own.

        Args:
            conn: An open DB-API 2.0 connection, created per request by Database.connect().

        Returns:
            None.
        """
        self._conn = conn  # The REQUEST's connection, shared with the other repositories            # connection
        self._in_transaction = False  # True only inside our own transaction() block                 # txn flag

    def _cursor(self):
        """A fresh cursor on the shared connection."""
        return self._conn.cursor()  # Cheap; a statement takes its own cursor                        # new cursor

    def _commit(self) -> None:
        """Commit this write -- unless we are inside a transaction() block.

        What this method does:
            - Calls conn.commit() only when no transaction() block is open.

        Why it exists:
            - Every write method calls this instead of conn.commit() directly, so a single
              write still commits on its own (as before), but a group of writes wrapped in
              transaction() commits exactly once, at the end.

        Returns:
            None.
        """
        if not self._in_transaction:  # Lone write -> commit now, as callers expect                  # in a txn?
            self._conn.commit()  # Inside a block, the outermost transaction() commits instead       # commit

    @contextmanager  # Makes transaction() usable as `with repo.transaction():`
    def transaction(self):
        """Group several writes into ONE commit -- all of them, or none.

        What this method does:
            - Sets the deferral flag, yields, then commits on success or rolls back and
              re-raises on any exception. A nested call yields without taking ownership, so
              the OUTERMOST block is the one that commits.

        Why it exists:
            - Used by the service layer around the write sequences that must agree with each
              other (completing a job; persisting a chat turn). Without it, each write
              committed separately, so a crash part-way through left the conversation row
              advanced but its transcript rows missing.

        Security and production notes:
            1. Open this as LATE as possible and keep it short: an open transaction holds
               locks on the row, so it must never wrap an agent call.
            2. The flag is cleared in a `finally`, so a rolled-back block does not leave the
               repository permanently deferring commits.

        Yields:
            This repository, so `with repo.transaction() as r:` reads naturally.

        Raises:
            Exception: Re-raises whatever the block raised, after rolling back.

        Example:
            >>> with repo.transaction():  # doctest: +SKIP
            ...     repo.save_state(...)
        """
        if self._in_transaction:  # Nested block: the outermost one owns the commit                  # already in?
            yield self  # already inside one -- the outermost block owns the commit                  # pass through
            return  # Do NOT commit or clear the flag; that belongs to the outer block               # defer
        self._in_transaction = True  # Make every _commit() in the block a no-op                     # take ownership
        try:  # Run the caller's writes                                                              # run block
            yield self  # The body performs its writes through this (or a sibling) repository        # yield repo
            self._conn.commit()  # All of them, in one commit                                        # commit all
        except Exception:  # Any failure -> none of them                                             # block failed
            self._conn.rollback()  # Discard the partial work                                        # rollback
            raise  # The caller still sees the original exception                                    # re-raise
        finally:  # Always clear, or the repository would defer commits forever                      # always
            self._in_transaction = False  # Back to commit-per-write behaviour                       # release
