####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# All SQL for the sessions table -- the chat list in the frontend's left panel.                    #
#   1. load(): read one session row by user_id + session_id.                                       #
#   2. save(): point a session at its current conversation and bump last_updated_at.               #
#   3. _upsert(): UPDATE-then-INSERT-on-miss, so one code path works on both engines.              #
#   4. list_recent(): the sidebar -- up to 20 still-active sessions, newest first.                 #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.db.database supplies fetchone_dict / fetchall_dicts, turning cursor tuples into dicts.   #
#   - app.db.repositories.base supplies the shared connection, _commit() and now_iso().            #
#   - typing.Optional marks load() as possibly finding no row.                                     #
####################################################################################################
"""sessions: the chat sessions shown in the frontend's left panel.

What this module is:
    - SessionRepository: two reads, one upsert, and the statements they use.

Why this exists:
    - A session is the frontend's grouping of conversations. It exists mainly to answer
      "what should the left panel show, and in what order?".

Security and production notes:
    1. Every statement is scoped by user_id, so one user's id can never list or overwrite
       another user's sessions.
    2. list_recent() has TWO dialect variants because the row limit is the one thing SQLite
       and Azure SQL spell differently (LIMIT vs TOP); both must be edited together.
"""

# ============================================ Imports =============================================
from typing import Optional  # load() may legitimately find no row                                   # stdlib typing

from app.db.database import fetchall_dicts, fetchone_dict  # Cursor tuples -> name-keyed dicts       # row adapters
from app.db.repositories.base import BaseRepository, now_iso  # Shared connection + UTC clock        # base repo


# ======================================= Session repository =======================================
class SessionRepository(BaseRepository):
    """sessions: the chat sessions shown in the frontend's left panel.

    What this class is:
        - The owner of the sessions table: the row that names a chat, points at its current
          conversation, and carries the timestamp the sidebar is ordered by.

    Why it exists:
        - So "which chats does this user see, and which is on top?" is one query rather
          than logic spread across the service layer.

    Security and production notes:
        1. Takes `use_sqlite` because list_recent() needs a row limit, and that is the one
           thing the two dialects spell differently (LIMIT vs TOP).
        2. The sidebar query is capped at 20 rows, so a user with hundreds of sessions
           cannot make the left panel an unbounded read.

    Example:
        >>> SessionRepository(conn, use_sqlite=True).list_recent("u1")  # doctest: +SKIP
    """

    # Same two names as conversations, for the same reasons:
    #   started_at       when the session was first created. Written once, never moves.
    #   last_updated_at  bumped every time the session is pointed at a new turn. The
    #                    sidebar is ordered by it, so it is what puts the chat a user
    #                    just spoke in at the top of their list.
    #
    # There is deliberately NO ended_at here. A session has no terminal state of its own
    # -- it drops off the sidebar when its CURRENT conversation reaches DONE, which is
    # what the LEFT JOIN below tests. Adding one would need a second rule about what
    # "ending" a session even means.
    _COLS = (  # Shared column list, so load()'s shape is declared in exactly one place              # column list
        "id, session_id, user_id, current_conversation_id, title, "
        "started_at, last_updated_at"
    )
    _SQL_LOAD = "SELECT " + _COLS + " FROM sessions WHERE user_id = ? AND id = ?"  # By primary key  # load sql
    _SQL_UPDATE = (  # Half of the upsert; tried first, because a refresh is the common case         # update sql
        "UPDATE sessions SET session_id = ?, current_conversation_id = ?, "
        "title = ?, started_at = ?, last_updated_at = ? WHERE user_id = ? AND id = ?"
    )
    _SQL_INSERT = (  # Other half of the upsert; only runs when the UPDATE matched no row            # insert sql
        "INSERT INTO sessions (id, session_id, user_id, current_conversation_id, "
        "title, started_at, last_updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
    )
    # Sidebar list. Excludes sessions whose current conversation has ended
    # (stage = DONE), so ended chats drop off the left panel. The row limit is spelled
    # differently per dialect (LIMIT vs TOP), hence the two statements.
    _LIST_COLS = (  # Aliased to s. because the sidebar query joins conversations                    # list columns
        "s.id, s.session_id, s.current_conversation_id, s.title, "
        "s.started_at, s.last_updated_at"
    )
    _LIST_FROM = (  # LEFT JOIN, so a session whose conversation row is missing still shows          # list from
        "FROM sessions s "
        "LEFT JOIN conversations c "
        "  ON c.user_id = s.user_id AND c.id = s.current_conversation_id "
        "WHERE s.user_id = ? AND (c.stage IS NULL OR c.stage <> 'DONE') "
    )
    _SQL_LIST_SQLITE = (  # SQLite dialect: LIMIT goes at the END of the statement                   # sqlite sql
        "SELECT " + _LIST_COLS + " " + _LIST_FROM
        + "ORDER BY s.last_updated_at DESC LIMIT 20"
    )
    _SQL_LIST_AZURE = (  # T-SQL dialect: TOP goes immediately after SELECT                          # azure sql
        "SELECT TOP 20 " + _LIST_COLS + " " + _LIST_FROM
        + "ORDER BY s.last_updated_at DESC"
    )

    def __init__(self, conn, use_sqlite: bool) -> None:
        """Adopt the request's connection and remember which SQL dialect to use.

        Args:
            conn: The request's open DB-API 2.0 connection.
            use_sqlite: True to use the LIMIT variant, False for the TOP variant.

        Returns:
            None.
        """
        super().__init__(conn)  # BaseRepository owns the connection and the commit rule             # base init
        self._use_sqlite = use_sqlite  # Picks the LIMIT vs TOP variant in list_recent()             # dialect

    # ============================================= Reads ==========================================
    def load(self, user_id: str, session_id: str) -> Optional[dict]:
        """Load one session row (by user_id + session_id) as a dict, or None.

        Args:
            user_id: Owner of the session; part of the primary key.
            session_id: The session to read.

        Returns:
            The row as a name-keyed dict, or None when it does not exist.

        Example:
            >>> repo.load("u1", "s1")  # doctest: +SKIP
            {'id': 's1', 'title': 'Outlook will not open'}
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_LOAD, (user_id, session_id))  # Both values bound with ?               # select
        return fetchone_dict(cur)  # None when the session does not exist yet                        # to dict

    def list_recent(self, user_id: str) -> list:
        """A user's most recent still-active sessions (up to 20), newest first.

        What this method does:
            - Runs the dialect-appropriate sidebar query: a LEFT JOIN that drops sessions
              whose current conversation has reached DONE, ordered by last_updated_at.

        Why it exists:
            - This IS the left panel. Ordering by last_updated_at is what puts the chat the
              user just spoke in at the top of their list.

        Security and production notes:
            1. Capped at 20 rows, so the sidebar can never become an unbounded read.
            2. The two dialect variants must be kept in step; only the row limit differs.

        Args:
            user_id: Owner whose sessions to list.

        Returns:
            Up to 20 session dicts, most recently updated first.

        Example:
            >>> repo.list_recent("u1")  # doctest: +SKIP
            [{'id': 's2', 'title': 'Outlook crashes'}, {'id': 's1', 'title': 'No mail'}]
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(
            self._SQL_LIST_SQLITE if self._use_sqlite else self._SQL_LIST_AZURE,  # LIMIT vs TOP     # dialect
            (user_id,),  # The only bound value; the row limit is a literal in the statement         # bind user
        )
        return fetchall_dicts(cur)  # Newest first; empty list for a brand-new user                  # to dicts

    # ============================================= Writes =========================================
    def save(
        self, user_id: str, session_id: str, current_conversation_id: str, title: str
    ) -> None:
        """Save/refresh a session: point it at the current conversation and bump
        last_updated_at, preserving the original started_at and title.

        What this method does:
            - Reads any existing row, then upserts with a fresh last_updated_at while
              keeping the ORIGINAL started_at and title when one already exists.

        Why it exists:
            - started_at and title are "first write wins" values. Re-supplying them on
              every turn would otherwise let a later turn's question rename the chat in the
              user's sidebar.

        Security and production notes:
            1. The read-then-upsert is not atomic, but both writers of a session are the
               same user's own turns, so the worst case is a redundant identical write.

        Args:
            user_id: Owner of the session.
            session_id: The session to save; also used as its `id`.
            current_conversation_id: The conversation this session is now pointing at.
            title: Title to use ONLY if the session is being created now.

        Returns:
            None.

        Example:
            >>> repo.save("u1", "s1", "c1", "Outlook will not open")  # doctest: +SKIP
        """
        now = now_iso()  # One stamp, used for both last_updated_at and a first started_at           # stamp
        existing = self.load(user_id, session_id) or {}  # {} means "creating it now"                # read current
        self._upsert(
            {
                "id": session_id,  # Primary key, together with user_id                              # id
                "session_id": session_id,  # Kept as its own column for the FE's convenience         # session id
                "user_id": user_id,  # Owner; scopes every statement in this class                   # user id
                "current_conversation_id": current_conversation_id,  # What the panel opens          # current conv
                "last_updated_at": now,  # Bumped every turn -- the sidebar's sort key               # updated at
                "started_at": existing.get("started_at", now),  # First write wins                   # started at
                "title": existing.get("title", title),  # First write wins, so chats keep their name  # title
            }
        )

    def _upsert(self, item: dict) -> None:
        """Insert or update a session row -- same update-then-insert as the
        conversation upsert, but for the sessions table.

        What this method does:
            - Tries the UPDATE by primary key; if it matched no row (rowcount == 0),
              INSERTs instead. Then commits via _commit(), which defers inside a
              transaction() block.

        Why it exists:
            - UPDATE-then-INSERT-on-miss is dialect-neutral, so ONE code path works on both
              SQLite and Azure SQL. A MERGE statement would need two variants.

        Security and production notes:
            1. Every value is bound with ?; the statements are class constants, never built
               with an f-string at the execute() call.

        Args:
            item: The full row as a dict, already resolved by save().

        Returns:
            None.
        """
        cur = self._cursor()  # One cursor for both statements, so rowcount refers to the UPDATE     # cursor
        cur.execute(  # Try the UPDATE first: a refresh is far more common than a create             # try update
            self._SQL_UPDATE,
            (
                item.get("session_id"), item.get("current_conversation_id"),  # Pointer fields       # set cols
                item.get("title"), item.get("started_at"),  # First-write-wins values                # set cols
                item.get("last_updated_at"),  # The sidebar's sort key                               # set col
                item.get("user_id"), item.get("id"),  # WHERE: the primary key                       # where
            ),
        )
        if cur.rowcount == 0:  # No such session yet -> create it                                    # existed?
            cur.execute(
                self._SQL_INSERT,
                (
                    item.get("id"), item.get("session_id"), item.get("user_id"),  # Keys             # insert vals
                    item.get("current_conversation_id"), item.get("title"),  # Pointer + name        # insert vals
                    item.get("started_at"), item.get("last_updated_at"),  # Both stamps              # insert vals
                ),
            )
        self._commit()  # Commits now, or defers to the caller's transaction() block                 # commit
