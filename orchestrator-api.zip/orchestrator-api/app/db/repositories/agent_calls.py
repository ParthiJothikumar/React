####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# All SQL for the agent_calls table -- the internal trace of every agent call we make.             #
#   1. append_calls(): insert one row per traced call, in one round trip, never raising.           #
#   2. list_for_conversation(): read the full trace of one conversation, oldest first.             #
#   3. Commit on its OWN, never inside the caller's transaction() -- see the ordering rule.        #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.core.config.logger records a dropped batch; this table never fails a user's request.     #
#   - app.db.database.fetchall_dicts turns the read's cursor tuples into name-keyed dicts.         #
#   - app.db.repositories.base supplies the shared connection and the now_iso() timestamp.         #
####################################################################################################
"""agent_calls: the internal trace of every agent call.

What this module is:
    - AgentCallRepository: one insert-many write and one read, plus the statements they use.

Why this exists:
    - The rows are collected in memory during the turn (see core/tracing.py) and flushed
      here in one go, so four agent calls cost one round trip rather than four.

Security and production notes:
    1. response_json holds RAW agent output, which for the device agents carries profile
       paths, mailbox addresses and internal host names. This table is for support and
       debugging only -- never expose it on a user-facing endpoint.
    2. Both write and read bind every value with ?; the statements are class constants
       assembled at class level, never f-strings at the execute() call.
"""

# ============================================ Imports =============================================
from app.core.config import logger  # Records a dropped batch; the request still succeeds            # config
from app.db.database import fetchall_dicts  # Cursor tuples -> name-keyed dicts on the read          # row adapter
from app.db.repositories.base import BaseRepository, now_iso  # Shared connection + UTC clock        # base repo


# ======================================== Agent-call trace ========================================
class AgentCallRepository(BaseRepository):
    """agent_calls: the internal trace of every agent call.

    What this class is:
        - An insert-only table (plus one read for support), holding the agent label,
          request, response, duration and error for every outbound agent call.

    Why it exists:
        - Insert-only, like append_turns -- but with two deliberate differences.
        - NO SEQ READ. append_turns has to run MAX(seq)+1 first because the FE replays
          turns in display order. Here the database assigns the id, so it is one statement
          instead of two and two concurrent pollers cannot pick the same number.
        - ITS OWN COMMIT, NOT THE CALLER'S TRANSACTION. Every other write in this package
          defers to transaction() so a turn commits once. This one must not: if the turn
          rolls back, the trace of the call that CAUSED the rollback would be rolled back
          with it, which destroys exactly the evidence the table exists to keep.

    Security and production notes:
        1. ORDERING RULE -- append_calls() must be called AFTER the turn's transaction()
           block has exited, never inside it. This repository shares the request's single
           connection, so its commit() is that connection's commit(). Called inside an open
           transaction() it would commit the caller's half-written work early -- silently
           defeating the all-or-nothing boundary that transaction() exists to provide.
           (Verified: a rollback after an inner append_calls() left the conversation row
           committed.)
           Called after the block, both cases are correct: the turn has already committed or
           already rolled back, so there is no in-flight work for this commit to catch. A
           `finally` around the turn is the right place -- it runs on the failure path too,
           which is when the trace matters most. TurnTimer does exactly that.
        2. response_json is raw agent output and can carry paths, addresses and host names,
           so list_for_conversation() is a support tool, not an endpoint.

    Example:
        >>> AgentCallRepository(conn).append_calls("u1", "c1", trace.rows)  # doctest: +SKIP
    """

    # -- Statements. Class constants assembled at class level, so no SQL is ever built with an
    # -- f-string at the execute() call; every user value below is bound with ?.
    _SQL_INSERT = (  # One row per traced call; the database assigns the id                          # insert sql
        "INSERT INTO agent_calls (user_id, conversation_id, agent, request_text, "
        "response_json, duration_ms, is_error, error_text, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    )
    _COLS = (  # Shared column list, so the read's shape is declared in exactly one place            # column list
        "id, agent, request_text, response_json, duration_ms, is_error, "
        "error_text, created_at"
    )
    _SQL_BY_CONVERSATION = (  # Ordered by id, which is also insertion order                         # select sql
        "SELECT " + _COLS + " FROM agent_calls "
        "WHERE user_id = ? AND conversation_id = ? ORDER BY id ASC"
    )

    def append_calls(self, user_id: str, conv_id: str, calls) -> None:
        """Write one row per agent call. Never raises.

        What this method does:
            - Returns immediately on an empty list; otherwise stamps one timestamp for the
              whole batch, inserts each row, and commits directly on the connection.

        Why it exists:
            - `calls` is a list of dicts, each {agent, request_text, response_json,
              duration_ms, is_error, error_text} -- collected during the turn and flushed
              here in one go, so four agent calls cost one round trip rather than four.

        Security and production notes:
            1. Swallows its own failures on purpose. This is a logging table: if the insert
               fails, the turn the user is waiting on must still succeed. A tracing table
               that can take the product down is a bad trade, so the exception is logged and
               dropped.
            2. self._conn.commit() is called DIRECTLY, not self._commit(), because this row
               must survive a rolled-back turn -- which is exactly why the ordering rule in
               the class docstring exists.

        Args:
            user_id: Owner of the conversation; part of every key in this schema.
            conv_id: The conversation these calls belong to.
            calls: List of row dicts from CallTrace.rows; an empty list is a no-op.

        Returns:
            None.

        Example:
            >>> repo.append_calls("u1", "c1", [{"agent": "snow", "duration_ms": 40}])  # doctest: +SKIP
        """
        if not calls:  # Nothing traced this turn -> no round trip at all                            # any rows?
            return  # The common case for a status poll that dropped its row                         # skip
        now = now_iso()  # ONE stamp for the whole batch, so the rows sort together                  # batch stamp
        try:  # Best-effort: a trace failure must never fail the user's turn                         # write try
            cur = self._cursor()  # One cursor reused for every row in the batch                     # cursor
            for call in calls:  # One INSERT per traced call, in a single round trip                 # each call
                cur.execute(
                    self._SQL_INSERT,
                    (
                        user_id,  # Bound, never interpolated                                        # user id
                        conv_id,  # Bound, never interpolated                                        # conv id
                        call.get("agent") or "unknown",  # Should always be Agent.label now          # agent
                        call.get("request_text"),  # Already capped by tracing._field                # request
                        call.get("response_json"),  # Already capped by tracing._field               # response
                        int(call.get("duration_ms") or 0),  # Never NULL: the column is NOT NULL     # duration
                        1 if call.get("is_error") else 0,  # 0/1 reads the same on both engines      # error flag
                        call.get("error_text"),  # Includes the ORIGINAL cause, per tracing          # error text
                        now,  # Same stamp for every row in this batch                               # created at
                    ),
                )
            self._conn.commit()  # DIRECT commit, not _commit(): must survive a rolled-back turn     # commit
        except Exception:  # Drop the trace rather than break the turn being traced                  # write failed
            logger.exception(  # Record how many rows were lost, and for which conversation          # log drop
                "could not write agent_calls trace conv_id=%s (%d row(s) dropped)",
                conv_id, len(calls),
            )

    def list_for_conversation(self, user_id: str, conv_id: str) -> list:
        """The full trace for one conversation, oldest first -- for support/debugging.

        What this method does:
            - Selects every agent_calls row for one user's conversation, ordered by id
              (which is insertion order), as a list of name-keyed dicts.

        Why it exists:
            - So a support engineer can see exactly which agents ran, in what order, how
              long each took and which one failed.

        Security and production notes:
            1. NOT for a user-facing endpoint: response_json holds raw agent output, which
               for the device agents carries profile paths, mailbox addresses and internal
               host names.
            2. Scoped by user_id as well as conversation_id, so one user's id cannot be used
               to read another user's trace.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation to read the trace for.

        Returns:
            One dict per call, oldest first; an empty list when nothing was traced.

        Example:
            >>> repo.list_for_conversation("u1", "c1")  # doctest: +SKIP
            [{'id': 1, 'agent': 'orchestrator', 'duration_ms': 812}]
        """
        cur = self._cursor()  # Fresh cursor on the request's shared connection                      # cursor
        cur.execute(self._SQL_BY_CONVERSATION, (user_id, conv_id))  # Both values bound with ?       # select
        return fetchall_dicts(cur)  # Name-keyed rows; empty list when nothing matched               # to dicts
