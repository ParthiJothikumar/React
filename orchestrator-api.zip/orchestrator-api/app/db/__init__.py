####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Package marker and map for `app.db`, the only package allowed to contain SQL.                    #
#   1. Declare app.db as a package so `from app.db.database import Database` resolves.             #
#   2. Name the three pieces: the connection factory, the repositories, and the SQL schema.        #
#   3. Record the two rules that keep persistence contained: no SQL outside this package, and      #
#        every statement must run on BOTH SQLite and Azure SQL.                                    #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported here; the package exposes its modules directly so a reader can see       #
#       which repository a call came from at the import site rather than through a re-export.      #
####################################################################################################
"""Persistence: the connection factory and every SQL statement in the app.

What this package is:
    - The three pieces that make up the state store:

        database.py      Database (connection factory), SQLITE_SCHEMA, row->dict adapters
        repositories/    one module per table group
        schema.sql       the Azure SQL schema, applied by hand / by release tooling

Why this exists:
    - NO SQL OUTSIDE THIS PACKAGE. That is the whole point of it: the services and the
      domain layer talk to repository methods, so a schema change has one blast radius,
      and reading "what does this app store?" means reading one folder.

Security and production notes:
    1. schema.sql and the SQLITE_SCHEMA string in database.py describe the SAME tables and
       must be changed together -- they live in one folder so that is obvious. SQLite has
       no BIT and no IDENTITY, which is the only reason there are two of them.
    2. It also runs on two engines. Every statement uses '?' placeholders and the upserts
       are UPDATE-then-INSERT-on-miss rather than dialect-specific MERGE, so the same code
       works against local SQLite and Azure SQL -- see the two dialect variants where a row
       limit is needed (LIMIT vs TOP).
    3. '?' placeholders are also the injection defence: no repository builds a statement by
       string interpolation, so a user-supplied value is always bound as a parameter.

Example:
    >>> from app.db.database import Database          # doctest: +SKIP
    >>> from app.db.repositories import ConversationRepository  # doctest: +SKIP
"""
