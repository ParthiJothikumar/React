####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Opens the per-request database connection and turns cursor tuples into dicts.                    #
#   1. Configure the Azure SQL driver's connection pool ONCE, before the first connection.         #
#   2. connect(): hand back a DB-API 2.0 connection to local SQLite or to Azure SQL.               #
#   3. SQLITE_SCHEMA: create the tables on first connect in SQLite mode, so tests need no setup.   #
#   4. fetchone_dict / fetchall_dicts: replace fragile row[3] indexing with row["stage"].          #
#                                                                                                  #
# Source:-                                                                                         #
#   - sqlite3 (standard library) backs the local file store; no driver or network is needed.       #
#   - mssql_python is imported LAZILY inside the two Azure SQL paths, so SQLite mode runs on a     #
#       machine with no SQL driver installed at all.                                               #
#   - app.core.config supplies Settings (which store, which pool size) and the shared logger.      #
#   - app.core.errors.DatabaseUnavailable is the one error every connection failure becomes.       #
####################################################################################################
"""Database class (connection factory) and row adapters.

What this module is:
    - Database.connect(), which opens a per-request DB-API 2.0 connection to either a
      local SQLite file (testing) or Azure SQL (production); both use '?' placeholders so
      every query in db/repositories/ works unchanged on either.

Why this exists:
    - Why a class: the SQLite "have I created the tables yet?" flag used to be a module
      global, which meant it could not be reset between tests and was shared by every code
      path in the process. As instance state on one object it has a clear owner and a
      lifecycle, and the object can be swapped for a stub.
    - The two row adapters stay module-level functions on purpose: they hold no state,
      they just zip a tuple against cur.description. Wrapping them in a class would add a
      `self` that never gets used.

Security and production notes:
    1. SQL_CONNECTION_STRING is a secret. It is never logged -- the failure paths below log
       a fixed message and raise DatabaseUnavailable, whose body main.py replaces with a
       generic line.
    2. SQLite is for TESTING only. On App Service the file lives on the instance's own
       disk, so it is not shared across instances and is lost on a restart or scale event.
    3. Total sessions against Azure SQL = SQL_POOL_MAX_SIZE x gunicorn workers x instances.
       Check the database tier's session limit before raising either number.
"""

# ============================================ Imports =============================================
import sqlite3  # Standard-library local file store used for testing; no driver needed               # stdlib sqlite3
from typing import Optional  # Optional[dict] on fetchone_dict, which may find no row                # stdlib typing

from app.core.config import Settings, logger  # Which store to use, plus the shared logger           # config
from app.core.errors import DatabaseUnavailable  # The single error a failed connect raises          # errors

# ========================================= SQLite schema ==========================================
# Schema for SQLite mode. Nobody runs scripts/setup_sqlite.py in a deployed app, so we
# create the tables on first connect (idempotent) to avoid "no such table".
# The column set MUST mirror schema.sql (Azure SQL) so test and prod don't drift.
SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT NOT NULL, user_id TEXT NOT NULL, conversation_id TEXT, stage TEXT,
    vars TEXT, question TEXT, answer TEXT, session_id TEXT, seq INTEGER,
    title TEXT,
    -- started_at:      set once, when the conversation begins
    -- last_updated_at: last activity of ANY kind; the reaper's staleness filter reads it
    -- ended_at:        set once, when the stage reaches DONE. NULL while still active
    started_at TEXT, last_updated_at TEXT, ended_at TEXT,
    -- ServiceNow references and the ending outcome: real columns, not keys inside vars
    -- (see schema.sql). SQLite has no BIT, so the flags are INTEGER 0/1 -- and
    -- `escalated = 1` reads the same on both engines.
    interaction_id TEXT, incident_id TEXT,
    resolved INTEGER NOT NULL DEFAULT 0,
    escalated INTEGER NOT NULL DEFAULT 0,
    job_id TEXT, job_status TEXT, job_message TEXT, job_output TEXT,
    job_baseline TEXT, job_started_at TEXT,
    PRIMARY KEY (user_id, id)
);
CREATE INDEX IF NOT EXISTS IX_conversations_user_session
    ON conversations (user_id, session_id);
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT NOT NULL, session_id TEXT, user_id TEXT NOT NULL,
    current_conversation_id TEXT, title TEXT,
    -- started_at: set once, when the session is created
    -- last_updated_at: bumped on every turn; the sidebar is ordered by it
    started_at TEXT, last_updated_at TEXT,
    PRIMARY KEY (user_id, id)
);
CREATE TABLE IF NOT EXISTS conversation_turns (
    user_id TEXT NOT NULL, conversation_id TEXT NOT NULL, seq INTEGER NOT NULL,
    role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT,
    PRIMARY KEY (user_id, conversation_id, seq)
);
-- One row per HTTP request we serve (see dbo.api_requests in schema.sql for why it is
-- its own table). duration_ms - agent_ms is our own overhead.
CREATE TABLE IF NOT EXISTS api_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL, conversation_id TEXT, endpoint TEXT NOT NULL,
    duration_ms INTEGER NOT NULL, agent_ms INTEGER,
    http_status INTEGER,
    is_error INTEGER NOT NULL DEFAULT 0,
    started_at TEXT
);
CREATE INDEX IF NOT EXISTS IX_api_requests_endpoint_time
    ON api_requests (endpoint, started_at);
-- Internal trace of agent calls (see dbo.agent_calls in schema.sql for the full
-- rationale). SQLite has no IDENTITY or BIT: AUTOINCREMENT assigns the id, and is_error
-- is an INTEGER holding 0/1 -- `is_error = 1` reads the same on both.
CREATE TABLE IF NOT EXISTS agent_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL, conversation_id TEXT NOT NULL, agent TEXT NOT NULL,
    request_text TEXT, response_json TEXT,
    duration_ms INTEGER NOT NULL,
    is_error INTEGER NOT NULL DEFAULT 0, error_text TEXT,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS IX_agent_calls_conversation
    ON agent_calls (user_id, conversation_id, id);
CREATE INDEX IF NOT EXISTS IX_agent_calls_agent_time
    ON agent_calls (agent, created_at);
"""


# ======================================= Connection factory =======================================
class Database:
    """Opens connections to the configured state store (SQLite or Azure SQL).

    What this class is:
        - A tiny factory: it decides WHICH engine to open based on Settings, configures the
          Azure SQL pool once, and hands back a fresh DB-API 2.0 connection per request.

    Why it exists:
        - So "which store are we on?" is answered in one place. Every repository takes a
          connection and never asks where it came from, which is what lets the same SQL
          run against a local file and against Azure SQL.

    Security and production notes:
        1. A new connection PER REQUEST keeps things thread-safe: FastAPI runs sync
           endpoints on a threadpool and gunicorn runs several worker processes.
        2. _sqlite_ready is instance state, not a module global, so a test can build a
           fresh Database and get the schema re-created instead of inheriting a stale flag.

    Example:
        >>> db = Database(Settings({"SQLITE_DB_PATH": ":memory:"}))  # doctest: +SKIP
        >>> conn = db.connect()  # doctest: +SKIP
    """

    def __init__(self, settings: Settings) -> None:
        """Record the settings and configure the driver pool before any connection exists.

        What this method does:
            - Stores the settings, clears the "SQLite tables created" flag, then calls
              _configure_pool() immediately.

        Why it exists:
            - The pool MUST be configured before the first connection (see
              _configure_pool), so it happens in the constructor rather than lazily.

        Args:
            settings: The parsed configuration deciding engine, pool size and idle timeout.

        Returns:
            None.
        """
        self._settings = settings  # Which store, which pool size, which idle timeout                # settings
        self._sqlite_ready = False  # "Have the SQLite tables been created?" -- per instance         # ddl flag
        self._configure_pool()  # Must run before the first connection is ever opened                # pool setup

    @property
    def use_sqlite(self) -> bool:
        """True when the configured store is a local SQLite file rather than Azure SQL."""
        return self._settings.use_sqlite  # Delegates to Settings, so there is one answer            # sqlite?

    def _configure_pool(self) -> None:
        """Set the driver's connection-pool limits once, at startup.

        What this method does:
            - In Azure SQL mode, calls mssql_python.pooling() with the configured max size
              and idle timeout, then logs the result. In SQLite mode it returns at once.

        Why it exists:
            - This MUST run before the first connection: mssql-python ignores pooling
              settings once any connection exists. deps.py builds this object when it is
              imported, which is well before the first request.

        Security and production notes:
            1. Deliberately best-effort. A missing or older driver logs a warning rather
               than raising, because raising here would abort app startup and take down
               every endpoint including the health check. If the driver genuinely isn't
               available, connect() raises DatabaseUnavailable per request -- which is the
               right place for that failure to surface.
            2. The driver's own defaults (max_size=100, idle_timeout=600) stay in effect if
               this fails, so the log line matters: 100 x workers x instances can exceed
               the database tier's session limit.

        Returns:
            None.

        Example:
            >>> Database(Settings({"SQLITE_DB_PATH": "local.db"}))._configure_pool()  # doctest: +SKIP
        """
        if self._settings.use_sqlite:  # SQLite mode: the SQL driver isn't needed or installed       # sqlite?
            return  # Nothing to configure; sqlite3 has no connection pool                           # skip pool
        try:  # Best-effort: a pooling failure must not abort app startup                            # config try
            import mssql_python  # Lazy: only needed in Azure SQL mode                               # lazy import

            mssql_python.pooling(  # Pin the ceiling explicitly so it is visible in code             # set pool
                max_size=self._settings.SQL_POOL_MAX_SIZE,  # Per-process connection ceiling         # max size
                idle_timeout=self._settings.SQL_POOL_IDLE_TIMEOUT,  # Reap unused connections        # idle secs
            )
            # max_size=45 doesn't open 45 connections at startup. It opens them on demand and
            # closes idle ones after idle_timeout.
            logger.info(  # Record the effective ceiling, for capacity review                        # log info
                "SQL connection pool configured: max_size=%s idle_timeout=%ss",
                self._settings.SQL_POOL_MAX_SIZE,
                self._settings.SQL_POOL_IDLE_TIMEOUT,
            )
        except Exception:  # Driver missing or too old -- warn, do not block startup                 # config failed
            logger.exception(  # The driver defaults now apply, which may exceed the tier            # log error
                "could not configure the SQL connection pool; the driver's own "
                "defaults (max_size=100, idle_timeout=600) remain in effect"
            )

    def connect(self):
        """Open a DB connection (local SQLite, or Azure SQL).

        What this method does:
            - In SQLite mode, opens the file and (on the first connect only) runs
              SQLITE_SCHEMA to create the tables. In Azure SQL mode, checks the connection
              string, lazily imports the driver, and connects.

        Why it exists:
            - When SQLITE_DB_PATH is set we open a local SQLite file (built into Python --
              no install/network/driver needed), ideal for offline testing. Otherwise we
              open Azure SQL via mssql_python + SQL_CONNECTION_STRING. Both are DB-API 2.0
              with '?' placeholders, so every repository query works on either.
            - A new connection per request keeps things thread-safe (FastAPI runs sync
              endpoints on a threadpool, and gunicorn runs several worker processes).

        Security and production notes:
            1. SQLite is for TESTING only. On App Service the file lives on the instance's
               own disk, so it is not shared across instances and is lost on a restart or a
               scale event. Use Azure SQL for anything that must persist.
            2. All three failure paths log a FIXED message and raise DatabaseUnavailable --
               the connection string is never interpolated into a log line or an error body.

        Returns:
            An open DB-API 2.0 connection to the configured store.

        Raises:
            DatabaseUnavailable: No connection string, driver not installed, or the Azure
                SQL connection attempt failed.

        Example:
            >>> Database(Settings({"SQLITE_DB_PATH": ":memory:"})).connect()  # doctest: +SKIP
        """
        if self.use_sqlite:  # Local file store: no driver, no network, no credential                # sqlite mode
            conn = sqlite3.connect(self._settings.SQLITE_DB_PATH)  # Open (or create) the file       # open file
            if not self._sqlite_ready:  # First connect in this process -> create the tables         # need ddl?
                conn.executescript(SQLITE_SCHEMA)  # Idempotent CREATE ... IF NOT EXISTS             # run ddl
                conn.commit()  # Persist the DDL before the caller runs any statement                # commit ddl
                self._sqlite_ready = True  # Skip the DDL on every later connect                     # mark ready
            return conn  # Ready for the repositories to use                                         # return conn

        conn_str = self._settings.SQL_CONNECTION_STRING  # SECRET: never logged or returned          # read conn str
        if not conn_str:  # Azure SQL mode with nothing to connect to                                # missing?
            logger.error("SQL_CONNECTION_STRING not configured")  # Fixed text, no value             # log error
            raise DatabaseUnavailable("SQL_CONNECTION_STRING not configured")  # -> 503              # raise 503

        # lazy import: only needed for Azure SQL, so SQLite mode runs without the
        # driver installed. `mssql-python` is in requirements.txt for deployment.
        try:  # Import the driver only on the path that actually needs it                            # import try
            import mssql_python  # Azure SQL driver, deployed via requirements.txt                   # sql driver
        except ImportError:  # Running in SQL mode on a machine without the driver                   # not installed
            logger.exception("mssql_python driver not installed")  # Names the missing dep           # log error
            raise DatabaseUnavailable("mssql_python driver not installed")  # -> 503                 # raise 503

        try:  # The connection attempt itself (network, auth, firewall)                              # connect try
            return mssql_python.connect(conn_str)  # Pooled by the driver, per _configure_pool       # connect
        except Exception:  # Unreachable, auth refused, firewall, tier session limit                 # connect failed
            logger.exception("Azure SQL connection failed")  # Fixed text; the trace has detail      # log error
            raise DatabaseUnavailable("Azure SQL connection failed")  # -> 503                       # raise 503


# ========================================== Row adapters ==========================================
def fetchone_dict(cur) -> Optional[dict]:
    """Return the row as a {column_name: value} dict, or None if no row.

    What this function does:
        - Fetches one row, then zips it against the column names from cur.description.

    Why it exists:
        - DB-API cursors hand back rows as plain tuples; we zip them with the column names
          so callers can use row["stage"] instead of fragile positional indexing like
          row[3]. Adding a column to a SELECT then cannot silently shift every index.

    Security and production notes:
        1. cur.description is only populated after a SELECT, so calling this after an
           INSERT/UPDATE is a programming error rather than a runtime fallback.

    Args:
        cur: A cursor on which a SELECT has already been executed.

    Returns:
        The first row as a dict, or None when the query matched nothing.

    Example:
        >>> fetchone_dict(cur)  # doctest: +SKIP
        {'stage': 'AWAITING_ISSUE', 'user_id': 'u1'}
    """
    row = cur.fetchone()  # One tuple, or None when nothing matched                                  # fetch row
    if row is None:  # No match -> let the caller decide (usually NotFound)                          # no row?
        return None  # Distinguishes "no row" from "a row of NULLs"                                  # return none
    cols = [c[0] for c in cur.description]  # Column names, in the cursor's own order                # get columns
    return dict(zip(cols, row))  # Name-keyed row, so callers never index positionally               # zip to dict


def fetchall_dicts(cur) -> list:
    """Return all rows as a list of {column_name: value} dicts (see fetchone_dict).

    What this function does:
        - Reads the column names once, then builds one dict per row.

    Why it exists:
        - Same reason as fetchone_dict, for the list queries (session lists, turn history,
          the reaper's batch of stale jobs).

    Security and production notes:
        1. This materialises the WHOLE result set in memory, so every caller must bound its
           query -- the reaper uses REAPER_BATCH_SIZE, the history queries are scoped to
           one user and session.

    Args:
        cur: A cursor on which a SELECT has already been executed.

    Returns:
        One dict per row; an empty list when the query matched nothing.

    Example:
        >>> fetchall_dicts(cur)  # doctest: +SKIP
        [{'seq': 1, 'role': 'user'}, {'seq': 2, 'role': 'assistant'}]
    """
    cols = [c[0] for c in cur.description]  # Read the column names once, not per row                # get columns
    return [dict(zip(cols, row)) for row in cur.fetchall()]  # Empty list when nothing matched       # zip all
