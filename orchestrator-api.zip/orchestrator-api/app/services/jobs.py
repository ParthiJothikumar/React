####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# JobService: advance a running diagnostics/troubleshoot job. One code path, two drivers.          #
#   1. advance_job(): what the FE's ~30s poll AND the reaper's sweep both call.                    #
#   2. _poll_status(): retry ONLY a transient blip; let a real failure surface at once.            #
#   3. _complete(): build the reply first, then ONE transaction whose UPDATE is the race guard.    #
#   4. sweep_running_jobs(): the reaper's batch, where one bad conversation never stops the rest.  #
#   5. Expire an overdue job on WALL-CLOCK time, so an abandoned job cannot run forever.           #
#                                                                                                  #
# Source:-                                                                                         #
#   - datetime / timedelta / timezone measure the wall-clock expiry and the staleness cut-off.     #
#   - app.core.config supplies Settings (the four job knobs) and the shared logger.                #
#   - app.core.constants supplies the stage, job-kind and job-status literals.                     #
#   - app.core.errors supplies AppError / NotFound / UpstreamTransient -- the retry decision is    #
#       expressed entirely by which of those is caught.                                            #
#   - app.services.payloads / timing supply the shared response shape and the per-request timer.   #
####################################################################################################
"""JobService: advancing a running diagnostics/troubleshoot job (what the poll drives).

What this module is:
    - One class plus one module-level helper (_is_overdue). Everything a device job needs
      between "started" and "the flow moved on" is here.

Why this exists:
    - There is no backend queue and no background loop. A job advances only when somebody
      asks -- the frontend's poll, or the reaper's sweep -- and BOTH go through
      advance_job(), so there is one code path, one set of behaviour and one set of tests.

Security and production notes:
    1. THE CONDITIONAL UPDATE IN _complete() IS THE RACE GUARD. Two browser tabs, a refresh
       mid-poll, another gunicorn worker, or the reaper on a second instance can all reach
       the same job. Exactly one wins; the losers re-read and report what the winner
       persisted, so the same messages are never written to the transcript twice.
    2. job_message is the USER-SAFE line. The raw device output is capped at
       MAX_JOB_OUTPUT and stored in job_output, which is never put into the response or the
       transcript -- see app/domain/run_state.py for why that split exists.
    3. Expiry is WALL-CLOCK from the trigger, not a poll count. The previous rule counted
       polls, and a poll only happens while a browser is open, so a user who closed their
       tab never accumulated any and the conversation stayed RUNNING forever.
"""

# ============================================ Imports =============================================
from datetime import datetime, timedelta, timezone  # Wall-clock expiry + staleness cut-off          # stdlib datetime
from typing import Optional  # session_id is optional: the reaper has no session context             # stdlib typing

from app.core.config import Settings, logger  # The four job knobs, and the shared logger            # config
from app.core.constants import (  # Stage, job-kind and job-status literals                          # constants
    DIAGNOSTICS_RUNNING,  # One of the two stages a job can be polled from                           # stage
    JOB_DONE,  # job_status written on success                                                       # job status
    JOB_FAILED,  # job_status written on failure OR expiry                                           # job status
    JOB_KIND_DIAGNOSTIC,  # Dispatch key derived from the stage                                      # job kind
    JOB_KIND_TROUBLESHOOT,  # Dispatch key derived from the stage                                    # job kind
    JOB_TERMINAL,  # Membership test for "stop polling this job"                                     # status set
    TROUBLESHOOT_RUNNING,  # The other stage a job can be polled from                                # stage
)
from app.core.errors import AppError, NotFound, UpstreamTransient  # The retry decision              # errors
from app.services.payloads import job_payload, join, visible  # Shared response shaping              # payloads
from app.services.timing import TurnTimer  # Per-request measurement for both timing tables          # timer

# =========================================== Constants ============================================
# Cap on the raw device output we store, so one runaway script can't bloat a row.
MAX_JOB_OUTPUT = 8000  # Characters of device output kept in conversations.job_output                # size cap


# ========================================== Expiry rule ===========================================
def _is_overdue(job_started_at, timeout_minutes: int) -> bool:
    """True when a job was triggered longer ago than we are willing to wait.

    What this function does:
        - Parses the trigger stamp, assumes UTC if it carries no zone, and compares the
          elapsed wall-clock time against the timeout.

    Why it exists:
        - Wall-clock, measured from the trigger -- which is the whole point. The previous
          rule counted polls, and a poll only happens while a browser is open, so a user
          who closed their tab never accumulated any and the conversation stayed RUNNING
          forever.

    Security and production notes:
        1. A missing or unparseable timestamp returns False: better to keep waiting (the
           reaper will look again next sweep) than to fail a job that may be running
           perfectly well.
        2. A naive stamp is treated as UTC rather than local time, because everything this
           app writes is UTC -- see BaseRepository.now_iso.

    Args:
        job_started_at: The trigger stamp from conversations.job_started_at.
        timeout_minutes: Settings.JOB_TIMEOUT_MINUTES.

    Returns:
        True only when the job is definitively past its deadline.

    Example:
        >>> _is_overdue(None, 20)
        False
    """
    if not job_started_at:  # No trigger stamp -> we cannot date it, so keep waiting                 # have stamp?
        return False  # Fails OPEN: the reaper looks again next sweep                                # keep waiting
    try:  # Accept the trailing Z form the device APIs use                                           # parse try
        started = datetime.fromisoformat(str(job_started_at).replace("Z", "+00:00"))  # To datetime  # parse
    except ValueError:  # Corrupt stamp -- warn, but do not fail a job over it                       # bad stamp
        logger.warning("unparseable job_started_at %r; not expiring", job_started_at)  # Discoverable  # log warn
        return False  # Fails OPEN, as above                                                         # keep waiting
    if started.tzinfo is None:  # Naive stamp -> assume UTC, matching everything we write            # naive?
        started = started.replace(tzinfo=timezone.utc)  # Never local time                           # to utc
    return datetime.now(timezone.utc) - started > timedelta(minutes=timeout_minutes)  # Past the deadline?  # compare


# ========================================== Job service ===========================================
class JobService:
    """Advancing a running diagnostics/troubleshoot job (what the FE poll drives).

    What this class is:
        - The poll handler (advance_job), the reaper's batch driver (sweep_running_jobs),
          and the three private steps they share.

    Why it exists:
        - So a browser poll and a background sweep are indistinguishable to the rest of the
          system: same status check, same compare-and-swap, same transaction, same tests.

    Security and production notes:
        1. Every collaborator is injected; the four telemetry ones are optional so the
           existing tests can build a service without them.
        2. When the reaper drives this instead of a browser there is no api_requests row,
           because nobody was waiting on that request -- see deps.make_job_service.

    Example:
        >>> JobService(conv, flow, jobs, lang, settings).advance_job("u1", "c1")  # doctest: +SKIP
    """

    def __init__(
        self, conversations, flow, jobs, multilingual, settings: Settings,
        agent_calls=None, trace=None, api_requests=None, log_factory=None,
    ) -> None:
        """Adopt the collaborators; the four telemetry ones are optional.

        Args:
            conversations: ConversationRepository -- job columns, stage and transcript.
            flow: SupportFlow -- its two job-completion handlers are called from here.
            jobs: JobRunner -- polls the agent and interprets its report.
            multilingual: MultilingualAgent -- translates the outgoing lines.
            settings: Parsed configuration; the four job knobs are read from it.
            agent_calls: AgentCallRepository, or None to skip trace rows.
            trace: This request's CallTrace, or None.
            api_requests: ApiRequestRepository, or None (the reaper passes None).
            log_factory: LogFactory, or None to skip the structured log event.

        Returns:
            None.
        """
        self._conversations = conversations  # Job columns, stage and the transcript                 # conv repo
        self._flow = flow  # Its two completion handlers build the reply                             # flow
        self._jobs = jobs  # JobRunner: polls the agent, interprets the report                       # job runner
        self._lang = multilingual  # Translates outgoing lines; degrades, never raises               # lang agent
        self._settings = settings  # JOB_TIMEOUT_MINUTES, JOB_STATUS_RETRIES, REAPER_*               # settings
        # All optional, so the existing tests can build a service without them.
        self._agent_calls = agent_calls  # Optional trace sink                                       # trace repo
        self._trace = trace  # Optional per-request CallTrace                                        # trace
        self._api_requests = api_requests  # None when the REAPER is driving this                    # timing repo
        self._logger = (  # Optional structured logger, named for this component                     # logger
            log_factory.get_logger("job_service") if log_factory is not None else None
        )

    # ============================================ Public API ======================================
    def advance_job(
        self, user_id: str, conversation_id: str, session_id: Optional[str] = None
    ) -> dict:
        """The FE spinner polls this every ~30s (no backend queue/loop).

        What this method does:
            - Starts a timer, delegates to _advance_job, and finishes the timer in a
              `finally` whatever happened.

        Why it exists:
            - On each poll we look up the job_id by conversation_id, ask the job's agent for
              its status LIVE, store the latest status in the DB, and:
                - still running -> return the progress with done=False (keep spinning)
                - done/failed   -> advance the flow ONCE (result + next question), persist
                                   the new stage, and return done=True so the FE stops
                                   polling.

        Security and production notes:
            1. Timed like a chat turn, and for the same reasons -- see TurnTimer. The rows
               are written AFTER the poll's own writes, so the trace is never inside their
               transaction, and from a `finally`, so a poll that failed still records why.
            2. When the reaper drives this instead of a browser there is no api_requests
               row, because nobody was waiting on that request (see deps.make_job_service).

        Args:
            user_id: Owner of the conversation.
            conversation_id: The conversation whose job to advance.
            session_id: Echoed into the payload; None when the reaper is driving.

        Returns:
            The job payload dict; `done` tells the FE whether to stop polling.

        Raises:
            NotFound: The conversation does not exist. -> 404
            AppError: An agent could not answer at all.

        Example:
            >>> svc.advance_job("u1", "c1")["done"]  # doctest: +SKIP
            False
        """
        timer = TurnTimer(  # Clock starts above the load and the agent poll                         # start timer
            "jobs_status",  # Route label stored on the api_requests row                             # endpoint
            agent_calls=self._agent_calls,  # May be None in tests                                   # trace repo
            api_requests=self._api_requests,  # None when the reaper is driving                      # timing repo
            trace=self._trace,  # Rows are flushed by timer.finish()                                 # trace
            logger=self._logger,  # May be None; then no log event is emitted                        # logger
        )
        failed = True  # Pessimistic: only cleared once a payload is fully built                     # assume fail
        try:  # All the real work; the finally always writes the timing                              # poll try
            payload = self._advance_job(user_id, conversation_id, session_id)  # One poll            # advance
            failed = False  # A payload was produced, so the poll succeeded                          # succeeded
            return payload  # The controller serialises this as-is                                   # return
        finally:  # Runs on success AND failure, after any transaction has closed                    # always
            timer.finish(user_id, conversation_id, failed=failed)  # Never raises                    # write timing

    def sweep_running_jobs(self, limit: int = None) -> dict:
        """Advance every conversation still parked in a RUNNING stage.

        What this method does:
            - Computes the staleness cut-off, fetches up to `limit` stale running jobs, and
              puts each through advance_job(), tallying the outcomes.

        Why it exists:
            - This is what the reaper calls. Without it a job only ever moves when a BROWSER
              polls -- so a user who closed their tab left the conversation stuck in
              DIAGNOSTICS_RUNNING forever, with a ServiceNow ticket that said "diagnostics
              started" and nothing more.
            - Each conversation goes through the SAME advance_job() the FE poll uses, so
              there is one code path and one set of behaviour.

        Security and production notes:
            1. The staleness cut-off skips anything a browser is still polling: its
               last_updated_at is fresh, so it is already being advanced by the user's own
               requests and does not need us.
            2. If a browser and the reaper reach the same job together -- or two instances
               both sweep it -- the compare-and-swap in advance_after_job() lets exactly one
               of them win.
            3. One conversation failing never stops the sweep: an AppError is an expected
               problem (agent unavailable, conversation gone) and we move on; anything else
               is our bug and gets a full traceback.

        Args:
            limit: Max conversations to handle; defaults to Settings.REAPER_BATCH_SIZE.

        Returns:
            {found, advanced, still_running, failed} -- the tallies the reaper logs.

        Example:
            >>> svc.sweep_running_jobs(50)  # doctest: +SKIP
            {'found': 2, 'advanced': 1, 'still_running': 1, 'failed': 0}
        """
        limit = limit if limit is not None else self._settings.REAPER_BATCH_SIZE  # Bounded sweep    # batch cap
        # Skip anything a browser is still polling: its last_updated_at is fresh, so it is
        # already being advanced by the user's own requests and does not need us.
        stale_before = (  # "Nobody has looked at this for REAPER_STALE_MINUTES"                     # cut-off
            datetime.now(timezone.utc)
            - timedelta(minutes=self._settings.REAPER_STALE_MINUTES)
        ).isoformat()
        rows = self._conversations.find_running(limit, stale_before)  # Oldest-touched first         # find stale
        advanced = still_running = failed = 0  # Tallies for the reaper's one log line               # counters
        for row in rows:  # One conversation at a time; a failure must not stop the sweep            # each row
            try:  # The SAME method a browser poll calls                                             # advance try
                payload = self.advance_job(row["user_id"], row["id"])  # No session_id here          # advance
                if payload.get("done"):  # The job reached a terminal state                          # finished?
                    advanced += 1  # We (or the winner of the race) moved the flow on                # count
                else:  # Still legitimately running                                                  # still going
                    still_running += 1  # Leave it for the next sweep                                # count
            except AppError as exc:  # EXPECTED: agent unavailable, conversation gone                # known issue
                logger.warning(  # No traceback: this is a handled condition                         # log warn
                    "sweep: skipped conv_id=%s: %s", row.get("id"), exc
                )
                failed += 1  # Counted, then we move on to the next conversation                     # count
            except Exception:  # UNEXPECTED: our own bug -- keep the full traceback                  # our bug
                logger.exception("sweep: BUG advancing conv_id=%s", row.get("id"))  # Traceback      # log error
                failed += 1  # Counted, then we move on to the next conversation                     # count
        return {  # The four tallies the reaper logs, so a live sweep is provable                    # tallies
            "found": len(rows), "advanced": advanced,  # How many, and how many moved on             # counts
            "still_running": still_running, "failed": failed,  # And the two other outcomes          # counts
        }

    # ============================================= Internals ======================================
    def _advance_job(self, user_id, conversation_id, session_id):
        """One poll, untimed: load, decide, poll the agent, then wait / expire / complete.

        What this method does:
            - Loads the conversation and its job columns. If the stage is not a RUNNING one
              there is nothing to poll. Otherwise it derives the job kind from the stage,
              polls the agent, and either keeps waiting, expires the job, or completes it.

        Why it exists:
            - Kept separate from advance_job() so the timer wraps the WHOLE thing in a
              `finally` without this method needing to know the timer exists.

        Security and production notes:
            1. The stage names a KIND; JobRunner owns the kind -> agent mapping, so this
               stays a two-line decision rather than an agent lookup here.
            2. An expired job is turned into a `failed` status with OUR OWN message, so the
               user is told plainly that nothing came back rather than being left spinning.

        Args:
            user_id: Owner of the conversation.
            conversation_id: The conversation whose job to advance.
            session_id: Echoed into the payload; may be None.

        Returns:
            The job payload dict.

        Raises:
            NotFound: The conversation does not exist.
        """
        conversation = self._conversations.load(user_id, conversation_id)  # Scoped by user_id       # load conv
        if conversation is None:  # Nothing to poll for                                              # exists?
            raise NotFound("Conversation not found")  # -> 404                                       # raise 404
        stage = conversation.get("stage")  # Where the flow currently is                             # read stage
        flow_vars = conversation.get("vars", {})  # Already merged with the promoted columns         # read vars
        job = self._conversations.get_job(user_id, conversation_id)  # job_output NOT included       # read job

        # Not in a running stage -> nothing to poll (not started, or already advanced).
        if stage not in (DIAGNOSTICS_RUNNING, TROUBLESHOOT_RUNNING):  # No job in flight             # running?
            return job_payload(  # Report the last known state and stop the spinner                  # early out
                user_id, session_id, conversation_id, stage,
                done=job.get("job_status") in JOB_TERMINAL,  # True once the job is terminal         # done flag
                messages=[job.get("job_message") or "No active job."],  # Safe line only             # message
            )

        # Running -> which agent to ask, from the stage. The stage names a KIND; JobRunner
        # owns the kind -> agent mapping, so this stays a two-line decision.
        kind = (  # Derived from the stage; JobRunner maps it to the agent                           # job kind
            JOB_KIND_DIAGNOSTIC if stage == DIAGNOSTICS_RUNNING
            else JOB_KIND_TROUBLESHOOT
        )

        status = self._poll_status(kind, job, conversation_id)  # Retries only a blip                # poll agent
        state = status.get("state", "running")  # running | done | failed                            # read state

        # Still running -> either keep waiting, or give up because it is overdue.
        if state not in ("done", "failed"):  # No outcome yet                                        # terminal?
            if _is_overdue(job.get("job_started_at"), self._settings.JOB_TIMEOUT_MINUTES):  # Past deadline?  # expired?
                status = {  # Synthesise a failure with OUR OWN wording                              # expire it
                    "state": "failed",  # Treated exactly like an agent-reported failure             # state
                    "message": (  # Plain, user-safe, and names the wait we gave it                  # message
                        f"No result after {self._settings.JOB_TIMEOUT_MINUTES} minutes. "
                        "Your ticket stays open."
                    ),
                    "output": None,  # Nothing came back, so there is nothing to store               # output
                }
                state = "failed"  # Fall through to _complete below                                  # now failed
            else:  # Genuinely still working -> record the progress line and keep spinning           # keep waiting
                message = status.get("message") or "Working..."  # Safe line only                    # progress
                self._conversations.update_job_message(  # ONE column; also bumps last_updated       # save progress
                    user_id, conversation_id, message
                )
                return job_payload(  # done=False -> the FE polls again in ~30s                      # keep polling
                    user_id, session_id, conversation_id, stage,
                    done=False, messages=[message],
                )

        return self._complete(  # Terminal (or expired) -> advance the flow exactly once             # complete
            user_id, conversation_id, session_id, stage, flow_vars, status, state
        )

    def _poll_status(self, kind, job, conv_id) -> dict:
        """One poll's worth of status checking, retrying only what a retry can fix.

        What this method does:
            - Calls JobRunner.check_status up to JOB_STATUS_RETRIES times, catching ONLY
              UpstreamTransient. If every attempt blips, it reports the last known message
              as "still running".

        Why it exists:
            - ONLY UpstreamTransient is retried -- a blip, where the next attempt may well
              succeed. If every attempt fails we report the last known message as "still
              running", so the blip costs a poll rather than the whole job.
            - Everything else is deliberately NOT caught:
                * UpstreamUnavailable -- a contract violation, or an agent that cannot
                  answer at all. Retrying it three times just delays the same failure, so it
                  surfaces immediately.
                * TypeError, KeyError, ... -- bugs in our own code. A blanket
                  `except Exception` here used to swallow them and report "still running",
                  so a real defect looked like a slow device job.

        Security and production notes:
            1. Retrying is only safe because a status check is a READ. It cannot start a
               second remediation on the user's machine.

        Args:
            kind: The job kind, for JobRunner's dispatch.
            job: The job columns read from the conversation row.
            conv_id: Used only for the warning line.

        Returns:
            {state, message, output} -- possibly a synthesised "still running".

        Example:
            >>> svc._poll_status("diagnostic", {"job_id": "j1"}, "c1")["state"]  # doctest: +SKIP
            'running'
        """
        for _ in range(self._settings.JOB_STATUS_RETRIES):  # Bounded by configuration               # each attempt
            try:  # A READ, so retrying it is safe                                                   # poll try
                return self._jobs.check_status(  # Interprets the agent's report for us              # check
                    kind, job.get("job_id"), job.get("job_baseline") or ""  # Freshness gate         # args
                )
            except UpstreamTransient as exc:  # ONLY a blip is retried -- see the notes above        # blip
                logger.warning(  # Each failed attempt is visible, not just the final give-up        # log warn
                    "check_status attempt failed conv_id=%s: %s", conv_id, exc
                )
        return {  # Every attempt blipped -> the blip costs a poll, not the job                      # give up
            "state": "running",  # Keep the job alive; expiry is the real backstop                   # state
            "message": job.get("job_message") or "Working...",  # Last known safe line               # message
            "output": None,  # We have no fresh output to store                                      # output
        }

    def _complete(
        self, user_id, conversation_id, session_id, stage, flow_vars, status, state
    ) -> dict:
        """Advance the flow after a job finishes -- exactly once, and atomically.

        What this method does:
            - Builds job_view and the capped job_output, runs the matching flow completion
              handler, translates the reply, then performs the conditional UPDATE plus the
              transcript write in one transaction. Reports the winner's state if we lost.

        Why it exists:
            - The order below is deliberate:
                1. Build the reply first (the flow handlers, plus translation). These call
                   agents -- ServiceNow on the failure path, and the multilingual agent --
                   so they must run BEFORE any transaction is opened. An open transaction
                   holds locks on the conversation row, and must never span an agent call.
                2. Then one transaction containing exactly two writes: the conditional
                   UPDATE that moves the stage and records the job outcome together, and the
                   transcript rows. Either both land or neither does, so a crash can no
                   longer leave the stage advanced with its messages missing.

        Security and production notes:
            1. The conditional UPDATE is also the race guard. Only the caller that still
               sees the RUNNING stage updates a row; a second poller (two browser tabs, a
               refresh mid-poll, another worker process, the reaper on another instance)
               gets 0 rows and skips -- which is what stops the same messages being written
               to the transcript twice.
            2. job_message is the USER-SAFE line; the raw device output is kept apart in
               job_output and is never put into job_view, so it cannot reach a message list.
            3. job_output is truncated so a pathological script can't write megabytes into
               the row, and the failure path logs only the LENGTH -- never the text, which
               would copy device data into the logs.

        Args:
            user_id: Owner of the conversation.
            conversation_id: The conversation to advance.
            session_id: Echoed into the payload; may be None.
            stage: The RUNNING stage we came in on; also the compare-and-swap condition.
            flow_vars: The flow's variables.
            status: The derived {state, message, output} from the agent.
            state: status["state"], already extracted by the caller.

        Returns:
            The job payload dict with done=True.
        """
        done = state == "done"  # The only two possibilities here are done and failed                # succeeded?
        # What diagnostics_completed / troubleshoot_completed read off the job row. Built
        # from the status we already hold, so no write has to happen before this step.
        #
        # job_message is the USER-SAFE line; the raw device output is kept apart in
        # job_output and is never put into job_view, so it cannot reach a message list.
        job_view = {  # Exactly two keys, both safe to show                                          # job view
            "job_status": JOB_DONE if done else JOB_FAILED,  # What the flow branches on             # status
            "job_message": status.get("message") or ("Complete." if done else "Failed."),  # Safe line  # message
        }
        # Truncated so a pathological script can't write megabytes into the row.
        raw_output = status.get("output")  # RAW device text: support only, never shown              # read output
        job_output = str(raw_output)[:MAX_JOB_OUTPUT] if raw_output else None  # Capped, or NULL     # cap output
        if job_output and not done:  # A failure WITH device output is the useful case               # failed+output?
            # The failure reason used to be discarded entirely. Record that we captured
            # it (not the text itself -- that would copy device data into the logs).
            logger.info(  # LENGTH only: the text stays in SQL, out of the log stream                # log info
                "job failed conv_id=%s; %d chars of device output stored in job_output",
                conversation_id, len(job_output),
            )

        messages: list = []  # The flow handler appends its lines to this                            # out lines
        if stage == DIAGNOSTICS_RUNNING:  # Diagnostics finished -> ask about troubleshooting        # which job?
            messages, new_stage, flow_vars = self._flow.diagnostics_completed(  # May call ServiceNow  # advance
                conversation_id, flow_vars, messages, job_view
            )
        else:  # TROUBLESHOOT_RUNNING -> ask whether the issue is resolved                           # the other
            messages, new_stage, flow_vars = self._flow.troubleshoot_completed(  # May call ServiceNow  # advance
                conversation_id, flow_vars, messages, job_view
            )
        messages = visible(self._lang.translate_messages(messages, flow_vars.get("lang")))  # Translate out  # translate
        answer = join(messages)  # The single string the FE also reads                               # join lines

        repo = self._conversations  # Local alias: this block names it four times                    # alias
        with repo.transaction():  # ONE transaction: the stage move and the transcript together      # one txn
            won = repo.advance_after_job(  # The conditional UPDATE -- also the race guard           # cas update
                user_id, conversation_id,
                expected_stage=stage, new_stage=new_stage, flow_vars=flow_vars,  # CAS condition     # stages
                question="[job-poll]", answer=answer,  # No real user turn: the FE was polling       # turn text
                job_status=job_view["job_status"],  # Terminal status                                # status
                job_message=job_view["job_message"],  # The user-safe outcome line                   # message
                job_output=job_output,  # Capped raw output; support only                            # output
            )
            if won:  # Only the winner writes the transcript, so lines are never duplicated          # won race?
                # Job completion produces assistant-only lines (result + next question).
                # No user turn here -- the FE was polling, not chatting.
                repo.append_turns(  # Assistant-only: nobody typed anything this turn                # save turns
                    user_id, conversation_id, [("assistant", m) for m in messages]
                )

        if won:  # We advanced the flow; report our own freshly-built reply                          # won race?
            return job_payload(
                user_id, session_id, conversation_id, new_stage,
                done=True, messages=messages, answer=answer,  # Stops the FE polling                 # done
            )

        # We lost the race. Report what the winner persisted, not our own copy, so both
        # pollers agree on what the user is looking at.
        logger.info(  # Expected under two tabs or a browser racing the reaper                       # log info
            "job completion already claimed by another poller conv_id=%s", conversation_id
        )
        return self._already_advanced(user_id, conversation_id, session_id)  # Re-read and report    # loser path

    def _already_advanced(self, user_id, conversation_id, session_id) -> dict:
        """Payload for a poller that lost the completion race: re-read and report.

        What this method does:
            - Re-reads the conversation and its job columns and builds a done=True payload
              from what the WINNER persisted.

        Why it exists:
            - So two pollers agree on what the user is looking at. Returning our own copy
              would show a second browser tab a different reply from the first.

        Security and production notes:
            1. get_job() is used rather than load_job_output(), so the raw device output
               cannot reach this response.

        Args:
            user_id: Owner of the conversation.
            conversation_id: The conversation another poller just advanced.
            session_id: Echoed into the payload; may be None.

        Returns:
            The job payload dict with done=True and the winner's message.
        """
        conversation = self._conversations.load(user_id, conversation_id) or {}  # {} if it vanished  # re-read
        job = self._conversations.get_job(user_id, conversation_id)  # job_output NOT included       # read job
        return job_payload(
            user_id, session_id, conversation_id, conversation.get("stage"),  # The winner's stage   # stage
            done=True,  # The job IS finished, whoever finished it                                   # done
            messages=[job.get("job_message") or "Complete."],  # The winner's safe line              # message
        )
