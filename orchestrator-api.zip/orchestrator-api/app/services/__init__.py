####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Public face of `app.services` -- one class per use-case group, each owning a unit of work.       #
#   1. Re-export the four service classes, so callers import from the package not the module.      #
#   2. Name what each service sequences, and what it deliberately knows nothing about.             #
#   3. Record that THIS layer owns the transaction boundary, and where it must be opened.          #
#                                                                                                  #
# Source:-                                                                                         #
#   - The four sibling modules hold the implementations; payloads.py is not re-exported because    #
#       only the services themselves build response dicts.                                         #
####################################################################################################
"""Service layer: one class per use-case group, each owning a whole unit of work.

What this package is:
    - Five modules, four of them exported:

        chat.py      ChatService -- starting and continuing conversations
        jobs.py      JobService -- advancing a running diagnostics/troubleshoot job
        history.py   HistoryService -- the read-only queries
        timing.py    TurnTimer -- measures one served request, writes both timing tables
        payloads.py  the response dicts every return path shares

Why this exists:
    - Sits between api/ (HTTP) and domain/ (the rules). A service method owns the SEQUENCE
      of a use case -- run the flow, translate the reply, persist the turn, dispatch any
      async job -- while knowing nothing about requests, responses or status codes. It
      returns plain dicts and raises the framework-free errors in core/errors.py; the api
      layer is the only place that turns those into HTTP.
    - Each service takes its collaborators in __init__ (repositories, agents, the flow) and
      never reaches for a module global. That is what makes them testable: a test builds
      ChatService(FakeConversationRepo(), FakeSessionRepo(), FakeFlow(), FakeFoundry()) and
      drives any branch with no database, no Azure and no network.
    - Imported from here rather than from the individual modules, so a caller writes
      `from app.services import ChatService`.

Security and production notes:
    1. TRANSACTION BOUNDARY: this layer owns it. Each service method does its slow work
       first (flow handlers, agent calls, translation) and only then opens
       repo.transaction() around the writes that must agree with each other -- so a crash
       can't leave the conversation row advanced with its transcript rows missing, and no
       agent call is ever inside an open transaction holding row locks.
    2. The two timing tables are written from a `finally`, AFTER the transaction block has
       exited -- see TurnTimer. Inside it they would commit the turn's half-written work.

Example:
    >>> from app.services import ChatService, JobService  # doctest: +SKIP
"""

# ============================================ Imports =============================================
from app.services.chat import ChatService  # Starting and continuing conversations                   # chat svc
from app.services.history import HistoryService  # The read-only sidebar / transcript queries        # history svc
from app.services.jobs import JobService  # Advancing a running device job                           # job svc
from app.services.timing import TurnTimer  # Per-request measurement for both timing tables          # timer

# =========================================== Public API ===========================================
# Explicit, so `import *` and the linters agree on the surface area of this package.
__all__ = ["ChatService", "HistoryService", "JobService", "TurnTimer"]  # payloads stays internal    # exports
