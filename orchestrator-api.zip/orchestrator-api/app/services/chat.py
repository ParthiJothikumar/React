####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# ChatService: the command side -- start a conversation, and advance an existing one.              #
#   1. start_chat(): new Foundry conversation + new session, then run the opening turn.            #
#   2. continue_chat(): load the session's active conversation and advance it one turn.            #
#   3. _persist_turn(): the shared tail -- translate out, then ONE transaction for both writes.    #
#   4. _dispatch_pending_job(): start the device job the flow asked for, AFTER the row exists.     #
#                                                                                                  #
# Source:-                                                                                         #
#   - uuid mints the session id; nothing else is imported from outside the app.                    #
#   - app.core.constants.DONE is the terminal-stage test on the continue path.                     #
#   - app.core.errors supplies the three errors this service raises (NotFound, ConversationEnded,  #
#       TurnFailed) -- all framework-free, so the api layer maps them to status codes.             #
#   - app.services.payloads / timing supply the shared response shape and the per-request timer.   #
####################################################################################################
"""ChatService: starting and continuing conversations (the command side).

What this module is:
    - One class with two public methods (start_chat, continue_chat) and two private tails
      they share (_persist_turn, _dispatch_pending_job).

Why this exists:
    - A service method owns the SEQUENCE of a use case -- run the flow, translate the
      reply, persist the turn, dispatch any async job -- while knowing nothing about
      requests, responses or status codes.

Security and production notes:
    1. TRANSACTION BOUNDARY. Both writes of a turn (the conversation row and its transcript
       rows) happen in ONE transaction, opened in _persist_turn AFTER the flow and
       translation calls -- so no agent call is ever inside an open transaction holding row
       locks, and a crash cannot leave the stage advanced with the messages missing.
    2. TurnFailed is raised with the stage that is GENUINELY in the database, and with the
       incident number when one already exists. Without both, the frontend reset a healthy
       conversation over one transient timeout and the user opened a SECOND ticket -- see
       core/errors.py.
    3. The timer is finished in a `finally` on every path, including the two early NotFound
       returns, so the latency tables do not only show the happy path.
"""

# ============================================ Imports =============================================
import uuid  # Mints the session id for a brand-new chat                                             # stdlib uuid

from app.core.constants import DONE  # Terminal-stage test on the continue path                      # constants
from app.core.errors import ConversationEnded, NotFound, TurnFailed  # The three we raise            # errors
from app.services.payloads import chat_payload, join, visible  # Shared response shaping             # payloads
from app.services.timing import TurnTimer  # Per-request measurement for both timing tables          # timer


# ========================================== Chat service ==========================================
class ChatService:
    """Starting and continuing conversations (the command side).

    What this class is:
        - The sequencer for a chat turn: flow, translate, persist, dispatch, respond.

    Why it exists:
        - So the ORDER of those steps is written once. Getting the order wrong is what
          caused the two bugs recorded in this file: a job dispatched before its
          conversation row existed, and a turn's transcript committed separately from its
          stage.

    Security and production notes:
        1. Every collaborator is injected; the four telemetry ones are optional so the
           existing tests can build a service without them.
        2. Nothing here catches NotFound or ConversationEnded into a generic failure -- both
           are re-raised so the api layer can map them to 404 and 409.

    Example:
        >>> ChatService(conv, sess, flow, foundry, jobs, lang).start_chat("u1", "hi")  # doctest: +SKIP
    """

    def __init__(
        self, conversations, sessions, flow, foundry, jobs, multilingual,
        agent_calls=None, trace=None, api_requests=None, log_factory=None,
    ) -> None:
        """Adopt the collaborators; the four telemetry ones are optional.

        Args:
            conversations: ConversationRepository -- flow state and the transcript.
            sessions: SessionRepository -- the sidebar row and its current-conversation pointer.
            flow: SupportFlow -- the stage machine.
            foundry: FoundryClient -- used only to create a new conversation.
            jobs: JobRunner -- starts a device job and supplies its baseline stamp.
            multilingual: MultilingualAgent -- translates the outgoing lines.
            agent_calls: AgentCallRepository, or None to skip trace rows.
            trace: This request's CallTrace, or None.
            api_requests: ApiRequestRepository, or None to skip timing rows.
            log_factory: LogFactory, or None to skip the structured log event.

        Returns:
            None.
        """
        self._conversations = conversations  # Flow state, job state and the transcript              # conv repo
        self._sessions = sessions  # The sidebar row and its current-conversation pointer            # session repo
        self._flow = flow  # The stage machine; holds no per-conversation state                      # flow
        self._foundry = foundry  # Only used to mint a new conversation on start_chat                # foundry
        self._jobs = jobs  # JobRunner: starts a device job, supplies the baseline stamp             # job runner
        self._lang = multilingual  # Translates outgoing lines; degrades, never raises               # lang agent
        # All optional, so the existing tests can build a service without them.
        self._agent_calls = agent_calls  # Optional trace sink                                       # trace repo
        self._trace = trace  # Optional per-request CallTrace                                        # trace
        self._api_requests = api_requests  # Optional timing sink                                    # timing repo
        self._logger = (  # Optional structured logger, named for this component                     # logger
            log_factory.get_logger("chat_service") if log_factory is not None else None
        )

    def _timer(self, endpoint: str) -> TurnTimer:
        """Start measuring this request.

        Constructed here so the clock starts at the top of the service method, before any
        agent or DB work -- otherwise the number would exclude exactly the slow part.

        Args:
            endpoint: Route label for the api_requests row, e.g. "chat".

        Returns:
            A started TurnTimer holding this request's sinks.
        """
        return TurnTimer(
            endpoint,  # Route label stored on the row                                               # endpoint
            agent_calls=self._agent_calls,  # May be None in tests                                   # trace repo
            api_requests=self._api_requests,  # May be None in tests                                 # timing repo
            trace=self._trace,  # Rows are flushed by timer.finish()                                 # trace
            logger=self._logger,  # May be None; then no log event is emitted                        # logger
        )

    # ============================================ Public API ======================================
    def start_chat(self, user_id: str, message: str) -> dict:
        """Start a new chat session and run the first turn.

        What this method does:
            - Mints a session id, creates a Foundry conversation, runs the flow for the
              opening message, persists the turn, saves the session row, dispatches any
              requested job, and returns the chat payload.

        Why it exists:
            - Creates a fresh Foundry conversation and a new session id, runs the flow for
              the opening message, translates the reply into the user's language, then
              persists the conversation, transcript and session rows.

        Security and production notes:
            1. The timer is started BEFORE the Foundry call, so its latency is counted too
               -- it is part of what the user waits for.
            2. `flow_vars` is kept as our own reference because the dict is mutated in
               place by step(). So if step() throws AFTER creating the ticket, incident_id
               is still visible here and can be carried out on TurnFailed. Nothing is saved
               on a failed first turn, so the user would otherwise start over and open a
               SECOND ticket.

        Args:
            user_id: The caller's id (an email address; it stays in SQL, never in a log field).
            message: The user's opening message, in their own language.

        Returns:
            The chat payload dict.

        Raises:
            NotFound / ConversationEnded: Re-raised untouched for the api layer to map.
            TurnFailed: Anything else, carrying the conversation id and any incident number.

        Example:
            >>> svc.start_chat("u1", "outlook won't open")["stage"]  # doctest: +SKIP
            'AWAITING_CLASSIFY'
        """
        # Started before the Foundry call, so its latency is counted too -- it is part of
        # what the user waits for.
        timer = self._timer("chat")  # Clock starts here, above every agent and DB call              # start timer
        failed = True  # Pessimistic: only cleared once the payload is fully built                   # assume fail
        session_id = "sess_" + uuid.uuid4().hex  # New sidebar entry for this chat                   # new session
        conversation = self._foundry.create_conversation()  # Raises UpstreamUnavailable on failure  # new conv
        # Handed to flow.step, which fills in interaction_id / incident_id as it goes.
        # We keep our own reference so a failure can still report what was raised: the
        # dict is mutated in place, so incident_id is visible here even if step() throws
        # afterwards.
        flow_vars = {"user_id": user_id}  # Seeded; the flow needs it to open the interaction        # flow vars
        try:  # Everything below is one turn; the finally always writes the timing                   # turn try
            messages, stage, flow_vars = self._flow.step(  # No persistence inside step()            # run flow
                conversation.id, message, None, flow_vars
            )
            messages, answer, pending_job = self._persist_turn(  # Translate + ONE transaction       # persist
                user_id, conversation.id,
                question=message, messages=messages, stage=stage, flow_vars=flow_vars,
                session_id=session_id, seq=0,  # First turn of a brand-new conversation              # lineage
            )
            self._sessions.save(user_id, session_id, conversation.id, message)  # Sidebar row        # save session
            self._dispatch_pending_job(user_id, conversation.id, pending_job)  # AFTER the row exists  # start job
            payload = chat_payload(  # Same shape every chat path returns                            # build reply
                user_id, session_id, conversation.id, stage, messages, answer
            )
            failed = False  # Only now is the turn genuinely a success                               # succeeded
            return payload  # The controller serialises this as-is                                   # return
        except (NotFound, ConversationEnded):  # Both have their own status codes                    # mapped errs
            raise  # Re-raised untouched, so main.py's handlers see them                             # re-raise
        except Exception as exc:  # Any real failure on the first turn                               # turn failed
            # Nothing is saved on a failed first turn, so the user must start over -- and
            # if a ticket was already raised, starting over would open a SECOND one.
            # Carry the incident out so the controller can hand them the number instead
            # of inviting a retry.
            raise TurnFailed(
                None, conversation.id, exc,  # stage=None: nothing was ever persisted                # no stage
                incident_id=flow_vars.get("incident_id"),  # Visible thanks to in-place mutation     # ticket
            ) from exc  # __cause__ keeps the real reason for the log line                           # chain
        finally:  # Runs on success AND failure, after any transaction has closed                    # always
            timer.finish(user_id, conversation.id, failed=failed)  # Never raises                    # write timing

    def continue_chat(self, user_id: str, session_id: str, message: str) -> dict:
        """Continue an ACTIVE conversation in a session by session_id.

        What this method does:
            - Loads the session and its current conversation, refuses a terminal one, then
              advances the flow by one turn and persists it.

        Why it exists:
            - Loads the session's current conversation and advances it by one turn. If that
              conversation has already ended (stage=DONE) it is final -- we raise
              ConversationEnded so the frontend starts a fresh chat; there is no rollover
              and no memory carry-over.

        Security and production notes:
            1. The two early exits (NotFound, ConversationEnded) each finish the timer
               before raising. A 404 is still a served request, and its timing belongs in
               the table -- otherwise the latency chart only ever shows the happy path.
            2. `current_stage` tracks what is genuinely in the DB: the old stage before the
               write commits, the new one after. That is the value TurnFailed carries, and
               it is why a failed turn no longer resets a healthy conversation.

        Args:
            user_id: The caller's id.
            session_id: Which session to continue.
            message: The user's message, in their own language.

        Returns:
            The chat payload dict.

        Raises:
            NotFound: The session, or its current conversation, does not exist. -> 404
            ConversationEnded: That conversation is already terminal. -> 409
            TurnFailed: The turn broke but the conversation is intact and retryable.

        Example:
            >>> svc.continue_chat("u1", "s1", "yes")["done"]  # doctest: +SKIP
            False
        """
        # Before the two loads, so their DB time is included.
        timer = self._timer("chat_continue")  # Clock starts above the two loads                     # start timer
        failed = True  # Pessimistic: only cleared once the turn has committed                       # assume fail
        try:  # The two lookups; either can legitimately find nothing                                # load try
            session = self._sessions.load(user_id, session_id)  # Scoped by user_id                  # load session
            if session is None:  # No such session for this user                                     # exists?
                raise NotFound("Session not found")  # -> 404                                        # raise 404
            conv_id = session.get("current_conversation_id")  # What the session points at           # read pointer
            conversation = self._conversations.load(user_id, conv_id)  # Scoped by user_id           # load conv
            if conversation is None:  # Pointer with no row behind it                                # exists?
                raise NotFound("Conversation not found")  # -> 404                                   # raise 404
        except NotFound:  # Still a served request -- time it before raising                         # not found
            # A 404 is still a served request, and its timing belongs in the table --
            # otherwise the latency chart only ever shows the happy path.
            timer.finish(user_id, None, failed=True)  # No conv_id to attribute it to                # write timing
            raise  # main.py maps this to 404                                                        # re-raise

        stage = conversation.get("stage", DONE)  # Default DONE: an unreadable row is terminal       # read stage
        flow_vars = conversation.get("vars", {})  # Already merged with the promoted columns         # read vars

        # Ended conversations are final -- no rollover, no memory carry-over. The
        # frontend should start a new chat instead of continuing.
        if stage == DONE:  # Terminal -> refuse the turn rather than reopening it                    # ended?
            # Not an error -- the caller turns it into a normal "chat ended" reply -- but
            # it IS a served request, so it is timed like any other.
            timer.finish(user_id, conv_id)  # failed=False: this is a normal outcome                 # write timing
            raise ConversationEnded(  # -> 409                                                       # raise 409
                "This conversation has ended. Please start a new chat."
            )

        # Anything that fails below leaves the conversation exactly where it was (the
        # writes are one transaction), so it is retryable -- and TurnFailed carries the
        # stage out, because the api layer cannot know it from the exception alone.
        # `current_stage` tracks what is genuinely in the DB: the old stage before the
        # write commits, the new one after.
        current_stage = stage  # What is REALLY in the DB right now                                  # true stage
        try:  # The turn itself                                                                      # turn try
            messages, new_stage, new_flow_vars = self._flow.step(  # No persistence inside step()    # run flow
                conv_id, message, stage, flow_vars
            )
            messages, answer, pending_job = self._persist_turn(  # Translate + ONE transaction       # persist
                user_id, conv_id,
                question=message, messages=messages, stage=new_stage,
                flow_vars=new_flow_vars,  # session_id/seq omitted -> keep what is stored            # lineage
            )
            current_stage = new_stage  # the transaction committed; the stage has moved              # stage moved
            self._dispatch_pending_job(user_id, conv_id, pending_job)  # AFTER the row is saved      # start job
            failed = False  # The turn committed                                                     # succeeded
        except ConversationEnded:  # Raised by step() for a terminal stage                           # ended
            raise  # terminal, not retryable -- the caller shows the "ended" message                 # re-raise
        except Exception as exc:  # Retryable: the conversation is exactly where it was              # turn failed
            raise TurnFailed(current_stage, conv_id, exc) from exc  # Carries the TRUE stage         # raise
        finally:  # Runs on success AND failure, after the transaction has closed                    # always
            timer.finish(user_id, conv_id, failed=failed)  # Never raises                            # write timing
        return chat_payload(user_id, session_id, conv_id, new_stage, messages, answer)  # Same shape  # return

    # ============================================= Internals ======================================
    def _persist_turn(
        self, user_id, conv_id, *, question, messages, stage, flow_vars,
        session_id=None, seq=None,
    ):
        """The tail every chat turn shares: translate, persist state, record transcript.

        What this method does:
            - Pops the job intent out of flow_vars, translates the outgoing lines, drops
              blanks, joins them into `answer`, then writes the conversation row and its
              transcript rows inside ONE transaction.

        Why it exists:
            - Returns (messages, answer, pending_job). The caller dispatches `pending_job`
              once writing is done -- the conversation row must exist before a job_id can be
              recorded against it.

        Security and production notes:
            1. The job intent is POPPED before saving, so it is never persisted into `vars`.
               A stale start_job left in the row would re-trigger a device job on reload.
            2. One transaction for both writes: the state and the transcript must agree, or
               a crash between them leaves the stage advanced with the messages missing.
               Opened here, AFTER the flow and translation calls, so no agent call is inside
               it holding row locks.
            3. visible() is applied BEFORE both the response and the transcript write, so
               the FE and the stored history cannot disagree about which bubbles existed.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation being written.
            question: The user's message, in their ORIGINAL language.
            messages: The flow's outgoing lines, in the working language.
            stage: The new stage to store.
            flow_vars: The flow's variables; mutated by the pop.
            session_id: Lineage; None keeps the stored value.
            seq: Lineage; None keeps the stored value.

        Returns:
            (messages, answer, pending_job).
        """
        # If the flow asked to start an async job, pull the request out before saving so
        # it isn't persisted in vars; the caller dispatches it once the row exists.
        pending_job = flow_vars.pop("start_job", None)  # Never stored: a stale one would re-fire    # take intent
        messages = visible(  # Translate out, then drop blanks -- in that order                      # translate out
            self._lang.translate_messages(messages, flow_vars.get("lang"))
        )
        answer = join(messages)  # The single string the FE also reads                               # join lines
        # One transaction for both writes: the state and the transcript must agree, or a
        # crash between them leaves the stage advanced with the messages missing. Opened
        # here, AFTER the flow and translation calls, so no agent call is inside it.
        with self._conversations.transaction():  # All of it, or none of it                          # one txn
            self._conversations.save(  # Stage, flow vars, and the turn's question/answer            # save state
                user_id, conv_id,
                stage=stage, flow_vars=flow_vars, question=question, answer=answer,
                session_id=session_id, seq=seq,  # None -> keep whatever is stored                   # lineage
            )
            # Record the FE-visible transcript for this turn: the user's message plus
            # each assistant line we're returning, exactly as shown.
            self._conversations.append_turns(  # The user's ORIGINAL text, then each reply           # save turns
                user_id, conv_id,
                [("user", question)] + [("assistant", m) for m in messages],
            )
        return messages, answer, pending_job  # The caller dispatches the job next                   # return tail

    def _dispatch_pending_job(self, user_id, conv_id, pending):
        """Start an async job the flow requested (via flow_vars["start_job"]).

        What this method does:
            - No-op when there is no intent. Otherwise calls JobRunner.start() to get a
              job_id and records it on the conversation row with a fresh baseline stamp.

        Why it exists:
            - No queue, no background loop: we call the agent's start() to get a job_id and
              record it on the conversation row (job_status=running). From then on the FE
              polls GET /jobs/status. Runs AFTER the conversation row is saved, so the row
              exists to update.

        Security and production notes:
            1. `params` are the agent's own arguments, passed through by name -- the flow
               decided what this kind of job needs, and JobRunner decides which class
               provides it.
            2. The baseline is captured at TRIGGER time so a later poll can tell OUR fresh
               device report apart from a stale one left by a previous run. Without it, an
               old run-state row reads as a finished result the instant we start.
            3. start() raises rather than inventing a job_id, so a failure here becomes a
               TurnFailed in the caller instead of a conversation that polls forever.

        Args:
            user_id: Owner of the conversation.
            conv_id: The conversation the job belongs to.
            pending: The {"kind", "params"} intent, or None/empty for nothing to do.

        Returns:
            None.
        """
        if not pending:  # Most turns request no job at all                                          # any job?
            return  # Nothing to dispatch                                                            # skip
        job_id = self._jobs.start(  # Raises rather than returning a fake id                         # trigger
            pending["kind"], conv_id, pending.get("params") or {}  # Spread by name in JobRunner     # kind+params
        )
        # Capture the baseline at trigger time so a later poll can tell OUR fresh device
        # report apart from a stale one left by a previous run.
        self._conversations.start_job(  # Sets job_status=running and clears job_output              # record job
            user_id, conv_id, job_id, self._jobs.baseline_stamp()  # Freshness gate for polls        # baseline
        )
