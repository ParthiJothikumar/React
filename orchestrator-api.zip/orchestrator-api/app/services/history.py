####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# HistoryService: the read-only queries behind the sidebar and the transcript replay.              #
#   1. list_sessions(): the left panel -- a user's most recent still-active sessions.              #
#   2. get_transcript(): every message we actually showed, for one session, in order.              #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported. Both repositories arrive as constructor arguments, so this service      #
#       runs against a stub with no database at all.                                               #
####################################################################################################
"""HistoryService: the read-only queries.

What this module is:
    - One class with two read methods, over the conversation and session repositories.

Why this exists:
    - These are the only two endpoints that touch no agent and no flow, so they get their
      own service rather than being folded into ChatService.

Security and production notes:
    1. No timer and no trace: these calls touch no agent, so there is nothing to time
       against an agent budget, and adding rows for them would dilute the tables that exist
       to explain slow turns.
    2. Both methods are scoped by user_id at the repository, so one user's id cannot read
       another user's sessions or transcript.
    3. The transcript is built from conversation_turns -- the exact text shown to the user
       -- so raw device output and agent JSON can never appear in it.
"""


# ======================================== History service =========================================
class HistoryService:
    """Read-only queries -- these ARE served straight from the DB.

    What this class is:
        - Two methods: the sidebar list, and the flattened transcript for one session.

    Why it exists:
        - No timer and no trace: these calls touch no agent, so there is nothing to time
          against an agent budget, and adding rows for them would dilute the tables that
          exist to explain slow turns.

    Security and production notes:
        1. Both repositories are injected, so a test drives this with no database.

    Example:
        >>> HistoryService(conv_repo, sess_repo).list_sessions("u1")  # doctest: +SKIP
        {'sessions': [...]}
    """

    def __init__(self, conversations, sessions) -> None:
        """Adopt the two repositories; hold no other state.

        Args:
            conversations: ConversationRepository, for list_by_session and load_turns.
            sessions: SessionRepository, for the sidebar query.

        Returns:
            None.
        """
        self._conversations = conversations  # Conversation rows plus the transcript rows            # conv repo
        self._sessions = sessions  # The sidebar's own table                                         # session repo

    def list_sessions(self, user_id: str) -> dict:
        """Sidebar data: a user's most recent sessions, newest first.

        What this method does:
            - Wraps SessionRepository.list_recent() in the {"sessions": [...]} envelope.

        Why it exists:
            - Messages are not included -- the frontend fetches those per session via
              get_transcript(). Loading every transcript to render a sidebar would read the
              whole of a user's history on every page load.

        Args:
            user_id: Owner whose sessions to list.

        Returns:
            {"sessions": [...]} -- up to 20 rows, most recently updated first.

        Example:
            >>> svc.list_sessions("u1")  # doctest: +SKIP
            {'sessions': [{'id': 's2', 'title': 'Outlook crashes'}]}
        """
        return {"sessions": self._sessions.list_recent(user_id)}  # Capped at 20 by the repository   # sidebar

    def get_transcript(self, user_id: str, session_id: str) -> dict:
        """Return the session's messages as a flat list of {role, content}.

        What this method does:
            - Walks the session's still-active conversations in order and concatenates each
              one's recorded turns into a single flat list.

        Why it exists:
            - `conversations` is every turn we showed the user (from conversation_turns,
              Approach A), concatenated in order -- no other conversation metadata. The FE
              renders one continuous thread, so it wants one flat list rather than a
              nesting it would have to flatten itself.

        Security and production notes:
            1. Reads conversation_turns, which holds the EXACT text shown to the user
               post-translation. Raw device output (job_output) and agent JSON are in other
               columns and are never part of this result.
            2. One query per conversation in the session. That is bounded in practice
               because list_by_session excludes ended conversations, but it is the read to
               watch if a session ever accumulates many active conversations.

        Args:
            user_id: Owner of the session.
            session_id: The session whose transcript to assemble.

        Returns:
            {"user_id", "session_id", "conversations"} where conversations is the flat list.

        Example:
            >>> svc.get_transcript("u1", "s1")["conversations"]  # doctest: +SKIP
            [{'role': 'user', 'content': 'hi'}, {'role': 'assistant', 'content': 'hello'}]
        """
        conversations = []  # Flat accumulator: the FE renders one continuous thread                 # accumulator
        for row in self._conversations.list_by_session(user_id, session_id):  # Oldest first, by seq  # each conv
            conversations.extend(  # Append this conversation's turns, in display order              # add turns
                self._conversations.load_turns(user_id, row["conversation_id"])
            )
        return {
            "user_id": user_id,  # Echoed so the FE can key its state                                # user id
            "session_id": session_id,  # Which session this transcript belongs to                    # session id
            "conversations": conversations,  # The flat [{role, content}] list                       # messages
        }
