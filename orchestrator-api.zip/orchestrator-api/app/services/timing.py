####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# TurnTimer: measures ONE served request and writes both timing tables when it finishes.           #
#   1. Start a monotonic clock at the top of the service method, before any agent or DB work.      #
#   2. finish(): flush the agent_calls rows, write the api_requests row, emit one log event.       #
#   3. Never raise -- it runs in a `finally`, so a bookkeeping failure must not mask the outcome.  #
#                                                                                                  #
# Source:-                                                                                         #
#   - time.perf_counter provides the MONOTONIC duration; datetime (UTC) provides the wall-clock    #
#       start stamp that is actually stored.                                                       #
#   - Both repositories and the structured logger arrive as constructor arguments, so a test can   #
#       build a TurnTimer with none of them and it simply measures nothing.                        #
####################################################################################################
"""TurnTimer: measures one served request and writes both timing tables.

What this module is:
    - One class, held per request (deps.py builds it alongside the trace), because it
      carries this request's start time.

Why this exists:
    - So every served request lands in api_requests -- including the ones that returned
      early or failed before reaching an agent, which are the interesting ones.

Security and production notes:
    1. WHERE IT IS WRITTEN -- from a `finally`, AFTER the transaction() block.
       Both repositories share this request's connection, so their commit is that
       connection's commit. Called inside an open transaction() they would commit the
       turn's half-written work early and defeat the all-or-nothing boundary. Once the
       block has exited there is nothing in flight for the commit to catch.
       And in a `finally` so it runs on the FAILURE path too -- which is when both tables
       matter most. The agent_calls row holds the error of the call that broke the turn, and
       the api_requests row is the slow/failed request a latency chart most needs. Tie
       either to the rolled-back transaction and that evidence is discarded with it.
    2. WHAT duration_ms MEANS -- it is measured from the start of the service method, not
       from the edge. So it covers the agent calls, the flow, translation and the DB writes,
       but NOT FastAPI's request parsing and response serialization. Those are single-digit
       milliseconds against turns of 1-4 seconds. True edge-to-edge would need middleware,
       and middleware runs outside the Depends lifecycle -- the DB connection is already
       closed by then, so it would need its own, doubling connection demand per request.
    3. The log event carries NO user_id and no message text: these records can be forwarded
       to Splunk, outside the tenant. user_id is an email address, so it stays in SQL where
       the row is keyed by it anyway.
"""

# ============================================ Imports =============================================
import time  # perf_counter supplies the monotonic clock the duration is measured with               # stdlib time
from datetime import datetime, timezone  # Wall-clock UTC stamp that is actually stored              # stdlib datetime


# =========================================== Turn timer ===========================================
class TurnTimer:
    """Measures one served request and writes both timing tables when it finishes.

    What this class is:
        - A start stamp plus one finish() call that writes the agent_calls rows, the
          api_requests row and one structured log line.

    Why it exists:
        - Held per request (deps.py builds it alongside the trace), because it carries this
          request's start time. Every collaborator is optional, so a test can build one that
          measures nothing.

    Security and production notes:
        1. Must be called from a `finally`, AFTER any transaction() block -- see the module
           docstring for both halves of that rule.
        2. finish() never raises: it runs in a finally, and a failure here would replace the
           turn's real outcome with a bookkeeping exception.

    Example:
        >>> timer = TurnTimer("chat")  # doctest: +SKIP
        >>> timer.finish("u1", "c1")  # doctest: +SKIP
    """

    def __init__(
        self, endpoint: str, agent_calls=None, api_requests=None, trace=None,
        logger=None,
    ) -> None:
        """Start the clock and adopt the (all optional) collaborators.

        Args:
            endpoint: Route label stored on the api_requests row, e.g. "chat".
            agent_calls: AgentCallRepository, or None to skip the trace rows.
            api_requests: ApiRequestRepository, or None to skip the timing row.
            trace: This request's CallTrace, whose rows are flushed by finish().
            logger: A StructuredLogger, or None to skip the log event.

        Returns:
            None.
        """
        self._endpoint = endpoint  # Route label; a fixed literal, never user input                  # endpoint
        self._agent_calls = agent_calls  # Optional, so tests can build a timer with none            # trace repo
        self._api_requests = api_requests  # Optional, so tests can build a timer with none          # timing repo
        self._trace = trace  # Holds this request's rows until finish() flushes them                 # trace
        # A StructuredLogger, or None. Given the same numbers the api_requests row gets,
        # so the SQL table and Splunk cannot disagree about a turn.
        self._logger = logger  # Optional structured logger for the turn_completed event             # logger
        self._t0 = time.perf_counter()  # Monotonic start: the duration is measured from here        # start clock
        # Wall clock for storage; perf_counter (monotonic) for the duration, so an NTP
        # adjustment mid-request cannot produce a negative number.
        self._started_at = datetime.now(timezone.utc).isoformat()  # Stored, not measured with       # start stamp

    def finish(self, user_id: str, conv_id=None, *, failed: bool = False) -> None:
        """Write the agent_calls rows, the api_requests row, and one log event.

        What this method does:
            - Copies the trace rows, sums their durations into agent_ms, computes the total
              duration, then writes each of the three sinks that is configured.

        Why it exists:
            - Never raises: this runs in a finally, and a failure here would replace the
              turn's real outcome -- success or a useful error -- with a bookkeeping
              exception. (Both repositories swallow their own failures, which is what makes
              that true.)

        Security and production notes:
            1. agent_ms is summed from the rows we already hold -- no extra read. An
               untraced call simply is not counted, which is the honest answer: we cannot
               report time we did not measure.
            2. The trace rows are CLEARED after they are written, so a retry on the same
               object cannot double-write them.
            3. The api_requests row is written even with no agent rows at all: a status poll
               that returned early, or a request that failed before reaching an agent, still
               gets its timing.
            4. The log line carries no user_id and no message text -- it can leave the
               tenant. duration_ms minus agent_ms is our own overhead, which is the question
               worth asking of a slow turn: was the wait us, or the agents?

        Args:
            user_id: Owner of the conversation; keys both table rows.
            conv_id: The conversation, or None when the request never resolved one.
            failed: True when the request did not succeed; sets is_error and WARNING level.

        Returns:
            None.

        Example:
            >>> TurnTimer("chat").finish("u1", "c1", failed=True)  # doctest: +SKIP
        """
        rows = list(self._trace.rows) if self._trace else []  # Copy: the trace is cleared below     # take rows
        # Summed from the rows we already hold -- no extra read. An untraced call simply
        # is not counted, which is the honest answer: we cannot report time we did not
        # measure.
        agent_ms = sum(int(r.get("duration_ms") or 0) for r in rows) if rows else None  # None, not 0  # agent ms
        duration_ms = int((time.perf_counter() - self._t0) * 1000)  # Monotonic delta, in ms         # total ms

        if self._agent_calls is not None and rows:  # Nothing to write when nothing was traced       # any rows?
            self._agent_calls.append_calls(user_id, conv_id, rows)  # Its own commit; never raises   # write trace
            self._trace.rows.clear()  # a retry on the same object cannot double-write               # clear rows

        if self._api_requests is not None:  # Written for EVERY served request                       # timing on?
            # Written even with no agent rows at all: a status poll that returned early,
            # or a request that failed before reaching an agent, still gets its timing.
            self._api_requests.add(  # Its own commit; never raises                                  # write timing
                user_id, conv_id, self._endpoint, duration_ms,  # Who, what, how long                # row
                agent_ms=agent_ms,  # NULL when nothing was traced                                   # agent ms
                is_error=failed,  # Stored as 0/1                                                    # error flag
                started_at=self._started_at,  # The wall-clock start, not "now"                      # start stamp
            )

        if self._logger is not None:  # Structured logging is optional per service                   # logging on?
            # correlation_id is the conversation_id, so this line joins to every other
            # line of the same conversation -- the agents' own, and the flow's.
            #
            # No user_id and no message text: these records can be forwarded to Splunk,
            # outside the tenant. user_id is an email address, so it stays in SQL where
            # the row is keyed by it anyway.
            self._logger.log(  # Same numbers as the SQL row, so the two cannot disagree             # log event
                event="turn_completed",  # A NAME, so dashboards can count it                        # event
                correlation_id=conv_id or "unknown",  # Joins to every other line of the turn        # correlation
                level="WARNING" if failed else "INFO",  # A failed turn is findable by level         # level
                endpoint=self._endpoint,  # Route label, for per-endpoint charts                     # endpoint
                duration_ms=duration_ms,  # Total time inside the service method                     # total ms
                # duration_ms - agent_ms is our own overhead, which is the question worth
                # asking of a slow turn: was the wait us, or the agents?
                agent_ms=agent_ms,  # Time inside agents; NULL when none were traced                 # agent ms
                agent_calls=len(rows),  # How many agent calls this turn made                        # call count
                is_error=failed,  # Same flag as the SQL row                                         # error flag
            )
