####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The response dicts every service return path shares, built in exactly one place.                 #
#   1. visible(): drop blank lines BEFORE both the response and the transcript write.              #
#   2. join(): collapse a turn's lines into the single `answer` string the FE also reads.          #
#   3. chat_payload() / job_payload(): the two response shapes, identical on every path.           #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.core.constants.DONE is the single source of the `done` flag, so the FE's "is this over"  #
#       test and the stage machine's terminal stage can never disagree.                            #
####################################################################################################
"""Response shaping: the dicts every service return path shares.

What this module is:
    - Four small pure functions: two that clean up a turn's message list, and two that
      build the response dicts.

Why this exists:
    - Module functions rather than a class, because they hold no state -- they just build
      the payload. Kept in one place so /chat, /chat/continue and /jobs/status cannot drift
      into returning three slightly different shapes for the same thing, which is exactly
      what a frontend then has to special-case.

Security and production notes:
    1. `done` is derived from DONE rather than passed in by each caller, so no return path
       can claim a conversation is finished when the stage machine disagrees.
    2. Nothing here adds a field: whatever the service hands over is what goes out. Raw
       device output never reaches these functions -- see app/domain/run_state.py.
"""

# ============================================ Imports =============================================
from app.core.constants import DONE  # Single source of the terminal stage, for `done`               # constants


# ======================================== Message helpers =========================================
def join(messages) -> str:
    """Collapse a turn's lines into the single `answer` string the FE also reads.

    Args:
        messages: The turn's assistant lines, already filtered by visible().

    Returns:
        The lines joined by a blank line; "" when there are none.

    Example:
        >>> join(["Ticket INC1 raised.", "Diagnostics started."])
        'Ticket INC1 raised.\\n\\nDiagnostics started.'
    """
    return "\n\n".join(msg for msg in messages if msg)  # Blank line between bubbles                 # join lines


def visible(messages) -> list:
    """Drop blank/whitespace-only lines.

    What this function does:
        - Returns only the messages that have non-whitespace content.

    Why it exists:
        - Applied BEFORE both the response and the transcript write, so the two cannot
          disagree: ConversationRepository.append_turns skips blank content, and without
          this the FE would render an empty bubble that vanished on refresh.

    Args:
        messages: The turn's assistant lines, possibly containing blanks.

    Returns:
        The non-blank lines, in order.

    Example:
        >>> visible(["Done.", "", "   "])
        ['Done.']
    """
    return [m for m in messages if m and m.strip()]  # Must match append_turns' own filter           # drop blanks


# ======================================= Response payloads ========================================
def chat_payload(user_id, session_id, conversation_id, stage, messages, answer) -> dict:
    """Shape the JSON a chat turn returns (identical across every return path).

    Args:
        user_id: The caller's id, echoed back.
        session_id: The session this turn belongs to.
        conversation_id: The Foundry conversation id.
        stage: The stage the conversation is now on.
        messages: The turn's assistant lines, already filtered.
        answer: The same lines joined, for clients that read one string.

    Returns:
        The chat response dict.

    Example:
        >>> chat_payload("u1", "s1", "c1", "DONE", ["Bye"], "Bye")["done"]
        True
    """
    return {
        "user_id": user_id,  # Echoed so the FE can key its state without tracking it                # user id
        "session_id": session_id,  # What the FE sends back on /chat/continue                        # session id
        "conversation_id": conversation_id,  # The Foundry conversation id                           # conv id
        "stage": stage,  # The real stage, so a failed turn does not reset the chat                  # stage
        "done": stage == DONE,  # Derived, never passed in, so it cannot disagree                    # done flag
        "messages": messages,  # One bubble per line, already filtered by visible()                  # bubbles
        "answer": answer,  # The same content as one string                                          # answer
    }


def job_payload(
    user_id, session_id, conversation_id, stage, *, done, messages, answer=None
) -> dict:
    """Shape the JSON the FE spinner expects (consistent across every return path).

    What this function does:
        - Same shape as chat_payload, except `done` is passed in and `answer` defaults to
          the joined messages.

    Why it exists:
        - A poll is "done" when the JOB finished, which is not the same question as whether
          the CONVERSATION reached DONE -- so this one flag cannot be derived from the stage.

    Args:
        user_id: The caller's id, echoed back.
        session_id: The session this conversation belongs to.
        conversation_id: The Foundry conversation id.
        stage: The stage the conversation is now on.
        done: Whether the JOB has finished; the FE stops polling on True.
        messages: The lines to show, already filtered.
        answer: Override for the joined string; defaults to join(messages).

    Returns:
        The job-status response dict.

    Example:
        >>> job_payload("u1", "s1", "c1", "AWAITING_PROCEED", done=True,
        ...             messages=["No issues found."])["answer"]
        'No issues found.'
    """
    return {
        "user_id": user_id,  # Echoed so the FE can key its state without tracking it                # user id
        "session_id": session_id,  # Which sidebar entry this poll belongs to                        # session id
        "conversation_id": conversation_id,  # The Foundry conversation id                           # conv id
        "stage": stage,  # Where the flow now is, after any advance                                  # stage
        "done": done,  # The JOB's state, NOT the conversation's -- so it is passed in               # done flag
        "messages": messages,  # One bubble per line, already filtered                               # bubbles
        "answer": answer if answer is not None else join(messages),  # Default to the joined lines   # answer
    }
