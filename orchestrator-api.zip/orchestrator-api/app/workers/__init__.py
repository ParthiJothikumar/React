####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Package marker and map for `app.workers` -- background work that runs on no user's request.      #
#   1. Declare app.workers as a package so the lifespan in main.py can import the reaper.          #
#   2. Record the rule for this package: a worker owns SCHEDULING only, never business logic.      #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported here. Each worker imports the SAME service methods an endpoint calls,    #
#       so the background path and the request path cannot drift apart.                            #
####################################################################################################
"""Background work that runs inside the app, on no user's request.

What this package is:
    - One worker today:

        reaper.py   sweeps conversations whose device job nobody is watching any more

Why this exists:
    - A worker is started by the app's lifespan (main.py) and cancelled on shutdown. The
      rule for this package: a worker owns SCHEDULING only -- when to run, how often, what
      to do about a failure -- and calls the same service methods an endpoint calls. No
      business logic here, or the background path and the request path would drift apart,
      and only one of them would be tested.

Security and production notes:
    1. Anything in here needs ALWAYS ON to keep running: a task inside the app cannot wake
       an app the platform has idled out. See the module docstring in reaper.py.
    2. A worker runs in EVERY gunicorn worker and on EVERY instance, so anything it does
       must be safe to do N times concurrently.
"""
