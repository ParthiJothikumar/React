####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The job reaper: finish off device jobs whose user stopped watching them.                         #
#   1. sweep_once(): one pass, on its own connection, through JobService.sweep_running_jobs().     #
#   2. run_forever(): sweep on an interval until cancelled, surviving any single failure.          #
#   3. Jitter the first sweep, so instances that start together do not sweep in lockstep.          #
#                                                                                                  #
# Source:-                                                                                         #
#   - asyncio provides the interval loop and to_thread, which keeps the blocking sweep off the     #
#       event loop; random provides the start jitter.                                              #
#   - app.core.config.logger records every sweep, including the empty ones.                        #
#   - app.deps supplies the process-wide Database and the JobService factory, so a sweep runs      #
#       the SAME code path the frontend's poll runs.                                               #
####################################################################################################
"""The job reaper: finish off device jobs nobody is watching.

What this module is:
    - Two functions: sweep_once() (one blocking pass) and run_forever() (the interval loop
      the lifespan starts as an asyncio task).

Why this exists:
    - A job only ever moves forward when the FRONTEND polls GET /jobs/status. So if the
      user closed their tab -- or slept the laptop, or lost signal -- the conversation
      stayed in DIAGNOSTICS_RUNNING permanently: the stage never advanced, the ServiceNow
      ticket kept saying "Automated diagnostics started" and nothing more, and it sat in
      their sidebar as an active chat that did nothing. The old give-up rule couldn't help,
      because it counted POLLS, and a poll only happens while a browser is open.
    - WHAT IT DOES. Every REAPER_INTERVAL_SECONDS it asks for conversations still parked in
      a RUNNING stage and puts each one through JobService.advance_job() -- the exact method
      the FE poll calls. So a sweep and a poll are indistinguishable to the rest of the
      system: same status check, same compare-and-swap, same transaction, same tests.
    - Mostly it finds nothing. If the user is watching, their own poll advances the job
      first and the sweep is a no-op (their conversation is filtered out by
      REAPER_STALE_MINUTES). It only matters for the conversations that were abandoned.

Security and production notes:
    1. IT NEEDS "ALWAYS ON". This was an Azure Functions timer trigger; on App Service
       there is no platform timer, so it is an asyncio task started by the app's lifespan.
       A task inside the app cannot wake an app that has idled out, which the platform
       timer could. Without Always On the sweeps simply stop, and abandoned jobs are never
       finished -- the bug this module exists to prevent.
    2. IT RUNS ON EVERY INSTANCE (and in every gunicorn worker), where the timer trigger
       took a lease and ran once. That is SAFE rather than merely tolerable: the sweep only
       selects jobs nobody has touched for REAPER_STALE_MINUTES, and the conditional UPDATE
       in advance_after_job() is a compare-and-swap, so exactly one sweeper can complete any
       given job. The cost is duplicated READS -- raise the interval, not the batch size, if
       that ever shows up in DTU.
    3. The sweep itself is blocking (SQL plus agent calls), so it runs in a worker thread
       via asyncio.to_thread. Running it directly on the event loop would stall every
       request being served by this worker for the length of the sweep.
    4. It does NOT notify anyone. It makes the state correct; telling the user their
       diagnostic finished while they were away is a separate feature (email / Teams /
       SignalR).
"""

# ============================================ Imports =============================================
import asyncio  # The interval loop, plus to_thread to keep the blocking sweep off the loop          # stdlib asyncio
import random  # Start jitter, so instances that deploy together do not sweep in lockstep            # stdlib random

from app.core.config import logger  # Records every sweep, including the empty ones                  # config
from app.deps import database, make_job_service  # Same objects the request path uses                # composition root

# =========================================== Constants ============================================
# Cap on the random start delay. Without it, every instance that starts after a deploy
# sweeps at the same moment for the life of the process; with it they spread out and stay
# spread out.
MAX_START_JITTER_SECONDS = 60  # Upper bound on the pre-first-sweep delay, in seconds                # jitter cap


# =========================================== One sweep ============================================
def sweep_once() -> dict:
    """One sweep, on its own connection. Blocking -- call it in a thread.

    What this function does:
        - Opens a connection, builds a JobService on it, runs sweep_running_jobs(), logs
          the tallies, and closes the connection in a `finally`.

    Why it exists:
        - Its own connection because there is no request here and so no Depends-managed
          one, and it is closed in a `finally` for the same reason: a leaked connection per
          sweep would exhaust the pool in a day.

    Security and production notes:
        1. Logged at INFO even when empty: a silent reaper and a dead reaper look the same
           otherwise, and this is the line that proves it is alive.
        2. This calls the SAME service method the frontend's poll calls, so a sweep cannot
           behave differently from a poll -- including its compare-and-swap.

    Returns:
        The sweep tallies: {found, advanced, still_running, failed}.

    Example:
        >>> sweep_once()  # doctest: +SKIP
        {'found': 2, 'advanced': 1, 'still_running': 1, 'failed': 0}
    """
    conn = database.connect()  # Our own connection: there is no request-scoped one here             # open conn
    try:  # Everything below must run with the connection guaranteed to be closed after              # sweep try
        result = make_job_service(conn).sweep_running_jobs()  # The FE poll's own code path          # do sweep
        # Logged at info even when empty: a silent reaper and a dead reaper look the same
        # otherwise, and this is the line that proves it is alive.
        logger.info(  # Four tallies, so a sweep that found nothing is still visible                 # log info
            "reaper sweep: found=%s advanced=%s still_running=%s failed=%s",
            result["found"], result["advanced"],
            result["still_running"], result["failed"],
        )
        return result  # Returned for tests; run_forever() ignores it                                # return tally
    finally:  # A leaked connection per sweep would exhaust the pool within a day                    # always
        conn.close()  # Return it to the driver's pool                                               # close conn


# ============================================ The loop ============================================
async def run_forever(interval_seconds: int) -> None:
    """Sweep every `interval_seconds` until cancelled.

    What this function does:
        - Sleeps a random jittered interval, then loops forever: run one sweep in a worker
          thread, swallow any Exception, and sleep again.

    Why it exists:
        - Never lets an exception end the loop: a sweep that fails must not stop every LATER
          sweep, which is what makes this a backstop rather than a single attempt.

    Security and production notes:
        1. CancelledError is re-raised untouched so shutdown is immediate. It derives from
           BaseException, so the `except Exception` below would not catch it anyway -- it is
           caught explicitly to say that this is intended.
        2. Sleep BEFORE the first sweep: at startup every running job was just being polled
           by somebody, and a burst of DB work while the app is still warming helps nobody.
        3. asyncio.to_thread is what keeps the blocking sweep off the event loop, so requests
           served by this worker are not stalled for the length of a sweep.

    Args:
        interval_seconds: Seconds between sweeps (Settings.REAPER_INTERVAL_SECONDS).

    Returns:
        None. Only ever exits by cancellation.

    Raises:
        asyncio.CancelledError: On shutdown, re-raised so the lifespan's cancel() completes.

    Example:
        >>> asyncio.create_task(run_forever(300))  # doctest: +SKIP
    """
    # Sleep BEFORE the first sweep: at startup every running job was just being polled by
    # somebody, and a burst of DB work while the app is still warming helps nobody.
    await asyncio.sleep(random.uniform(0, min(interval_seconds, MAX_START_JITTER_SECONDS)))  # Spread instances out  # jitter
    while True:  # Runs until the lifespan cancels this task at shutdown                             # forever
        try:  # One sweep; a failure must cost this sweep only, never the loop                       # sweep try
            await asyncio.to_thread(sweep_once)  # Blocking work off the event loop                  # run sweep
        except asyncio.CancelledError:  # Shutdown -- propagate so cancel() completes at once        # cancelled
            raise  # BaseException, so `except Exception` would miss it; explicit for clarity        # re-raise
        except Exception:  # Any sweep failure: log it and keep the loop alive                       # sweep failed
            logger.exception("reaper sweep failed")  # A later sweep will pick the jobs up           # log error
        await asyncio.sleep(interval_seconds)  # Wait out the interval, then sweep again             # wait
