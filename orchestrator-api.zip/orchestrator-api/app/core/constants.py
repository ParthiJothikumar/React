####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Domain constants -- the fixed vocabulary of the support flow. NOT configuration.                 #
#   1. Name every stage the conversation can sit in, plus the RUNNING set the flow skips.          #
#   2. Pin the exact labels each agent is ALLOWED to return, so drift is detectable.               #
#   3. Hold the fixed user-facing lines the flow sends when there is nothing to quote.             #
#   4. Name the job kinds and the job_status values written to the conversations row.              #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported: these are literals, not derived values. Anything read from an env var   #
#       or an App Service Application Setting belongs on the Settings class in config.py instead,  #
#       because it can differ per environment; everything here is the same in every environment.   #
####################################################################################################
"""Domain constants -- the vocabulary of the support flow.

What this module is:
    - The fixed names the stage machine, the agents and the job pipeline agree on: stage
      strings, the allowed agent return labels, the canned user-facing lines, and the job
      kind / status values.

Why this exists:
    - These are NOT configuration: they are fixed parts of the domain, so they stay plain
      module-level constants rather than moving onto the Settings class in config.py.
      Anything read from an env var / App Setting belongs there instead.
    - Collecting the allowed agent labels here is what makes "drift" checkable. The flow
      compares an agent's answer against these sets, so an unexpected label is logged and
      handled safely instead of falling through to whichever branch happens to match.

Security and production notes:
    1. VALID_ISSUE_TYPES and VALID_MODES are the drift guards on the two classification
       agents. An unrecognised label must never reach the incident-creating or
       machine-remediating branches, so both sets fail CLOSED (see flow.py).
    2. The frozenset types are deliberate: a set literal could be mutated at runtime by
       any importer, which would silently widen what the flow is prepared to accept.
"""

# ========================================== Flow stages ===========================================
# One string per state the conversation can be parked in between turns. The value is written
# verbatim to conversations.stage, so renaming one is a data migration, not a refactor.
AWAITING_ISSUE = "AWAITING_ISSUE"  # Greeting loop: waiting for the user to name an Outlook issue    # stage
AWAITING_CLASSIFY = "AWAITING_CLASSIFY"  # First classification agent still gathering detail         # stage
AWAITING_RESOLVED = "AWAITING_RESOLVED"  # Manual steps shown; waiting for "did that fix it?"        # stage
AWAITING_PROCEED = "AWAITING_PROCEED"  # Diagnostics done; waiting for "proceed to fix?"             # stage
AWAITING_FINAL = "AWAITING_FINAL"  # Troubleshoot done; waiting for the final resolved answer        # stage
# ask_user follow-up turn (a chat-await, NOT a RUNNING stage): the second classification agent
# asked a question and we are waiting for the user's reply. It is kept distinct from
# AWAITING_CLASSIFY because the reply is routed back to the SECOND agent, not the first.
AWAITING_FOLLOWUP = "AWAITING_FOLLOWUP"  # Second classification agent asked; awaiting the answer    # stage
DONE = "DONE"  # Terminal: a further turn raises ConversationEnded (-> 409)                          # stage

# Diagnostics/Troubleshoot run as long-running ASYNC jobs (3-15 min, Intune on the client
# machine). The flow does NOT block: it starts the job and enters one of these "running"
# stages; the FE polls GET /jobs/status, which checks the agent's status live and advances
# the flow when the job finishes.
DIAGNOSTICS_RUNNING = "DIAGNOSTICS_RUNNING"  # Diagnostics job in flight; chat turns just wait       # stage
TROUBLESHOOT_RUNNING = "TROUBLESHOOT_RUNNING"  # Remediation job in flight; chat turns just wait     # stage
# Membership test used by SupportFlow.step(): a turn arriving on either of these gets a
# "still working" reply and KEEPS its stage, rather than being dispatched to a handler.
RUNNING_STAGES = frozenset({DIAGNOSTICS_RUNNING, TROUBLESHOOT_RUNNING})  # The two job-in-flight stages  # stage set

# =========================== Agent response vocabularies (drift guards) ===========================
# Allowed issue_type values returned by the ORCHESTRATOR agent. Anything outside this set is
# classification drift: it is logged and handled as non_it (re-prompt), so an unexpected
# label can never silently create an incident.
ISSUE_GREETING = "greeting"  # "hi" / "hello" -- no issue stated yet, so re-prompt                   # issue type
ISSUE_NON_IT = "non_it"  # Not an IT question at all (HR, payroll) -- re-prompt, no ticket           # issue type
ISSUE_NON_OUTLOOK_IT = "non_outlook_it"  # Real IT issue, wrong queue -> raise a ticket and end      # issue type
ISSUE_OUTLOOK_IT = "outlook_it"  # In scope -> raise a ticket, then run the classification flow      # issue type
VALID_ISSUE_TYPES = frozenset(  # The closed set flow.py checks before it acts on issue_type         # drift guard
    {ISSUE_GREETING, ISSUE_NON_IT, ISSUE_NON_OUTLOOK_IT, ISSUE_OUTLOOK_IT}
)

# Allowed mode values returned by the SECOND classification agent. An unexpected value is
# logged and handled as MODE_MANUAL (show steps, ask the user), so a drift can never
# silently trigger automated diagnostics on somebody's machine.
MODE_MANUAL = "manual"  # Hand the user written steps and ask whether they worked                    # mode
MODE_AUTOMATE = "automate"  # Safe to run diagnostics/remediation without the user doing anything    # mode
VALID_MODES = frozenset({MODE_MANUAL, MODE_AUTOMATE})  # The closed set; fails to MODE_MANUAL        # drift guard

# action values returned by the SECOND classification agent's richer contract
# (ValidationResponse). NOTE the automate value is "automatic" here, NOT "automate" -- the two
# vocabularies came from different agent versions and both are still in use, so they are kept
# as separate constants rather than being "tidied" into one.
ACTION_MANUAL = "manual"  # ValidationResponse spelling of the manual path (M1)                      # action
ACTION_AUTOMATIC = "automatic"  # ValidationResponse spelling of the automated path (A1/U3)          # action

# ==================================== Fixed user-facing lines =====================================
# Single user-safe line shown on a failure that carries no agent_message. The raw technical
# `error` is stored in flow_vars["last_error"] and logged -- it is never shown, because it can
# name internal endpoints, scripts and identifiers.
SECOND_CLASS_FALLBACK = (  # Shown when an agent fails without a user-safe message of its own        # fallback
    "Sorry, we couldn't complete this automatically. A support team member "
    "will follow up to help."
)

# Non-actionable messages (greeting or general/non-IT): the orchestrator re-prompts for an
# Outlook issue up to Settings.MAX_NONACTIONABLE times (one shared counter across both kinds),
# then ends the conversation. No incident is created for these; the interaction opened at the
# start of every conversation is closed when the conversation ends.
GREETING_PROMPT = "Hi! How can I help you with your Outlook issue?"  # Reply to a bare greeting      # prompt
NON_IT_PROMPT = "This is Outlook IT support -- what Outlook issue can I help you with?"  # Off-topic reply  # prompt
NONACTIONABLE_END_MESSAGE = (  # Sent once the re-prompt cap is exceeded, then the flow ends         # end line
    "Thanks for contacting. For any Outlook support, please start a new conversation."
)

# =========================================== Async jobs ===========================================
# Which agent a started job belongs to. JobRunner maps the kind to the agent object, so these
# two strings are the whole dispatch vocabulary -- there are no start/status URLs any more.
JOB_KIND_DIAGNOSTIC = "diagnostic"  # Read-only investigation; feeds into troubleshoot afterwards    # job kind
JOB_KIND_TROUBLESHOOT = "troubleshoot"  # Remediation that CHANGES the user's machine                # job kind

# Values written to conversations.job_status. The reaper and the FE poll both read this column,
# so a job is only ever advanced out of JOB_RUNNING by a compare-and-swap (see jobs.py).
JOB_RUNNING = "running"  # Started and not yet finished; the stage is one of RUNNING_STAGES          # job status
JOB_DONE = "done"  # Finished successfully; job_message carries the user-safe outcome                # job status
JOB_FAILED = "failed"  # Failed OR timed out; the flow escalates and leaves the ticket open          # job status
JOB_TERMINAL = frozenset({JOB_DONE, JOB_FAILED})  # Membership test for "stop polling this job"      # status set
