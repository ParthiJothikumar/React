####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Package marker and map for `app.core`, the cross-cutting foundation layer.                       #
#   1. Declare app.core as an importable package so `from app.core.config import settings` works.  #
#   2. Document which four modules live here and what each one owns.                               #
#   3. Record the layering rule: core is the BOTTOM of the import graph and imports no sibling.    #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported here, deliberately. Every other package imports this one, so an import   #
#       of api / services / domain / db / agents from inside core would close an import cycle and  #
#       leave no layer at the bottom for the rest of the app to be built on.                       #
####################################################################################################
"""Cross-cutting foundations: configuration, constants, errors, tracing.

What this package is:
    - The four modules every other layer is allowed to depend on:

        config.py     Settings (env / App Service Application Settings) + the shared logger
        constants.py  domain constants: stages, agent vocabularies, fixed user-facing lines
        errors.py     the framework-free error types raised below the HTTP layer
        tracing.py    CallTrace -- the agent_calls rows collected during one request

Why this exists:
    - THE BOTTOM OF THE DEPENDENCY GRAPH. Every other package imports this one; this one
      imports none of them. If something here ever needs `api`, `services`, `domain`, `db`
      or `agents`, it is in the wrong folder -- that import would turn the graph into a
      cycle and leave nothing to build the rest on.

Security and production notes:
    1. config.py is the ONLY module that reads the environment, so "where did this value
       come from?" has exactly one answer in an incident review.
    2. config.py is also the one owner of logging.basicConfig; because it is imported
       earliest it always wins, which is what keeps stdout valid JSON for the collector.
    3. errors.py stays framework-free on purpose: no status codes leak downwards, so the
       reaper and the tests can drive the same code with no web server present.

Example:
    >>> from app.core.config import settings, logger  # doctest: +SKIP
    >>> from app.core.constants import DONE           # doctest: +SKIP

The test for "does this belong in core?" is whether it would still make sense with the
web layer, the database and the agents all deleted. Settings, the stage names, the error
types and the timing rows all pass. Anything that knows what a conversation *is* does
not -- that is domain/.
"""
