####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The framework-free error vocabulary every layer BELOW the HTTP edge raises.                      #
#   1. Give domain / services / db / agents one exception hierarchy to raise instead of            #
#        fastapi.HTTPException, so none of them has to know that HTTP exists.                      #
#   2. Let api/routes/ + main.py be the single place a domain error becomes a status code.         #
#   3. Carry the few extra fields a caller genuinely cannot re-derive (TurnFailed.stage).          #
#                                                                                                  #
# Source:-                                                                                         #
#   - Only the built-in Exception type is used; this module imports nothing at all, which is what  #
#       lets the reaper sweep, a CLI script and a unit test raise and catch these with no web      #
#       server, no FastAPI and no database anywhere in the process.                                #
####################################################################################################
"""Domain errors -- the framework-free vocabulary the layers below HTTP raise.

What this module is:
    - One small exception hierarchy rooted at AppError, with the HTTP status each type is
      mapped to recorded in its docstring (the mapping itself lives in main.py).

Why this exists:
    - domain/, services/, db/ and agents/ must not know that HTTP exists, so they raise
      these instead of fastapi.HTTPException. api/routes/ (plus the handlers in main.py)
      is the ONE place that decides which status code each one becomes.
    - That is what keeps those layers callable from somewhere other than a web request --
      the reaper's background sweep, a CLI script, a unit test -- with no FastAPI involved.

Security and production notes:
    1. NotFound / ConversationEnded carry author-written text and are safe to return
       verbatim; UpstreamUnavailable / DatabaseUnavailable carry internal causes, so
       main.py logs those and replaces the body with a generic line.
    2. Starlette dispatches to the CLOSEST registered handler class, so a new subclass
       inherits its parent's status automatically instead of falling to an anonymous 500.

Example:
    >>> raise NotFound("No conversation for this user")  # doctest: +SKIP
"""

# ========================================= Base exception =========================================
class AppError(Exception):  # Root of the hierarchy; main.py registers a catch-all handler for it
    """Base class for every domain error raised below the HTTP layer.

    What this class is:
        - The single root every other error here inherits from, so one `except AppError`
          catches the whole vocabulary and one registered handler backstops all of them.

    Why this exists:
        - To give main.py a last-resort handler: a subclass added later but never mapped
          still produces a named log line rather than an anonymous 500.

    Security and production notes:
        1. Never raised directly -- always a subclass, so the mapped status is meaningful.
        2. Reaching the AppError handler in production is itself the signal that a new
           subclass needs its own mapping in main.py.

    Example:
        >>> isinstance(NotFound("x"), AppError)
        True
    """


# ====================================== Client-fault errors =======================================
class NotFound(AppError):  # -> 404; detail text is author-written and safe to return verbatim
    """A session/conversation does not exist for this user. -> 404

    What this class is:
        - The "you asked for something that isn't there" error, raised by the history and
          job lookups when a user_id / session_id pair matches no row.

    Why this exists:
        - So a missing row is a 404 rather than an empty 200, which would look to the
          frontend like a real but blank conversation.

    Security and production notes:
        1. Its message is returned to the caller as-is, so it must stay author-written --
          never interpolate a SQL error or a connection string into it.
        2. It is scoped by user_id at the query, so it also covers "exists, but not
          yours" without telling the caller which of the two happened.

    Example:
        >>> raise NotFound("No conversation for this user")  # doctest: +SKIP
    """


class ConversationEnded(AppError):  # -> 409; the stage is terminal, a new conversation is needed
    """The conversation is terminal (stage=DONE); a new one must be started. -> 409

    What this class is:
        - The conflict raised when a chat turn arrives for a conversation the stage
          machine has already finished.

    Why this exists:
        - 409 tells the frontend the request was well-formed but the conversation is
          closed, which is a different remedy from "retry" (5xx) or "not found" (404).

    Security and production notes:
        1. Raised by SupportFlow.step() when no handler matches the stage, so a stage the
           machine does not recognise ends the turn instead of falling through a branch.
        2. api/routes/ deliberately RE-RAISES this rather than swallowing it, so it
           reaches the handler in main.py and keeps its 409.

    Example:
        >>> raise ConversationEnded("Conversation already completed")  # doctest: +SKIP
    """


# ==================================== Recoverable turn failure ====================================
class TurnFailed(AppError):  # One turn broke but the conversation is intact and can be retried
    """A turn failed, but the CONVERSATION is intact and the user can retry.

    What this class is:
        - A wrapper around whatever went wrong during one chat turn, carrying the stage
          the conversation is ACTUALLY still at plus the incident number if one exists.

    Why this exists:
        - Raised only by ChatService.continue_chat. It carries the real stage because the
          HTTP layer cannot know it -- the failure happened before a stage could be
          returned.
        - Without it the response said done=True / stage=DONE, so the frontend reset a
          perfectly good conversation over one transient agent timeout. The user then
          re-described the problem from scratch and we opened a SECOND ServiceNow
          incident. With the real stage and done=False they simply resend the same
          message.

    Security and production notes:
        1. `incident_id` is set when a ServiceNow ticket was already raised before the
           failure. That changes what we tell the user: instead of "please try again" --
           which makes them start over and open a SECOND ticket -- we hand them the number
           that already exists and tell them not to. Removing the reason to retry is what
           prevents the duplicate.
        2. The original cause is preserved on __cause__ (raised with `from`), so the log
           line still shows what actually broke while the user sees only a safe line.

    Example:
        >>> raise TurnFailed("AWAITING_CLASSIFY", "conv-1", TimeoutError())  # doctest: +SKIP
    """

    def __init__(self, stage, conversation_id, cause: Exception, incident_id=None) -> None:  # Keep the real stage
        """Record the still-valid stage alongside the underlying cause.

        What this method does:
            - Uses str(cause) as the exception message so a log line shows the real
              reason, then stores the stage, conversation id and optional incident id as
              attributes for the HTTP layer to read.

        Why it exists:
            - The controller has to answer the frontend with a stage and a done flag, and
              the only place that still knows the true stage is the service that failed.

        Security and production notes:
            1. `cause` is stringified into the message for the LOG; api/routes/ builds the
               user-facing body from the stage and incident id, never from this message.
            2. incident_id defaults to None, which the controller reads as "no ticket
               exists yet", so the retry wording is chosen from real state.

        Args:
            stage: The stage the conversation is genuinely still sitting at.
            conversation_id: Id of the conversation whose turn failed.
            cause: The exception that actually broke, kept on __cause__ by the `raise from`.
            incident_id: ServiceNow incident number if one was already created, else None.

        Returns:
            None.

        Example:
            >>> TurnFailed("DONE", "c1", ValueError("boom")).stage
            'DONE'
        """
        super().__init__(str(cause))  # Message is the cause text, for the log line                  # base init
        self.stage = stage  # The stage the conversation is REALLY at, for the response              # true stage
        self.conversation_id = conversation_id  # Which conversation failed this turn                # conv id
        self.incident_id = incident_id  # Ticket number if one already exists, else None             # incident


# ====================================== Dependency failures =======================================
class UpstreamUnavailable(AppError):  # -> 502; an agent could not answer at all
    """An agent failed, cannot answer, or is not implemented yet. -> 502

    What this class is:
        - The single error every agent raises when its outbound work fails, including the
          NotImplementedError case of an agent whose `_call` hook is still a stub.

    Why this exists:
        - So the flow and the services handle "the agent did not answer" identically
          whichever agent it was, and the SDK exception type never leaks upwards.

    Security and production notes:
        1. It carries an internal cause, so main.py LOGS it and returns a generic
           "Agent call failed" body -- an SDK message can name endpoints and headers.
        2. It is NOT retried by JobService: an agent that cannot answer at all will not
           answer on a second attempt either. See UpstreamTransient for the opposite case.

    Example:
        >>> raise UpstreamUnavailable("orchestrator call failed")  # doctest: +SKIP
    """


class UpstreamTransient(UpstreamUnavailable):  # -> 502 by inheritance; the retryable variant
    """A momentary failure calling an agent -- worth retrying. -> 502

    What this class is:
        - A narrower UpstreamUnavailable meaning "this looked like a blip, not a refusal".

    Why this exists:
        - Subclasses UpstreamUnavailable so it still maps to 502 without its own handler
          (Starlette matches the closest registered class). The distinction exists for
          RETRY decisions, not for the status code: JobService retries this one and lets a
          plain UpstreamUnavailable through, because an agent that cannot answer at all
          will not answer on the second attempt either.

    Security and production notes:
        1. Only raise this where a retry is genuinely safe -- the job status poll is a
           read, so retrying it cannot start a second remediation on a user's machine.
        2. The retry budget is Settings.JOB_STATUS_RETRIES, so the blast radius of
           mis-classifying an error as transient is bounded by configuration.

    Example:
        >>> isinstance(UpstreamTransient("blip"), UpstreamUnavailable)
        True
    """


class DatabaseUnavailable(AppError):  # -> 503; the state store is unreachable or unconfigured
    """The state store is unreachable or not configured. -> 503

    What this class is:
        - The error the db layer raises when no connection can be obtained at all, as
          opposed to a query that ran and returned nothing (that is NotFound).

    Why this exists:
        - 503 says "the service is temporarily unable", which is the honest answer when
          the conversation state cannot be read or written.

    Security and production notes:
        1. Its cause routinely contains driver text and can contain the connection
           string, so main.py logs it and returns a fixed "Database unavailable" body.
        2. /health deliberately does NOT touch SQL (see main.py), so a brief SQL blip
           raises this on real requests without making the platform recycle the instance.

    Example:
        >>> raise DatabaseUnavailable("no connection string configured")  # doctest: +SKIP
    """
