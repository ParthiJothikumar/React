####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Collects the agent_calls rows produced while serving ONE request.                                #
#   1. Time each outbound agent call and record it, whether the call returns or raises.            #
#   2. Cap and serialise the request/response text so one runaway script cannot bloat the table.   #
#   3. Name the ORIGINAL cause of a failure, not just the wrapper the agent raised.                #
#   4. Offer NULL_TRACE, a no-op trace, so agents never need an "if trace is not None" branch.     #
#                                                                                                  #
# Source:-                                                                                         #
#   - json serialises a request/response object into the single text column it is stored in.       #
#   - time.perf_counter provides the MONOTONIC clock the durations are measured with.              #
#   - contextlib.contextmanager turns call() into a `with` block that also fires on an exception.  #
#   - app.core.config.logger is the shared logger used if recording a row itself fails.            #
####################################################################################################
"""The rows collected for the agent_calls table during one request.

What this module is:
    - CallTrace, a per-request collector of timing rows, plus NullTrace/NULL_TRACE for
      callers with no request to attribute rows to. Nothing here writes to the database;
      the rows are handed to the repository at the end of the request.

Why this exists:
    - The measuring happens where the outbound call is actually made -- inside each agent,
      via the `traced()` helper on agents/base.py. That is the one place every call passes
      through, so no `trace` argument has to be threaded through step(), six stage handlers
      and a dozen agent methods.
    - `call()` is a context manager rather than a decorator or a wrapper object because the
      call it measures has to be able to FAIL. The agents that swallow their own failures
      (MultilingualAgent.detect returns the previous language, ServiceNowAgent.update_incident
      logs and returns, SecondClassificationAgent returns {"success": false}) do so ABOVE
      this layer, so the row is written from inside the `except` before their handling runs.

Security and production notes:
    1. A CallTrace is created per request in deps.py and handed to that request's agents. It
       is never shared -- request 1's rows must not land in request 2's list.
    2. Every stored field passes through _field(), which caps it at MAX_FIELD characters.
       Agent payloads can contain whole scripts and device output; without the cap one call
       could write megabytes into a single row.
    3. record() is best-effort and swallows its own exceptions: it runs on the live request
       path, so a failure while recording must never turn a healthy agent call into a
       failed request.

WHAT CHANGED WHEN THE AGENTS CAME IN-PROCESS. This module used to hold a URL -> agent name
map, because the only thing an outbound POST knew about its destination was the URL (minus
the ?code= key). An agent is now a class that knows its own name, so it passes `Agent.label`
directly -- a row can no longer come out as "unknown" because a setting was blank or a query
string was not stripped.
"""

# ============================================ Imports =============================================
import json  # Serialise a request/response object into the single text column it is stored in       # stdlib json
import time  # perf_counter supplies the monotonic clock used for the durations                      # stdlib time
from contextlib import contextmanager  # Turns call() into a `with` block that also fires on an error  # stdlib ctx

from app.core.config import logger  # Shared logger, used only if recording a row itself fails       # logging

# =========================================== Constants ============================================
# Cap per column. Agent payloads can carry a whole PowerShell script or a device's raw stdout,
# so an uncapped row could write megabytes and make the agent_calls table unqueryable.
MAX_FIELD = 8000  # Max characters stored per text column before truncation                          # size cap


# ========================================= In-flight row ==========================================
class AgentCall:
    """The row of a call that is still in flight.

    What this class is:
        - A one-field mailbox handed to the body of a `with trace.call(...)` block. The
          caller assigns `response` once it has one.

    Why it exists:
        - The context manager has to write the row from BOTH the success path and the
          `except` path, so the response cannot simply be the block's return value -- it
          has to be somewhere the manager can still read after an exception.

    Security and production notes:
        1. __slots__ keeps this to a single attribute. One of these is allocated per agent
           call on the live request path, so it stays deliberately cheap.

    Example:
        >>> record = AgentCall(); record.response = {"ok": True}; record.response
        {'ok': True}
    """

    __slots__ = ("response",)  # Single attribute only: allocated on every agent call                # slots

    def __init__(self) -> None:
        """Start with no response recorded, so a call that raises still writes a row."""
        self.response = None  # Set by the `with` body; stays None if the call raised first          # response


# ======================================= Per-request trace ========================================
class CallTrace:
    """The rows collected during ONE request. deps.py builds a fresh one per request.

    What this class is:
        - A list of dicts, one per outbound agent call, each with the agent label, the
          request and response text, the duration, and the error if there was one.

    Why it exists:
        - So latency per agent is recorded once, at the only place every call goes through,
          instead of at each of the dozen call sites in the flow.

    Security and production notes:
        1. NEVER share an instance between requests: the rows are attributed to whichever
           api_request row the service writes at the end, so a shared list would file one
           user's agent calls against another user's request.
        2. The rows are held in memory for the life of the request only. A request making
           an unbounded number of agent calls would grow this list, which is why the flow
           caps its loops (Settings.MAX_NONACTIONABLE, the agent-owned follow-up count).

    Example:
        >>> trace = CallTrace()
        >>> with trace.call("orchestrator", {"m": "hi"}) as row: row.response = {"ok": 1}
        >>> len(trace.rows)
        1
    """

    def __init__(self) -> None:
        """Start with an empty row list; one CallTrace serves exactly one request."""
        self.rows = []  # Accumulated agent_calls rows, flushed by the service at request end        # rows

    @contextmanager  # Makes call() usable as `with trace.call(...) as row:`
    def call(self, agent: str, request):
        """Time one agent call and add its row, whether the call returns or raises.

        What this method does:
            - Reads the monotonic clock, yields an AgentCall for the body to attach its
              response to, then records the row. On an exception it records the row WITH
              the error and re-raises the original exception unchanged.

        Why it exists:
            - The agents that swallow their own failures do so above this layer, so the row
              has to be written from inside the `except` -- otherwise a call that failed and
              was handled gracefully would leave no trace of having happened at all.

        Security and production notes:
            1. perf_counter is monotonic, so an NTP adjustment mid-call cannot produce a
               negative duration. It is read immediately after the call returns, so our own
               JSON parsing and DB writes stay out of the number -- which is what makes it
               honestly "how long the agent took".
            2. The exception is re-raised UNCHANGED (bare `raise`), so the caller's own
               error handling still sees the original type and traceback.

        Args:
            agent: The agent's label, taken from Agent.label rather than inferred.
            request: The payload sent to the agent, stored as text after capping.

        Yields:
            An AgentCall the body assigns its `response` to.

        Raises:
            Exception: Re-raises whatever the wrapped call raised, unchanged.

        Example:
            >>> trace = CallTrace()
            >>> with trace.call("snow", {"id": 1}) as row: row.response = "IN123"
            >>> trace.rows[0]["agent"]
            'snow'
        """
        record = AgentCall()  # Mailbox the `with` body attaches its response to                     # new row
        started = time.perf_counter()  # Monotonic start stamp, taken as late as possible            # start clock
        try:  # Run the caller's block; it may return normally or raise                              # run body
            yield record  # Hand the mailbox to the `with` body                                      # yield row
        except Exception as exc:  # The agent call failed -- still record what happened              # call failed
            self.record(agent, request, record.response, _ms(started), exc)  # Row WITH the error    # log error row
            raise  # unchanged: the caller's own error handling still sees the original              # re-raise
        self.record(agent, request, record.response, _ms(started))  # Success row                    # log ok row

    def record(self, agent, request, response, duration_ms, error=None) -> None:
        """Add one row.

        What this method does:
            - Appends a single dict to self.rows, serialising and capping the request,
              response and error text on the way in.

        Why it exists:
            - Best-effort by design: this runs on the live request path, so a failure while
              recording must never turn a healthy agent call into a failed one.

        Security and production notes:
            1. Every text field goes through _field(), so an oversized payload is truncated
               rather than written whole.
            2. The whole append is wrapped in try/except. A row is dropped (with a logged
               exception) instead of propagating -- losing one telemetry row is strictly
               better than failing a user's request over it.

        Args:
            agent: The agent's label.
            request: The payload sent to the agent.
            response: Whatever the agent returned, or None if it raised.
            duration_ms: Measured call duration in whole milliseconds.
            error: The exception if the call failed, else None.

        Returns:
            None.

        Example:
            >>> t = CallTrace(); t.record("snow", {"a": 1}, "ok", 12); t.rows[0]["is_error"]
            False
        """
        try:  # Recording is best-effort: never let telemetry break the request                      # best effort
            self.rows.append(
                {
                    "agent": agent,  # Which agent was called, from Agent.label                      # agent
                    "request_text": _field(request),  # Capped, serialised request payload           # request
                    "response_json": _field(response),  # Capped, serialised response                # response
                    "duration_ms": duration_ms,  # How long the agent itself took, in ms             # duration
                    "is_error": error is not None,  # Cheap boolean for dashboard filtering          # error flag
                    "error_text": _field(_error_text(error)),  # Failure text incl. the cause        # error text
                }
            )
        except Exception:  # A telemetry failure must not fail a healthy agent call                  # record failed
            logger.exception("could not record an agent call (row dropped)")  # Drop the row         # log drop

    def drop_last(self) -> None:
        """Drop the row just added -- used by the job status poll.

        What this method does:
            - Removes the most recently appended row, if there is one.

        Why it exists:
            - A job runs 3-15 minutes and is polled every 30s, so ~30 of its 31 rows would
              say "still running". Only the final poll carries the outcome, so the noise is
              discarded at the call site that knows the poll was inconclusive.

        Security and production notes:
            1. Guarded on a non-empty list, so calling it on a fresh trace is a harmless
               no-op rather than an IndexError on the request path.

        Returns:
            None.

        Example:
            >>> t = CallTrace(); t.record("diag", {}, "running", 5); t.drop_last(); t.rows
            []
        """
        if self.rows:  # Guard: a no-op on a fresh trace rather than an IndexError                   # any rows?
            self.rows.pop()  # Discard the inconclusive "still running" poll row                     # drop row


# =========================================== Null trace ===========================================
class NullTrace:
    """A trace that keeps nothing, for callers with no request to attribute rows to.

    What this class is:
        - A drop-in CallTrace with the same three methods, all of which do nothing.

    Why it exists:
        - The agents hold a trace unconditionally and call it on every request, so this is
          what makes `if self._trace is not None` unnecessary in nine modules. Used by
          tests, which construct an agent with no trace at all.

    Security and production notes:
        1. `rows` is an empty TUPLE, not a list, so code that mistakenly tries to append to
           a NullTrace fails loudly in a test rather than quietly collecting rows nobody
           ever reads.

    Example:
        >>> with NULL_TRACE.call("x", {}) as row: row.response = 1
        >>> NULL_TRACE.rows
        ()
    """

    rows = ()  # Immutable and empty: appending to a null trace should fail, not silently work       # no rows

    @contextmanager  # Same `with` interface as CallTrace.call, so agents need no branch
    def call(self, agent, request):
        """Yield a throwaway AgentCall and record nothing."""
        yield AgentCall()  # Body still gets a mailbox; the response is simply discarded             # yield row

    def record(self, *args, **kwargs) -> None:
        """Accept and discard a row, so agent code needs no branch."""
        pass  # Intentionally empty: this trace stores nothing                                       # no-op

    def drop_last(self) -> None:
        """Accept and discard a drop request, so the job poll needs no branch."""
        pass  # Intentionally empty: there is never a row to drop                                    # no-op


# Shared singleton. NullTrace holds no per-request state, so one instance is safe everywhere
# and saves an allocation per agent constructed outside a request.
NULL_TRACE = NullTrace()  # The default trace for agents built with no request behind them           # singleton


# ======================================== Internal helpers ========================================
def _ms(started: float) -> int:
    """Convert a perf_counter start stamp into elapsed whole milliseconds."""
    return int((time.perf_counter() - started) * 1000)  # Monotonic delta, floored to an int         # elapsed ms


def _error_text(error):
    """Describe a failure, naming the ORIGINAL cause where one was chained.

    What this function does:
        - Returns None for no error, the string itself if given a string, otherwise
          "Type: message" plus "(caused by Type: message)" when __cause__ is set.

    Why it exists:
        - The agents translate SDK exceptions into UpstreamUnavailable (see agents/base.py),
          so without the `__cause__` every failed row would read "UpstreamUnavailable:
          <agent> call failed" and the actual reason -- a timeout, an auth failure, a 429 --
          would live only in the logs.

    Security and production notes:
        1. This text lands in the agent_calls table, which is an internal diagnostics
           table, never a response body. An SDK message can name endpoints and headers, so
           it must not be surfaced to a user from here.

    Args:
        error: An exception, a plain string, or None.

    Returns:
        A description of the failure, or None when there was no error.

    Example:
        >>> _error_text(None) is None
        True
    """
    if error is None:  # No failure -> nothing to describe                                           # no error
        return None  # Leaves error_text NULL for a successful call                                  # return none
    if isinstance(error, str):  # Already a message; store it as given                               # plain string
        return error  # Pass the caller's own text straight through                                  # return text
    text = f"{type(error).__name__}: {error}"  # Start with the raised type and message              # own text
    cause = getattr(error, "__cause__", None)  # The `raise ... from` original, if any               # get cause
    if cause is not None:  # An agent wrapper hid the real reason -- append it                       # has cause?
        text += f" (caused by {type(cause).__name__}: {cause})"  # Name the true failure             # add cause
    return text  # Full description: the wrapper plus the underlying cause                           # return all


def _field(value):
    """Serialize a value for storage and cap its length.

    What this function does:
        - Passes a string through unchanged, JSON-encodes anything else (default=str so an
          unserialisable object degrades to its repr rather than raising), then truncates
          past MAX_FIELD with a visible "...[truncated]" marker.

    Why it exists:
        - The request/response columns are single text columns, and agent payloads can
          contain a whole script or a device's raw stdout. Capping here means every writer
          gets the limit for free.

    Security and production notes:
        1. default=str guarantees this never raises on an exotic object, which matters
           because it runs inside the best-effort record() path.
        2. The truncation marker is deliberately visible, so a reader knows they are
           looking at a partial payload rather than the agent's real answer.

    Args:
        value: Any request or response value, or None.

    Returns:
        The capped text, or None when value was None.

    Example:
        >>> _field({"a": 1})
        '{"a": 1}'
    """
    if value is None:  # Nothing to store -> keep the column NULL                                    # is none?
        return None  # NULL distinguishes "no response" from an empty response                       # return none
    text = value if isinstance(value, str) else json.dumps(value, default=str)  # default=str never raises  # to text
    return text if len(text) <= MAX_FIELD else text[:MAX_FIELD] + "...[truncated]"  # Visible cap    # cap text
