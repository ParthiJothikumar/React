####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Package marker and map for `app.domain` -- the business rules, free of delivery concerns.        #
#   1. Declare app.domain as a package and name the three modules in it.                           #
#   2. Record the rule that makes the rules reusable: no framework, no database, no HTTP.          #
#   3. Explain why flow.py is deliberately one long module rather than a package.                  #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported here. This package depends only on app.core (errors, constants) and on   #
#       the agent objects handed to it, which is what lets a test drive it with no web server.     #
####################################################################################################
"""The business rules: what this product DOES, independent of how it is delivered.

What this package is:
    - Three modules:

        flow.py       SupportFlow -- the stage machine that advances a conversation
        jobs.py       JobRunner -- which agent runs a job kind, and its retry semantics
        run_state.py  what a device job's report means (pure functions)

Why this exists:
    - NO FRAMEWORK, NO DATABASE, NO HTTP STATUS CODES in this package. It raises the domain
      errors from core/errors.py and returns plain values; the api layer decides what each
      error becomes, and the services layer decides what gets written down. That is what
      makes the flow callable from a request, from the reaper's background sweep, and from a
      test with no web server -- three callers, one set of rules.
    - The layer above (services/) sequences these: run the flow, translate the reply,
      persist the turn, dispatch the job. The layer below (agents/, db/) does the actual
      work. Nothing here reaches sideways into api/.

Security and production notes:
    1. run_state.py holds the `message` vs `output` split, which is a SECURITY boundary:
       one is shown to the user and written to the transcript, the other is raw device text
       kept for support only. It lives here, in one pure function, rather than being
       trusted to two agent implementations.
    2. jobs.py owns the retry boundary (UpstreamTransient vs UpstreamUnavailable). Getting
       it wrong is what decides whether a broken agent surfaces in seconds or silently
       burns a job's 20-minute deadline.

flow.py is deliberately one long module rather than a package. It is a single state
machine whose handlers each return the next stage, and following a transition across
files costs more than the file length saves.
"""
