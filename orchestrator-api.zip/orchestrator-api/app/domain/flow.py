####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The support-flow stage machine: advance one conversation by exactly one turn.                    #
#   1. step(): detect language, translate in, dispatch to the handler for the current stage.       #
#   2. One handler per stage, each returning (messages, new_stage, flow_vars).                     #
#   3. Route the SECOND classification agent's answer, failing CLOSED on anything unexpected.      #
#   4. Record the INTENT to start a device job; the service layer actually dispatches it.          #
#   5. diagnostics_completed / troubleshoot_completed: resume the flow once a job finishes.        #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.core.config supplies Settings (the caps and the device stand-in) and the shared logger.  #
#   - app.core.constants supplies every stage name, agent label and fixed user-facing line.        #
#   - app.core.errors.ConversationEnded is raised for a terminal stage; the api layer maps it.     #
#   - The agents themselves arrive as constructor arguments, never imported here.                  #
####################################################################################################
"""Support-flow engine: the stage machine, as a class over its injected agents.

What this module is:
    - SupportFlow. step() advances a conversation by one turn and returns
      (messages, new_stage, flow_vars).

Why this exists:
    - It holds no per-conversation state -- the caller owns `stage` and `flow_vars` and
      passes them in every turn -- so a single instance is safe to share across requests
      and the handlers stay pure functions of their arguments.
    - What it holds instead is its collaborators: one object per agent (see agents/),
      injected in __init__. That is the reason this is a class rather than a module of
      functions. Previously the handlers imported `run_agent_json`, `snow_create_incident`
      and friends directly at module scope, which meant the only way to test a stage was to
      monkeypatch module globals. Now a test constructs SupportFlow with a stub per agent
      and drives any branch with no network at all.
    - EACH AGENT IS AN OBJECT WITH ITS OWN METHOD -- self._orchestrator.classify(...), not
      call_json(conv_id, <which agent>, ...). The agents used to be Function Apps behind
      URLs, so one generic client was told which one to POST to on every call; now the agent
      is the object and only the DATA is passed. A stage cannot call the wrong agent by
      passing the wrong URL, and what each agent needs is visible in its own signature.

Security and production notes:
    1. Still framework-agnostic: no FastAPI objects, no DB access, no HTTP status codes. It
       raises ConversationEnded (see core/errors.py); the api layer decides that means 409.
    2. Every agent answer is checked against a closed set before it is acted on, and every
       check fails CLOSED -- an unrecognised issue_type becomes non_it, and an unrecognised
       `action` routes to the support team. Drift must never be the thing that opens a
       ticket or starts a script on somebody's machine.
    3. The raw technical `error` from an agent is logged and stashed in
       flow_vars["last_error"]; the user only ever sees agent_message or a fixed fallback.
"""

# ============================================ Imports =============================================
from app.core.config import Settings, logger  # Caps, the device stand-in, and the logger            # config
from app.core.constants import (  # Every stage name, agent label and fixed line                     # constants
    ACTION_AUTOMATIC,  # ValidationResponse spelling of the automated path                           # action
    ACTION_MANUAL,  # ValidationResponse spelling of the manual path                                 # action
    AWAITING_CLASSIFY,  # First classification agent still gathering detail                          # stage
    AWAITING_FINAL,  # Troubleshoot done; waiting for the final resolved answer                      # stage
    AWAITING_FOLLOWUP,  # Second classification agent asked; awaiting the answer                     # stage
    AWAITING_ISSUE,  # Greeting loop: waiting for the user to name an Outlook issue                  # stage
    AWAITING_PROCEED,  # Diagnostics done; waiting for "proceed to fix?"                             # stage
    AWAITING_RESOLVED,  # Manual steps shown; waiting for "did that fix it?"                         # stage
    DIAGNOSTICS_RUNNING,  # Diagnostics job in flight                                                # stage
    DONE,  # Terminal stage                                                                          # stage
    GREETING_PROMPT,  # Reply to a bare greeting                                                     # message
    ISSUE_GREETING,  # issue_type: no issue stated yet                                               # issue type
    ISSUE_NON_IT,  # issue_type: not an IT question at all                                           # issue type
    ISSUE_NON_OUTLOOK_IT,  # issue_type: real IT issue, wrong queue                                  # issue type
    JOB_FAILED,  # job_status value the completion handlers branch on                                # job status
    JOB_KIND_DIAGNOSTIC,  # Job kind recorded in flow_vars["start_job"]                              # job kind
    JOB_KIND_TROUBLESHOOT,  # Job kind recorded in flow_vars["start_job"]                            # job kind
    NON_IT_PROMPT,  # Reply to an off-topic question                                                 # message
    NONACTIONABLE_END_MESSAGE,  # Sent once the re-prompt cap is exceeded                            # message
    RUNNING_STAGES,  # The two stages a chat turn must not be dispatched on                          # stage set
    SECOND_CLASS_FALLBACK,  # Shown when an agent fails with no safe message of its own              # message
    TROUBLESHOOT_RUNNING,  # Remediation job in flight                                               # stage
    VALID_ISSUE_TYPES,  # Closed set the orchestrator's answer is checked against                    # drift guard
)
from app.core.errors import ConversationEnded  # Raised for a terminal stage; api maps to 409        # errors


# NOTE ON DUPLICATE TICKETS -- why there is no correlation_id here.
#
# A key derived from user_id + the message (stable across a retry) was built and then
# removed on purpose. It only pays off if ServiceNow matches OPEN incidents only:
#
#   same complaint while the old ticket is open   -> reuse is reasonable
#   same complaint after the old one was closed   -> MUST create a new ticket
#
# Get that second rule wrong and a user's new problem is attached to a closed ticket
# nobody is working -- their issue silently disappears. A wrong merge is worse than the
# duplicate it prevents, so the field is not sent until ServiceNow can guarantee the
# scoping.
#
# What replaces it: api/routes/ no longer tells a user to "try again" once a ticket exists
# -- it hands them the incident number and says they need not start over. That removes
# the retry we were causing, which was the main source of duplicates. The cases still
# uncovered are a user ignoring that message, and double-submits (two tabs / double
# click) -- the latter produces duplicates even when nothing fails, and only a
# ServiceNow-side key could catch it.


# ========================================== Support flow ==========================================
class SupportFlow:
    """The stage machine. One instance per worker process; no mutable state.

    What this class is:
        - Six stage handlers plus two job-completion handlers, over five injected agents.
          Each handler takes (conv_id, user_message, flow_vars, messages) and returns
          (messages, new_stage, flow_vars).

    Why it exists:
        - So the rules of the conversation live in one readable place, with no framework, no
          database and no HTTP anywhere near them.

    Security and production notes:
        1. NO MUTABLE STATE. The caller owns `stage` and `flow_vars`, so one instance is
           safely shared by every request in the worker process.
        2. Every branch that ends the conversation goes through _end(), so the outcome
           (resolved / escalated / neither) can never be left unstated.

    Example:
        >>> flow.step("c1", "outlook won't open", None, {})  # doctest: +SKIP
        (['Incident INC001 has been created.'], 'AWAITING_CLASSIFY', {...})
    """

    def __init__(
        self, orchestrator, classify_first, classify_second, servicenow, multilingual,
        settings: Settings,
    ) -> None:
        """Adopt the five agents and the settings; hold no conversation state.

        Args:
            orchestrator: OrchestratorAgent -- classifies the message into an issue_type.
            classify_first: FirstClassificationAgent -- issue -> kb_id + summary.
            classify_second: SecondClassificationAgent -- kb_id -> how to resolve it.
            servicenow: ServiceNowAgent -- interaction and incident lifecycle.
            multilingual: MultilingualAgent -- detect language and translate.
            settings: Parsed configuration; read for MAX_NONACTIONABLE and DEFAULT_DEVICE_ID.

        Returns:
            None.
        """
        self._orchestrator = orchestrator  # Decides whether this is support work at all             # agent
        self._classify_first = classify_first  # Gathers detail until it can name a KB article       # agent
        self._classify_second = classify_second  # Decides HOW that article gets resolved            # agent
        self._snow = servicenow  # Interaction + incident lifecycle                                  # agent
        self._lang = multilingual  # Detect + translate; degrades, never raises                      # agent
        self._settings = settings  # Caps and the temporary shared device id                         # settings

    # ============================================ Entry point =====================================
    def step(self, conv_id: str, user_message: str, stage, flow_vars: dict):
        """Advance the support flow by one turn based on the current stage.

        What this method does:
            - Re-detects the language, translates the message into the working language,
              then either answers "still working" (a RUNNING stage) or dispatches to the
              handler for the current stage. Finally, closes the ServiceNow interaction if
              the conversation just ended.

        Why it exists:
            - Detects and stores the user's language, then dispatches to the handler for the
              current stage. Returns (messages, new_stage, flow_vars). Raises
              ConversationEnded if the stage is already terminal (unknown/DONE) --
              api/routes/ maps that to a 409.

        Security and production notes:
            1. The language is re-detected EVERY turn so a mid-conversation switch is
               honoured, but detection failure keeps the previously stored language -- so a
               short reply like "ok" can never flip the conversation's language.
            2. The interaction is closed centrally here rather than in each terminal branch,
               so a branch added later cannot forget to close it.

        Args:
            conv_id: The Foundry conversation id, used as the correlation id throughout.
            user_message: The user's raw message, in their own language.
            stage: The stage the conversation is currently parked on; None on the first turn.
            flow_vars: The flow's variables, owned by the caller and passed back in.

        Returns:
            (messages, new_stage, flow_vars).

        Raises:
            ConversationEnded: The stage is terminal, so there is no handler for it.

        Example:
            >>> flow.step("c1", "hi", None, {})[1]  # doctest: +SKIP
            'AWAITING_ISSUE'
        """
        messages: list = []  # Accumulates the assistant lines this turn, in display order           # out lines
        # Re-detect every turn so a mid-conversation language switch is honored; keep
        # the previously stored language when detection is empty/uncertain/unsupported.
        flow_vars["lang"] = self._lang.detect(  # Never raises; falls back to what we had            # detect lang
            user_message, fallback=flow_vars.get("lang", "")
        )

        # Work internally in English: translate the inbound message so the yes/no
        # checks AND the sub-agents all see English, regardless of the user's language.
        # (The services still store the ORIGINAL native text.)
        user_message = self._lang.to_english(user_message, flow_vars["lang"])  # Degrades to the original  # translate in

        if stage in RUNNING_STAGES:  # A device job is in flight; the FE should be polling           # job running?
            # A job is running -> the FE should be polling /jobs/status, not sending
            # chat turns. If a turn arrives anyway, say we're still working and STAY on
            # the stage we were given (don't try to re-derive which job is running).
            messages.append("Still working on it -- I'll update you here shortly.")  # Safe holding line  # hold
            new_stage, flow_vars = stage, flow_vars  # KEEP the stage exactly as it came in          # keep stage
        else:  # A normal chat turn -> dispatch to the stage's handler                               # normal turn
            handler = self._handler_for(stage)  # None means the stage is terminal                   # find handler
            if handler is None:  # DONE, or a stage this machine does not recognise                  # terminal?
                raise ConversationEnded("Conversation already completed")  # -> 409                  # raise 409
            messages, new_stage, flow_vars = handler(  # The handler owns the whole turn             # run handler
                conv_id, user_message, flow_vars, messages
            )

        # The interaction represents the chat contact -> close it once the conversation
        # ends (any terminal), whether or not an incident was created/resolved.
        if (  # Central close, so a terminal branch added later cannot forget it                     # just ended?
            new_stage == DONE  # The conversation is over, however it got there                      # terminal
            and flow_vars.get("interaction_id")  # There is an interaction to close                  # have one?
            and not flow_vars.get("interaction_closed")  # And we have not closed it already         # not yet?
        ):
            self._snow.close_interaction(conv_id, flow_vars["interaction_id"])  # Best-effort        # close
            flow_vars["interaction_closed"] = True  # Idempotent: never close it twice               # mark closed
        return messages, new_stage, flow_vars  # The caller persists all three                       # return turn

    @staticmethod
    def _end(messages, flow_vars, *, resolved=False, escalated=False):
        """End the conversation, recording HOW it ended.

        What this method does:
            - Writes the two outcome flags into flow_vars and returns the DONE stage.

        Why it exists:
            - Every terminal branch goes through here instead of returning DONE directly, so
              the outcome can't be left unstated -- and the two flags are set in one place
              rather than at ten `return ... DONE ...` sites.

                resolved   the user confirmed the issue was fixed
                escalated  we finished WITHOUT fixing it and a human must pick up the ticket
                both False the conversation needed no action (a greeting, or a non-IT question)

        Security and production notes:
            1. The pair cannot be derived later: for an Outlook issue the incident is created
               up front, before the outcome is known, so incident_id tells you nothing about
               how it turned out. ConversationRepository lifts both into their own columns.

        Args:
            messages: The assistant lines accumulated this turn.
            flow_vars: The flow's variables, mutated with the two flags.
            resolved: True when the user confirmed the issue was fixed.
            escalated: True when a human must pick the ticket up.

        Returns:
            (messages, DONE, flow_vars).
        """
        flow_vars["resolved"] = resolved  # Promoted to its own column by the repository             # outcome
        flow_vars["escalated"] = escalated  # Promoted to its own column by the repository           # outcome
        return messages, DONE, flow_vars  # step() then closes the interaction                       # end turn

    def _handler_for(self, stage):
        """Map a stage to its handler method, or None if the stage is terminal.

        What this method does:
            - Returns _start for a brand-new conversation, otherwise looks the stage up in a
              literal dict and returns None on a miss.

        Why it exists:
            - A dict beats a long if/elif chain here: adding a stage is one entry, and the
              set of handled stages is readable at a glance. RUNNING stages are handled in
              step() itself, because their reply keeps whatever stage came in.

        Args:
            stage: The current stage, or None for a brand-new conversation.

        Returns:
            The bound handler method, or None when the stage is terminal/unknown.
        """
        if stage is None:  # Brand-new conversation -> the first turn is always _start               # new chat?
            return self._start  # Opens the interaction and classifies the message                   # first turn
        return {  # One entry per chat-await stage; RUNNING stages are handled in step()             # dispatch
            AWAITING_ISSUE: self._start,  # Greeting loop re-enters the same handler                 # handler
            AWAITING_CLASSIFY: self._run_classify,  # First agent still gathering detail             # handler
            AWAITING_RESOLVED: self._resolved_turn,  # "Did the manual steps work?"                  # handler
            AWAITING_PROCEED: self._proceed_turn,  # "Proceed to the automated fix?"                 # handler
            AWAITING_FINAL: self._final_turn,  # "Is it resolved now?"                               # handler
            AWAITING_FOLLOWUP: self._followup_turn,  # Reply to the second agent's question          # handler
        }.get(stage)  # None for DONE, or for a stage this machine does not recognise                # or none

    # =========================================== Stage handlers ===================================
    def _start(self, conv_id, user_message, flow_vars, messages):
        """First turn / greeting loop: open the interaction, classify, and route.

        What this method does:
            - Opens the ServiceNow interaction once, asks the orchestrator agent for an
              issue_type, validates it against the closed set, and routes on it.

        Why it exists:
            - The ServiceNow interaction is opened ONCE, at the start of the conversation
              (any category), and reused on greeting-loop turns. Routing by issue_type:
                greeting / non_it -> re-prompt for an Outlook issue up to MAX_NONACTIONABLE
                                     times (shared counter), then end. No incident.
                non_outlook_it    -> create an incident (ticket), thank the user, end.
                outlook_it        -> create an incident up front, then enter classification.
              The interaction is closed centrally in step() when the conversation ends.

        Security and production notes:
            1. issue_type is validated against VALID_ISSUE_TYPES and anything unexpected is
               logged and treated as non_it, so drift can never silently reach the two
               incident-creating branches below.
            2. create_incident RAISES on failure (unlike the interaction calls), because the
               user is about to be told a ticket number and a ticket that was never created
               must not be reported as one.

        Args:
            conv_id: The Foundry conversation id.
            user_message: The user's message, already translated to the working language.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.

        Returns:
            (messages, new_stage, flow_vars).
        """
        # Interaction is created once per conversation, at the start (reused on loops).
        if not flow_vars.get("interaction_id"):  # Only on the very first turn                       # have one?
            flow_vars["interaction_id"] = self._snow.create_interaction(  # Best-effort: "" on failure  # create
                conv_id, flow_vars.get("user_id", "")
            )
        interaction_id = flow_vars["interaction_id"]  # May be "" if ServiceNow was down             # interaction

        response = self._orchestrator.classify(conv_id, user_message)  # Raises on failure           # classify
        # Validate issue_type against the allowed set (no value drift): a missing or
        # unexpected label is logged and treated as non_it, so it can never silently
        # fall through to the incident-creating branches below.
        issue_type = response.get("issue_type")  # The agent's label, not yet trusted                # read label
        if issue_type not in VALID_ISSUE_TYPES:  # Drift guard, failing CLOSED to non_it             # known?
            logger.warning(  # Make the drift discoverable rather than silent                        # log warn
                "orchestrator returned unexpected issue_type=%r conv_id=%s; treating as %s",
                issue_type, conv_id, ISSUE_NON_IT,
            )
            issue_type = ISSUE_NON_IT  # Safest label: re-prompt, and raise no ticket                # fail closed
        flow_vars["issue_type"] = issue_type  # Remembered for the rest of the conversation          # store label

        # Non-actionable (greeting or general/non-IT): re-prompt up to the cap, then end.
        if issue_type in (ISSUE_GREETING, ISSUE_NON_IT):  # Nothing to act on yet                    # actionable?
            count = flow_vars.get("nonactionable_count", 0) + 1  # ONE shared counter for both       # bump count
            flow_vars["nonactionable_count"] = count  # Persisted, so the cap survives a turn        # store count
            if count > self._settings.MAX_NONACTIONABLE:  # Cap reached -> stop asking               # over cap?
                messages.append(NONACTIONABLE_END_MESSAGE)  # Fixed, user-safe closing line          # end line
                # Neither flag: no incident was ever created and nothing needed doing.
                return self._end(messages, flow_vars)  # resolved=False, escalated=False             # end chat
            messages.append(  # Ask again, with wording that matches which case it was               # re-prompt
                GREETING_PROMPT if issue_type == ISSUE_GREETING else NON_IT_PROMPT
            )
            return messages, AWAITING_ISSUE, flow_vars  # Stay in the greeting loop                  # loop

        # non_outlook_it: create the ticket under the interaction, thank the user, end.
        if issue_type == ISSUE_NON_OUTLOOK_IT:  # Real IT issue, but another team's queue            # wrong queue?
            snow = self._snow.create_incident(  # RAISES on failure -- see the notes above           # create tkt
                conv_id, interaction_id, issue_type, user_message
            )
            flow_vars["incident_id"] = snow.get("incident_id")  # Promoted to its own column         # store tkt
            ticket_msg = (  # Prefer the agent's own wording; fall back to ours                      # ticket line
                snow.get("message")
                or f"Your ticket {snow.get('incident_id')} has been created."
            )
            messages.append(ticket_msg + " Thank you for contacting us.")  # One closing bubble      # reply
            # Escalated: correct routing rather than a failure, but the ticket goes to
            # another team's queue and a human picks it up.
            return self._end(messages, flow_vars, escalated=True)  # A human owns it now             # end chat

        # outlook_it: create the incident up front, then enter the classification flow.
        snow = self._snow.create_incident(  # RAISES on failure -- the user is told a number         # create tkt
            conv_id, interaction_id, issue_type, user_message
        )
        flow_vars["incident_id"] = snow.get("incident_id")  # Promoted to its own column             # store tkt
        messages.append(  # Tell the user the ticket exists before the work starts                   # reply
            snow.get("message") or f"Incident {snow.get('incident_id')} has been created."
        )
        return self._run_classify(conv_id, user_message, flow_vars, messages)  # Straight on         # classify

    def _run_classify(self, conv_id, user_message, flow_vars, messages):
        """First-classification turn: run the FIRST classification agent.

        What this method does:
            - Calls the first agent. If it wants more detail, shows its question and stays
              on AWAITING_CLASSIFY. Once it closes, stores kb_id + summary and makes the
              FIRST call to the second agent.

        Why it exists:
            - While it needs more info it returns chat_close=false with a follow-up question
              (agent_message); we show it and stay in AWAITING_CLASSIFY. When it returns
              chat_close=true we store its kb_id + summary and hand off to the second
              classification agent.

        Security and production notes:
            1. THE AGENT OWNS THE FOLLOW-UP LOOP. Nothing here counts or caps its questions,
               so adding one is a change to that agent and not to this flow.

        Args:
            conv_id: The Foundry conversation id.
            user_message: The user's message, already translated.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.

        Returns:
            (messages, new_stage, flow_vars).
        """
        first = self._classify_first.classify(conv_id, user_message)  # Raises on failure            # classify 1

        if not first.get("chat_close"):  # Still gathering detail -> ask and wait                    # closed?
            # still gathering info -> show the follow-up question and wait
            if first.get("agent_message"):  # Only append a real question                            # have q?
                messages.append(first["agent_message"])  # The agent's own next question             # ask
            return messages, AWAITING_CLASSIFY, flow_vars  # Same stage, next turn re-enters         # wait

        # classification complete -> keep kb_id + summary for the second agent
        flow_vars["kb_id"] = first.get("kb_id")  # The second agent's only real input                # store kb
        flow_vars["kb_summary"] = first.get("summary")  # Extra context for the device agents        # store summary
        if first.get("agent_message"):  # A closing line is optional here                            # have line?
            messages.append(first["agent_message"])  # Show it if there is one                       # reply

        # First call to the SECOND classification agent (message=""), then route.
        second = self._classify_second.validate(  # NEVER raises: returns success=false instead      # classify 2
            conv_id, flow_vars.get("kb_id"), message=""
        )
        return self._route_second_classification(conv_id, flow_vars, messages, second)  # Route      # route

    def _followup_turn(self, conv_id, user_message, flow_vars, messages):
        """User answered an ask_user follow-up -> re-call agent 2 with their reply.

        What this method does:
            - Calls the second agent again, this time with the user's reply, and routes the
              answer exactly as the first call was routed.

        Why it exists:
            - The agent owns the follow-up count (we don't send or track it); it returns
              another follow-up question, a ready-to-run result, or success=false when it
              gives up. The response is routed exactly like the first call.

        Args:
            conv_id: The Foundry conversation id.
            user_message: The user's answer to the agent's question, already translated.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.

        Returns:
            (messages, new_stage, flow_vars).
        """
        second = self._classify_second.validate(  # Same call, now carrying the user's reply         # classify 2
            conv_id, flow_vars.get("kb_id"), message=user_message
        )
        return self._route_second_classification(conv_id, flow_vars, messages, second)  # Route      # route

    def _route_second_classification(self, conv_id, flow_vars, messages, second):
        """Route on one ValidationResponse from the SECOND classification agent.

        What this method does:
            - Checks success, then validated, then the action word, then user_params and
              follup_flag -- in that order -- and dispatches to the matching tail.

        Why it exists:
            - `second` is the agent's decision dict (the M/A/U/N scenarios). Order matters:
              success and validated are checked first, so every failure or non-automatable
              result (M2/U5/U6/N1/N2) short-circuits to _close_with_message before any
              action / user_params / follup_flag branch is considered.

        Security and production notes:
            1. THE DRIFT GUARD IS THE POINT OF THIS METHOD. Anything but a clean "automatic"
               routes to the support team and is never run. An automated action must be asked
               for explicitly and spelled correctly; drift must never be the thing that
               starts a script on someone's machine.

        Args:
            conv_id: The Foundry conversation id.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.
            second: The agent's ValidationResponse dict.

        Returns:
            (messages, new_stage, flow_vars).
        """
        # success == false (M2/U5/U6/N2, or a synthesized transport failure) -> close.
        if not second.get("success"):  # The agent could not get to an answer at all                 # succeeded?
            return self._close_with_message(  # log_error: this one has a technical cause            # route out
                conv_id, flow_vars, messages, second, log_error=True
            )

        # success but not automatable (N1: e.g. not found) -> show message, close.
        if not second.get("validated"):  # A real answer, but nothing we can act on                  # actionable?
            return self._close_with_message(  # No technical error to log here                       # route out
                conv_id, flow_vars, messages, second, log_error=False
            )

        action = (second.get("action") or "").lower()  # Normalised once for the checks below        # read action

        # MANUAL (M1): steps already embed the reference link -> show + ask confirmation.
        if action == ACTION_MANUAL:  # Hand the user written steps to follow themselves              # manual?
            messages.append(  # steps preferred; agent_message is the fallback wording               # show steps
                second.get("steps") or second.get("agent_message") or ""
            )
            messages.append("Did these steps resolve your issue?")  # Sets up _resolved_turn         # ask
            return messages, AWAITING_RESOLVED, flow_vars  # Wait for their yes/no                   # wait

        # Drift guard: anything but a clean "automatic" -> route to the team (never
        # auto-run).
        if action != ACTION_AUTOMATIC:  # Unrecognised action -> never run anything                  # automatic?
            logger.warning(  # Make the drift discoverable rather than silent                        # log warn
                "second classification returned unexpected action=%r conv_id=%s; "
                "routing to support team", second.get("action"), conv_id,
            )
            return self._close_with_message(  # Fails CLOSED to a human                              # route out
                conv_id, flow_vars, messages, second, log_error=False
            )

        # AUTOMATIC, no user input needed (A1) -> diagnostics, then troubleshoot.
        if not second.get("user_params"):  # Nothing to collect -> diagnose first                    # need input?
            return self._start_diagnostics(conv_id, flow_vars, messages)  # A1 path                  # diagnose

        # AUTOMATIC + ask_user, still gathering input (U1/U2/U4) -> ask and wait. The
        # agent owns the follow-up count and returns success=false at the cap (U5).
        if second.get("follup_flag"):  # Still collecting the script's inputs                        # more input?
            if second.get("follow_up_question"):  # Only append a real question                      # have q?
                messages.append(second["follow_up_question"])  # The agent's own next question       # ask
            return messages, AWAITING_FOLLOWUP, flow_vars  # _followup_turn handles the reply        # wait

        # AUTOMATIC + ask_user, inputs ready (U3) -> troubleshoot with the script.
        return self._start_troubleshoot(  # Skips diagnostics: the script is already chosen          # remediate
            conv_id, flow_vars, messages,
            second.get("script_name"), second.get("script_params"),
        )

    def _close_with_message(self, conv_id, flow_vars, messages, second, log_error):
        """Route-to-team tail (validated==false / success==false).

        What this method does:
            - Logs and stashes the raw error when asked to, shows a user-safe line, adds a
              work note to the incident, and ends the conversation as escalated.

        Why it exists:
            - The user only ever sees a safe message: agent_message when present (keeps M2's
              KB link and U5's 'team will follow up'), else SECOND_CLASS_FALLBACK.

        Security and production notes:
            1. The raw technical `error` is logged and stored in flow_vars["last_error"]
               (persisted on the conversation row) for debugging -- NEVER shown to the user.
            2. The incident, opened at the start, is updated and left OPEN for the support
               team. The update is best-effort, so a ServiceNow blip cannot break the turn.

        Args:
            conv_id: The Foundry conversation id.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.
            second: The agent's ValidationResponse dict.
            log_error: True when `second` carries a technical cause worth logging.

        Returns:
            (messages, DONE, flow_vars), with escalated=True.
        """
        raw_error = second.get("error")  # Technical cause; must never reach the user                # read error
        if log_error and raw_error:  # Only the success==false path has one worth logging            # log it?
            logger.error(  # stop_reason names WHY the agent gave up                                 # log error
                "second-classification failed conv_id=%s stop=%s: %s",
                conv_id, second.get("stop_reason"), raw_error,
            )
            flow_vars["last_error"] = raw_error  # Persisted on the row, for debugging               # stash error
        messages.append(second.get("agent_message") or SECOND_CLASS_FALLBACK)  # Safe line only      # reply
        self._snow.update_incident(  # Best-effort: the ticket stays OPEN for a human                # work note
            conv_id, flow_vars.get("incident_id"),
            "Automated resolution not completed; routed to support team.",
        )
        return self._end(messages, flow_vars, escalated=True)  # A human owns it now                 # end chat

    # ========================================= Async job triggers =================================
    def _start_diagnostics(self, conv_id, flow_vars, messages):
        """A1 path: START an async diagnostics job instead of blocking.

        What this method does:
            - Notes the start on the incident, records the job INTENT in
              flow_vars["start_job"], tells the user, and returns the RUNNING stage.

        Why it exists:
            - We only record the INTENT in flow_vars["start_job"]; the service (after step())
              calls the agent's start() and records the job_id on the conversation row. The
              FE then polls /jobs/status, which asks the agent for its status live and
              advances the flow. Diagnostics feeds into troubleshoot afterwards
              (AWAITING_PROCEED).
            - Why the flow does not call the agent itself: the job_id has to be written
              against a conversation row that does not exist yet on the first turn, and
              step() must stay free of persistence. See ChatService._dispatch_pending_job.

        Security and production notes:
            1. The agent's start() arguments are given BY NAME -- JobRunner passes them
               straight through as keyword arguments. Nothing is serialised into a JSON
               string any more, so a field the agent does not accept is a TypeError at the
               call instead of a key it silently ignores.
            2. device_id is currently a single configured test device for every user -- see
               Settings.DEFAULT_DEVICE_ID and the startup warning about it.

        Args:
            conv_id: The Foundry conversation id.
            flow_vars: The flow's variables; gains the "start_job" intent.
            messages: The accumulating assistant lines.

        Returns:
            (messages, DIAGNOSTICS_RUNNING, flow_vars).
        """
        self._snow.update_incident(  # Best-effort progress note on the open ticket                  # work note
            conv_id, flow_vars.get("incident_id"), "Automated diagnostics started."
        )
        flow_vars["start_job"] = {  # INTENT only; the service dispatches it after step()            # job intent
            "kind": JOB_KIND_DIAGNOSTIC,  # JobRunner maps this to the diagnostics agent             # job kind
            # The agent's start() arguments, by name -- JobRunner passes them straight
            # through as keyword arguments. Nothing is serialised into a JSON string any
            # more, so a field the agent does not accept is a TypeError at the call
            # instead of a key it silently ignores.
            "params": {
                # Which machine to work on. Currently a single configured test device for
                # every user -- see Settings.DEFAULT_DEVICE_ID.
                "device_id": self._settings.DEFAULT_DEVICE_ID,  # TEMPORARY shared device            # device
                "kb_id": flow_vars.get("kb_id"),  # The article the agents settled on                # kb id
                "summary": flow_vars.get("kb_summary", ""),  # Extra context for the agent           # summary
            },
        }
        messages.append(  # Set the user's expectation: minutes, not seconds                         # reply
            "Diagnostics started -- this can take a few minutes. I'll post updates here."
        )
        return messages, DIAGNOSTICS_RUNNING, flow_vars  # Chat turns now get the holding line       # running

    def _start_troubleshoot(self, conv_id, flow_vars, messages, script_name, script_params):
        """U3 path: skip diagnostics and START the troubleshoot job with the collected
        script. Same start_job mechanism as _start_diagnostics; the job input carries
        the script_name + script_params the ask_user loop gathered.

        What this method does:
            - Notes the start on the incident, records the troubleshoot job INTENT including
              the chosen script and its collected inputs, tells the user, returns RUNNING.

        Why it exists:
            - The second classification agent already knows which script to run and has
              collected its inputs, so there is nothing left to diagnose.

        Security and production notes:
            1. This path CHANGES the user's machine, and it was reached only via a clean
               `action == "automatic"` -- see the drift guard in
               _route_second_classification.

        Args:
            conv_id: The Foundry conversation id.
            flow_vars: The flow's variables; gains the "start_job" intent.
            messages: The accumulating assistant lines.
            script_name: The script the agent named.
            script_params: The inputs it collected for that script; None becomes {}.

        Returns:
            (messages, TROUBLESHOOT_RUNNING, flow_vars).
        """
        self._snow.update_incident(  # Best-effort progress note on the open ticket                  # work note
            conv_id, flow_vars.get("incident_id"), "Troubleshooting started."
        )
        flow_vars["start_job"] = {  # INTENT only; the service dispatches it after step()            # job intent
            "kind": JOB_KIND_TROUBLESHOOT,  # JobRunner maps this to the troubleshoot agent          # job kind
            "params": {
                "device_id": self._settings.DEFAULT_DEVICE_ID,  # TEMPORARY shared device            # device
                "kb_id": flow_vars.get("kb_id"),  # The article the agents settled on                # kb id
                "script_name": script_name,  # What the second agent chose to run                    # script
                "script_params": script_params or {},  # Its collected inputs; never None            # params
            },
        }
        messages.append(  # Set the user's expectation: minutes, not seconds                         # reply
            "Troubleshooting started -- this can take a few minutes. I'll post updates here."
        )
        return messages, TROUBLESHOOT_RUNNING, flow_vars  # Chat turns now get the holding line      # running

    # ========================================= Confirmation turns =================================
    def _resolved_turn(self, conv_id, user_message, flow_vars, messages):
        """Handle the 'did the manual steps resolve it?' answer (manual path).

        What this method does:
            - On "yes", resolves the incident and ends as resolved. On anything else, adds a
              work note, tells the user the ticket stays open, and ends as escalated.

        Why it exists:
            - 'yes' resolves the incident opened at the start. 'no' updates that incident
              (it stays open for the team). Flow ends (DONE) either way.

        Security and production notes:
            1. resolve() RAISES on failure, unlike update_incident(): telling someone their
               ticket is closed when it is still open is the one outcome worth failing the
               turn for.
            2. The check is a substring test on the translated message, which is why the
               inbound translation in step() has to happen before any handler runs.

        Args:
            conv_id: The Foundry conversation id.
            user_message: The user's answer, already translated.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.

        Returns:
            (messages, DONE, flow_vars).
        """
        if "yes" in user_message.lower():  # Confirmed fixed -> close the ticket properly            # said yes?
            messages.append(  # resolve() returns the agent's own confirmation line                  # resolve
                self._snow.resolve(  # RAISES on failure -- see the notes above                      # close tkt
                    conv_id,
                    flow_vars.get("interaction_id"),
                    flow_vars.get("incident_id"),
                )
            )
            messages.append("Glad it worked")  # Friendly close                                      # reply
            return self._end(messages, flow_vars, resolved=True)  # Genuinely fixed                  # end chat
        # user said no -> update the incident, which stays open
        self._snow.update_incident(  # Best-effort: the ticket stays OPEN for a human                # work note
            conv_id, flow_vars.get("incident_id"),
            "Manual steps did not resolve the issue.",
        )
        messages.append(  # Give them the number so they need not start over                         # reply
            f"Your incident {flow_vars.get('incident_id', '')} stays open for the "
            "support team."
        )
        return self._end(messages, flow_vars, escalated=True)  # A human owns it now                 # end chat

    def _proceed_turn(self, conv_id, user_message, flow_vars, messages):
        """Handle the 'proceed with troubleshooting?' answer.

        What this method does:
            - On "yes", records the troubleshoot job intent and returns RUNNING. On anything
              else, adds a work note and ends as escalated.

        Why it exists:
            - 'yes' STARTS an async troubleshoot job (same start_job mechanism -- we never
              block); anything else leaves the incident open and ends (DONE).

        Security and production notes:
            1. The params are NAMED arguments, like the other two start_job payloads. This
               one used to send the bare summary as the whole `input` string, which the
               receiving service could not json.loads() -- so every troubleshoot started
               from "yes, proceed" failed at the far end while the other two paths worked. A
               malformed payload is no longer possible to express here.

        Args:
            conv_id: The Foundry conversation id.
            user_message: The user's answer, already translated.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.

        Returns:
            (messages, new_stage, flow_vars).
        """
        if "yes" in user_message.lower():  # Consented to the automated fix                          # said yes?
            self._snow.update_incident(  # Best-effort progress note                                 # work note
                conv_id, flow_vars.get("incident_id"), "Troubleshooting started."
            )
            flow_vars["start_job"] = {  # INTENT only; the service dispatches it after step()        # job intent
                "kind": JOB_KIND_TROUBLESHOOT,  # JobRunner maps this to the troubleshoot agent      # job kind
                # Named arguments, like the other two start_job payloads. This one used to
                # send the bare summary as the whole `input` string, which the receiving
                # service could not json.loads() -- so every troubleshoot started from
                # "yes, proceed" failed at the far end while the other two paths worked.
                # A malformed payload is no longer possible to express here.
                "params": {
                    "device_id": self._settings.DEFAULT_DEVICE_ID,  # TEMPORARY shared device        # device
                    "kb_id": flow_vars.get("kb_id"),  # The article the agents settled on            # kb id
                    "summary": flow_vars.get("kb_summary", ""),  # Context from diagnostics          # summary
                },
            }
            messages.append(  # Set the user's expectation: minutes, not seconds                     # reply
                "Troubleshooting started -- this can take a few minutes. "
                "I'll post updates here."
            )
            return messages, TROUBLESHOOT_RUNNING, flow_vars  # Chat turns now get the hold line     # running
        # user said no -> update the incident, which stays open
        self._snow.update_incident(  # Best-effort: record that they declined                        # work note
            conv_id, flow_vars.get("incident_id"), "User declined troubleshooting."
        )
        messages.append(  # Give them the number so they need not start over                         # reply
            f"No problem. Your incident {flow_vars.get('incident_id', '')} stays open "
            "for the support team."
        )
        # The user chose to stop, but the ticket is still open for a human.
        return self._end(messages, flow_vars, escalated=True)  # A human owns it now                 # end chat

    def _final_turn(self, conv_id, user_message, flow_vars, messages):
        """Handle the final 'issue resolved?' answer after troubleshooting.

        What this method does:
            - On "yes", resolves the incident and ends as resolved. On anything else, adds a
              work note, tells the user the ticket stays open, and ends as escalated.

        Why it exists:
            - 'yes' resolves the ServiceNow incident; anything else leaves it open. Flow
              ends (DONE) either way.

        Security and production notes:
            1. resolve() RAISES on failure, for the same reason as in _resolved_turn: a
               ticket reported as closed while it is still open must surface.

        Args:
            conv_id: The Foundry conversation id.
            user_message: The user's answer, already translated.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.

        Returns:
            (messages, DONE, flow_vars).
        """
        if "yes" in user_message.lower():  # Confirmed fixed -> close the ticket properly            # said yes?
            messages.append(  # resolve() returns the agent's own confirmation line                  # resolve
                self._snow.resolve(  # RAISES on failure -- see the notes above                      # close tkt
                    conv_id,
                    flow_vars.get("interaction_id"),
                    flow_vars.get("incident_id"),
                )
            )
            return self._end(messages, flow_vars, resolved=True)  # Genuinely fixed                  # end chat
        # user said no -> update the incident, which stays open
        self._snow.update_incident(  # Best-effort: the ticket stays OPEN for a human                # work note
            conv_id, flow_vars.get("incident_id"),
            "Issue not resolved after troubleshooting.",
        )
        messages.append(  # Give them the number so they need not start over                         # reply
            f"Your incident {flow_vars.get('incident_id', '')} stays open for the "
            "support team."
        )
        return self._end(messages, flow_vars, escalated=True)  # A human owns it now                 # end chat

    # ================== Job completion (called from JobService, not from step()) ==================
    def diagnostics_completed(self, conv_id, flow_vars, messages, job):
        """Advance the flow after a diagnostics job finishes.

        What this method does:
            - On failure, notes it on the incident and ends as escalated. On success, shows
              the user-safe outcome line and asks whether to proceed to troubleshooting.

        Why it exists:
            - On success: show the result and ask whether to proceed to troubleshooting
              (AWAITING_PROCEED). On failure/timeout: note it on the incident and end (DONE).
            - Called from JobService rather than step(), because a job finishes outside any
              chat turn -- from the FE's poll or from the reaper's sweep.

        Security and production notes:
            1. job_message is the user-safe outcome line. The raw device output lives in
               job_output and is never handed to this method -- see app/domain/run_state.py.
            2. This is also the job-EXPIRY path: an overdue job is reported as failed, so a
               job nobody ever came back for is escalated rather than silently forgotten.

        Args:
            conv_id: The Foundry conversation id.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.
            job: {job_status, job_message} as prepared by JobService.

        Returns:
            (messages, new_stage, flow_vars).
        """
        if job.get("job_status") == JOB_FAILED:  # Failed OR expired -- treated identically          # failed?
            self._snow.update_incident(  # Best-effort: the ticket stays OPEN for a human            # work note
                conv_id, flow_vars.get("incident_id"), "Automated diagnostics failed."
            )
            messages.append(  # Safe line + the ticket number, so they need not start over           # reply
                f"Diagnostics couldn't complete ({job.get('job_message', '')}). Your "
                f"incident {flow_vars.get('incident_id', '')} stays open for the "
                "support team."
            )
            # Also the job-expiry path: an overdue job is reported as failed, so a job
            # nobody ever came back for is escalated rather than silently forgotten.
            return self._end(messages, flow_vars, escalated=True)  # A human owns it now             # end chat
        # job_message is the user-safe outcome line. The raw device output lives in
        # job_output and is never handed to this method -- see app/domain/run_state.py.
        if job.get("job_message"):  # The safe outcome line, if there is one                         # have line?
            messages.append(job["job_message"])  # Never job_output -- that is support-only          # reply
        messages.append("Proceed with troubleshooting?")  # Sets up _proceed_turn                    # ask
        return messages, AWAITING_PROCEED, flow_vars  # Wait for their consent                       # wait

    def troubleshoot_completed(self, conv_id, flow_vars, messages, job):
        """Advance the flow after a troubleshoot job finishes.

        What this method does:
            - On failure, notes it on the incident and ends as escalated. On success, shows
              the user-safe outcome line and asks whether the issue is resolved.

        Why it exists:
            - On success: show the result and ask whether the issue is resolved
              (AWAITING_FINAL). On failure/timeout: note it on the incident and end (DONE).

        Security and production notes:
            1. job_message is the user-safe outcome line (see diagnostics_completed). The
               raw device output is never handed to this method.

        Args:
            conv_id: The Foundry conversation id.
            flow_vars: The flow's variables.
            messages: The accumulating assistant lines.
            job: {job_status, job_message} as prepared by JobService.

        Returns:
            (messages, new_stage, flow_vars).
        """
        if job.get("job_status") == JOB_FAILED:  # Failed OR expired -- treated identically          # failed?
            self._snow.update_incident(  # Best-effort: the ticket stays OPEN for a human            # work note
                conv_id, flow_vars.get("incident_id"), "Troubleshooting failed."
            )
            messages.append(  # Safe line + the ticket number, so they need not start over           # reply
                f"Troubleshooting couldn't complete ({job.get('job_message', '')}). "
                f"Your incident {flow_vars.get('incident_id', '')} stays open for the "
                "support team."
            )
            return self._end(messages, flow_vars, escalated=True)  # A human owns it now             # end chat
        # job_message is the user-safe outcome line (see diagnostics_completed).
        if job.get("job_message"):  # The safe outcome line, if there is one                         # have line?
            messages.append(job["job_message"])  # Never job_output -- that is support-only          # reply
        messages.append("Issue Resolved?")  # Sets up _final_turn                                    # ask
        return messages, AWAITING_FINAL, flow_vars  # Wait for their confirmation                    # wait
