####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# JobRunner: the seam between "a job KIND" and the agent that actually provides it.                #
#   1. DISPATCH. kind -> agent, in one dict; a third job type is one entry plus its own folder.    #
#   2. ERROR TRANSLATION with the retry semantics JobService depends on (transient vs not).        #
#   3. TRACE HYGIENE. Drop the row for a poll that only says "still running".                      #
#   4. NO SIMULATION MODE: everything here raises rather than inventing a result.                  #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.core.config.logger records a failed start with the underlying exception type.            #
#   - app.core.constants supplies the two job-kind literals used as the dispatch keys.             #
#   - app.core.errors supplies AppError / UpstreamTransient / UpstreamUnavailable -- the retry     #
#       boundary is expressed entirely by which of those two is raised.                            #
#   - app.core.tracing.NULL_TRACE is the default, so no caller has to pass a trace.                #
#   - app.domain.run_state interprets whatever the agent reported; kept next door as pure logic.   #
####################################################################################################
"""JobRunner: which agent runs a job kind, and what its answer is worth.

What this module is:
    - One class with four methods: baseline_stamp(), start(), check_status() and the
      private _traced() that keeps the agent_calls table honest.

Why this exists:
    - The diagnostics and troubleshoot agents used to be Function Apps behind POST /start
      and GET /status; they are now classes in agents/diagnostics/ and agents/troubleshoot/,
      called directly. This class is the seam between "a job kind" -- which is all the flow
      knows and all it should know -- and the agent that provides it.
    - It does three things and no more:
        1. DISPATCH. kind -> agent, in one dict. Adding a third job type is one entry here
           plus its own folder under agents/.
        2. ERROR TRANSLATION with the retry semantics the caller depends on.
           UpstreamTransient means "ask again in 30 seconds"; UpstreamUnavailable means
           "this will not get better on its own". JobService retries the first and lets the
           second through, so getting this boundary right is what decides whether a broken
           agent surfaces in seconds or silently burns the job's 20-minute deadline.
        3. TRACE HYGIENE. A poll that says "still running" has its row dropped, because a
           job is polled every 30s for minutes and ~30 of its 31 rows would otherwise say
           nothing.

Security and production notes:
    1. NO SIMULATION MODE. There is no "pretend the job worked" switch and no fallback for
       an agent that isn't ready: everything below raises. A previous version faked progress
       whenever a URL was unset, which made the app tell real users "No issues found;
       Outlook profile repaired" while nothing had run -- and resolve their ServiceNow
       incident when they confirmed. Tests inject a scripted stand-in for this class.
    2. The interpretation of what a report MEANS lives in run_state.py, next door, because
       it is pure logic and deserves to be tested as such.
"""

# ============================================ Imports =============================================
from app.core.config import logger  # Records a failed start with the exception type                 # config
from app.core.constants import JOB_KIND_DIAGNOSTIC, JOB_KIND_TROUBLESHOOT  # Dispatch keys           # constants
from app.core.errors import AppError, UpstreamTransient, UpstreamUnavailable  # Retry boundary       # errors
from app.core.tracing import NULL_TRACE  # Default trace, so no caller must pass one                 # tracing
from app.domain import run_state  # Pure interpretation of whatever the agent reported               # run state


# =========================================== Job runner ===========================================
class JobRunner:
    """Routes a job kind to its agent and reports {state, message, output}.

    What this class is:
        - A dispatch table plus the error-translation layer around two agent calls.

    Why it exists:
        - So the flow can name WHAT it wants done (a kind) without knowing WHICH class does
          it, and so the retry decision is made in exactly one place.

    Security and production notes:
        1. Both start() and check_status() raise rather than returning a placeholder. A fake
           job_id or a fabricated status is how a user gets told their machine was repaired
           when nothing ran.
        2. The transient/permanent split is a deliberate policy, not an accident of which
           exception happened to be handy -- see each `except` below.

    Example:
        >>> JobRunner(diag, trouble).start("diagnostic", "c1", {"device_id": "d1"})  # doctest: +SKIP
        'job-42'
    """

    def __init__(self, diagnostics, troubleshoot, trace=None) -> None:
        """Build the kind -> agent table and adopt this request's trace.

        Args:
            diagnostics: The DiagnosticsAgent instance for this request.
            troubleshoot: The TroubleshootAgent instance for this request.
            trace: This request's CallTrace, or None for NULL_TRACE.

        Returns:
            None.
        """
        # Kind -> agent. The flow names a KIND (it knows what it wants done); which class
        # provides it is settled here.
        self._agents = {
            JOB_KIND_DIAGNOSTIC: diagnostics,  # Read-only investigation                             # dispatch
            JOB_KIND_TROUBLESHOOT: troubleshoot,  # Remediation that CHANGES the machine             # dispatch
        }
        self._trace = trace if trace is not None else NULL_TRACE  # Never None, so no branch         # trace

    def _agent(self, kind: str):
        """The agent registered for `kind`, or raise if there is none.

        Raises:
            UpstreamUnavailable: The kind is not registered -- a bug, not a misconfiguration.
        """
        agent = self._agents.get(kind)  # None when the kind is not in the dispatch table            # look up
        if agent is None:  # A bug, not a configuration problem: the kind is our own literal         # missing?
            # A bug, not a configuration problem: the kind is written in our own code.
            raise UpstreamUnavailable(f"no agent registered for job kind {kind!r}")  # -> 502        # raise
        return agent  # The DiagnosticsAgent or TroubleshootAgent for this request                   # return agent

    # ============================================== Trigger =======================================
    def baseline_stamp(self) -> str:
        """Trigger-time stamp to store with the job -- see run_state.baseline_stamp."""
        return run_state.baseline_stamp()  # Delegated, so the skew rule has one owner               # stamp

    def start(self, kind: str, conversation_id: str, params: dict) -> str:
        """Kick off the long-running run and return its job_id (does NOT wait).

        What this method does:
            - Resolves the agent, calls its start() with `params` spread as keyword
              arguments, translates any failure, and validates that a usable job_id came
              back.

        Why it exists:
            - `params` is what the flow collected for this kind -- device_id, kb_id, and
              either a summary or a script_name plus its params. It is passed as keyword
              arguments, so a field the agent does not accept is a TypeError here, at the
              call site, instead of a silently ignored key in a JSON body.

        Security and production notes:
            1. Raises rather than inventing a job_id: a fake id would make the flow report a
               device repair that never happened.
            2. A start failure is NEVER transient. Retrying a trigger risks starting a
               SECOND remediation on someone's machine, so every failure path here raises
               the permanent error.
            3. An AppError from the agent is re-raised untouched -- the agent already decided
               whether a retry is worthwhile, so we must not relabel it.

        Args:
            kind: JOB_KIND_DIAGNOSTIC or JOB_KIND_TROUBLESHOOT.
            conversation_id: The Foundry conversation this job belongs to.
            params: Keyword arguments for the agent's start(); None is treated as {}.

        Returns:
            The agent's job_id, guaranteed to be a non-empty string.

        Raises:
            UpstreamUnavailable: Unknown kind, agent not implemented, the start call failed,
                or the agent returned no usable job_id.

        Example:
            >>> runner.start("diagnostic", "c1", {"device_id": "d1", "kb_id": "KB1"})  # doctest: +SKIP
            'sd-9:d1'
        """
        agent = self._agent(kind)  # Raises for an unregistered kind                                 # resolve
        try:  # The trigger itself; must never be retried, so every failure is permanent             # start try
            job_id = agent.start(conversation_id, **(params or {}))  # Spread: a bad field is a TypeError  # trigger
        except AppError:  # Already a domain error, with its own retry semantics decided             # domain err
            # Already a domain error -- the agent decided whether a retry is worthwhile,
            # so don't relabel it.
            raise  # Pass it up unchanged                                                            # re-raise
        except NotImplementedError as exc:  # The agent's _call hook is still a stub                 # not built
            raise UpstreamUnavailable(f"{kind} agent is not implemented yet") from exc  # -> 502     # raise
        except Exception as exc:  # Anything else: SDK error, auth, network, bad argument            # start failed
            logger.error(  # Name the exception type, which the generic body will not carry          # log error
                "%s start failed conv_id=%s (%s): %s",
                kind, conversation_id, type(exc).__name__, exc,
            )
            raise UpstreamUnavailable(f"{kind} start failed: {exc}") from exc  # Never retried       # raise

        if not job_id or not isinstance(job_id, str):  # Ran, but gave us nothing to poll            # usable id?
            # The agent ran but gave us nothing to poll -- a contract violation, not a
            # blip, so it must not be retried.
            raise UpstreamUnavailable(f"{kind} start returned no job_id ({job_id!r})")  # -> 502     # raise
        return job_id  # Stored on the conversation row by the caller                                # return id

    # ============================================== Status ========================================
    def check_status(self, kind: str, job_id: str, baseline: str = "") -> dict:
        """Ask the agent how the job is going. Returns {state, message, output}.

        What this method does:
            - Resolves the agent, calls status(job_id), translates any failure, checks the
              shape, then hands the report to run_state.derive() and applies trace hygiene.

        Why it exists:
            - `baseline` is the trigger-time timestamp (conversations.job_baseline), used to
              tell OUR fresh result apart from a stale report left by an earlier run on the
              same device.

        Security and production notes:
            1. A generic failure here is UpstreamTransient, unlike start(): this is polled
               every ~30s for minutes, and one bad poll must cost a poll rather than the
               whole job. Retrying a READ is safe -- it cannot start a second remediation.
            2. NotImplementedError is NOT transient: retrying three times would just delay
               the same answer, and the poller would then report "still working" until the
               job expired.

        Args:
            kind: JOB_KIND_DIAGNOSTIC or JOB_KIND_TROUBLESHOOT.
            job_id: The id the agent returned from start(); we never parse it.
            baseline: Trigger-time stamp used by the freshness gate in run_state.

        Returns:
            {state, message, output} -- state is one of running/done/failed.

        Raises:
            UpstreamUnavailable: Unknown kind, no job_id, agent not implemented, or a
                non-dict report.
            UpstreamTransient: A momentary failure worth one more poll.

        Example:
            >>> runner.check_status("diagnostic", "sd-9:d1")["state"]  # doctest: +SKIP
            'running'
        """
        agent = self._agent(kind)  # Raises for an unregistered kind                                 # resolve
        if not job_id:  # Nothing to poll -- a bug in the caller, not a blip                         # have id?
            raise UpstreamUnavailable(f"{kind} status check has no job_id")  # Never retried         # raise

        try:  # A READ, so a blip here is safe to retry                                              # status try
            data = agent.status(job_id)  # The agent's own report, in either shape                   # poll agent
        except AppError:  # Already a domain error with its retry semantics decided                  # domain err
            raise  # Pass it up unchanged                                                            # re-raise
        except NotImplementedError as exc:  # The agent's _call hook is still a stub                 # not built
            # NOT transient: retrying three times would just delay the same answer, and
            # the poller would then report "still working" until the job expired.
            raise UpstreamUnavailable(f"{kind} agent is not implemented yet") from exc  # -> 502     # raise
        except Exception as exc:  # SDK error, network, throttling -- one bad poll                   # blip
            # Treated as a blip so the caller retries: this is polled every ~30s for
            # minutes, and one bad poll must cost a poll rather than the whole job.
            raise UpstreamTransient(f"{kind} status check failed: {exc}") from exc  # Retried        # raise

        if not isinstance(data, dict):  # A non-dict cannot be interpreted at all                    # a dict?
            raise UpstreamUnavailable(  # Contract violation, so not retried                         # raise
                f"{kind} status returned {type(data).__name__}, expected a dict"
            )
        return self._traced(run_state.derive(data, baseline))  # Interpret, then tidy the trace      # derive

    def _traced(self, status: dict) -> dict:
        """Keep the trace row only when the poll carries an outcome.

        What this method does:
            - Drops the last agent_calls row when the derived state is still "running", then
              returns the status unchanged.

        Why it exists:
            - The agent recorded its own row by the time we get here, so a "still running"
              answer is discarded again -- otherwise the ~30 no-news polls of every job
              would be the large majority of the agent_calls table.

        Security and production notes:
            1. A FAILED poll is never dropped: it raised above and never reached this
               method. So the table keeps every failure and only discards the no-news polls.

        Args:
            status: The derived {state, message, output} dict.

        Returns:
            The same dict, unchanged.
        """
        if status.get("state") == "running":  # No news -> the row would say nothing useful          # no news?
            self._trace.drop_last()  # Discard it; failures raised earlier and never get here        # drop row
        return status  # Returned unchanged either way                                               # return
