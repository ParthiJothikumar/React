####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Decides what a device job's report MEANS -- pure functions, no I/O anywhere.                     #
#   1. derive(): collapse either report shape into exactly {state, message, output}.               #
#   2. Enforce the message-vs-output split, which is a SECURITY boundary, not a naming choice.     #
#   3. baseline_stamp() + is_newer(): tell OUR fresh result from a stale run left by a prior run.  #
#   4. Never report "complete" for an outcome we do not recognise -- surface it as failed.         #
#                                                                                                  #
# Source:-                                                                                         #
#   - datetime / timedelta / timezone parse and compare the device's report timestamp against      #
#       our trigger-time baseline, all in UTC.                                                     #
#   - app.core.config.logger records an unrecognised detection/remediation state pair.             #
####################################################################################################
"""What a device job's report MEANS -- pure functions, no I/O.

What this module is:
    - A device agent hands back whatever its runner produced. This module turns that into
      the only three fields the rest of the app is allowed to know about:

        state    ->  running | done | failed. For CODE to branch on.
        message  ->  one line safe to SHOW THE USER, whatever the state. Our own wording,
                     or the agent's `userMessage` when it provides one.
        output   ->  raw stdout/stderr from the script on the user's device. Stored in
                     conversations.job_output for support, and NEVER returned to the browser.

Why this exists:
    - WHY THIS IS NOT IN THE AGENTS. An agent knows how its run works; it does not know
      what this product shows a user, what goes into the transcript, or how a stale device
      report is told apart from a fresh one. Those are the caller's concerns, and they are
      identical for both device agents.
    - WHY IT IS ITS OWN MODULE, and not part of JobRunner: nothing here touches an agent, a
      clock we don't control, or a database, so every branch below can be tested by passing
      a dict -- which matters, because these branches are the difference between telling a
      user their machine was fixed and telling them it wasn't.

Security and production notes:
    1. `message` vs `output` is a SECURITY boundary, not a naming preference. The scripts
       belong to other teams and can change without our code changing, so their output
       cannot be treated as display text. Real remediation output routinely contains
       profile paths (C:\\Users\\jdoe\\...\\jdoe@company.com.ost), registry values, mailbox
       addresses and internal server names -- and anything we show is also written into the
       transcript, so it would be replayed on every history load. Deciding it in ONE pure
       function beats trusting two agent implementations to each decide it the same way.
    2. The final branch fails CLOSED: an outcome we do not recognise is reported as failed
       with a warning, never as "Complete". Saying a machine was fixed when it was not is
       the single worst thing this app can do.
"""

# ============================================ Imports =============================================
from datetime import datetime, timedelta, timezone  # Parse + compare report stamps, in UTC          # stdlib datetime

from app.core.config import logger  # Records an unrecognised state pair as a WARNING                # config

# =========================================== Constants ============================================
# Safety margin so tiny clock differences between our host and the device management
# service cannot make us reject our own fresh result as "stale". 2 min is well under a
# 3-15 min run.
BASELINE_SKEW = timedelta(seconds=120)  # Clock-skew allowance on the freshness gate                 # skew

# Detection is still in flight for these -> the run isn't done reporting yet.
TRANSIENT_DETECTION = (None, "", "unknown", "pending")  # Not terminal: keep polling                 # in flight

# Map any terminal word an agent might send to our 3-word contract; unknown -> running.
STATE_MAP = {
    "done": "done", "success": "done", "completed": "done", "skipped": "done",  # Succeeded          # to done
    "failed": "failed", "error": "failed", "timed_out": "failed",  # Did not succeed                 # to failed
    "not_applicable": "failed",  # The fix does not apply -- a failure from the user's view          # to failed
}


# ========================================= Freshness gate =========================================
def baseline_stamp() -> str:
    """UTC timestamp captured at trigger; a device report NEWER than this is OUR run.

    What this function does:
        - Returns "now, minus BASELINE_SKEW" as an ISO-8601 UTC string.

    Why it exists:
        - Stored on the conversation row (job_baseline) and passed back to derive() on every
          poll. Without it, a run-state row left on the device by a PREVIOUS run of the same
          script reads as a finished result the instant we start -- so the user would be
          told their new problem was fixed by an old repair.

    Security and production notes:
        1. The skew is SUBTRACTED, making the gate slightly permissive. That is the right
           direction: rejecting our own fresh result would leave the job polling until it
           expired, whereas the 2-minute window is far shorter than any real run.

    Returns:
        The trigger-time cut-off as an ISO-8601 UTC string.

    Example:
        >>> baseline_stamp()  # doctest: +SKIP
        '2026-09-09T11:20:33.123456+00:00'
    """
    return (datetime.now(timezone.utc) - BASELINE_SKEW).isoformat()  # Permissive by 2 min           # stamp


def is_newer(last_updated: str, baseline: str) -> bool:
    """True if the run-state row is newer than the baseline (i.e. it's OUR result).

    What this function does:
        - Compares two ISO-8601 stamps, falling back to a lexical comparison if either
          cannot be parsed.

    Why it exists:
        - No baseline -> everything counts (nothing to compare against). A baseline but no
          timestamp on the row -> NOT ours: we cannot show a user a result we can't date.

    Security and production notes:
        1. The no-timestamp case returns False deliberately. Treating an undateable row as
           fresh is exactly how a previous run's result gets reported as this one's.
        2. The fallback is safe because ISO-8601 UTC sorts lexically anyway.

    Args:
        last_updated: The device report's own timestamp, possibly empty.
        baseline: Our trigger-time cut-off, possibly empty.

    Returns:
        True when the row can be attributed to our own run.

    Example:
        >>> is_newer("2026-09-09T11:30:00+00:00", "2026-09-09T11:20:00+00:00")
        True
    """
    if not baseline:  # Nothing to compare against -> accept whatever came back                      # no baseline?
        return True  # e.g. a job started before baselines were stored                               # accept
    if not last_updated:  # Undateable row -> must NOT be treated as ours                            # no stamp?
        return False  # Fails CLOSED: an old result must never be reported as this run's             # reject
    try:  # Proper datetime comparison, handling the trailing Z form                                 # parse try
        return _parse(last_updated) > _parse(baseline)  # Strictly newer counts as ours              # compare
    except ValueError:  # Unparseable stamp -- fall back to text order                               # bad stamp
        return last_updated > baseline  # ISO-8601 UTC sorts lexically anyway                        # lexical


def _parse(ts: str) -> datetime:
    """Parse an ISO-8601 stamp, accepting the trailing 'Z' form the device APIs use."""
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))  # fromisoformat rejects a bare Z       # parse


# ===================================== Report interpretation ======================================
def derive(data: dict, baseline: str = "") -> dict:
    """Collapse one status report into {state, message, output}.

    What this function does:
        - Chooses an interpreter by shape: raw device run-state fields when detectionState
          or remediationState is present, otherwise the already-normalised form.

    Why it exists:
        - Accepts either shape an agent may return:
            * RAW device run-state fields (detectionState, remediationState,
              lastStateUpdateDateTime, the script outputs) -- interpreted below;
            * an already-normalised {"state": ..., "userMessage": ..., "result": ...}.
        - So an agent team can hand back whatever their runner produces without either side
          negotiating a wire format.

    Security and production notes:
        1. Both paths return the same three keys, so no caller has to know which shape
           arrived -- and neither path can put raw output into `message`.

    Args:
        data: The agent's status report, in either shape.
        baseline: Trigger-time cut-off used by the raw-device path's freshness gate.

    Returns:
        {state, message, output} -- state is one of running/done/failed.

    Example:
        >>> derive({"state": "success", "userMessage": "Fixed"})["state"]
        'done'
    """
    if "detectionState" in data or "remediationState" in data:  # Raw device run-state shape         # raw shape?
        return _from_device_run_state(data, baseline)  # Needs the freshness gate                    # interpret raw
    return _from_normalised(data)  # The agent already collapsed it to a state word                  # interpret norm


def _from_normalised(data: dict) -> dict:
    """An agent that already reports a state word.

    What this function does:
        - Maps the agent's state/status word through STATE_MAP (unknown -> running), picks
          the first user-written message field, and treats `result` as raw output.

    Why it exists:
        - Its `result` is treated as RAW OUTPUT, not as a message: we don't know how it was
          written, so it is safe-by-default and only surfaces to the user if the agent also
          sends a field written for them (`userMessage`).

    Security and production notes:
        1. An unrecognised state word becomes "running", not "done". The job then keeps
           polling and eventually expires, which is a visible failure rather than a false
           success.

    Args:
        data: The agent's normalised report.

    Returns:
        {state, message, output}.

    Example:
        >>> _from_normalised({"state": "banana"})["state"]
        'running'
    """
    raw = (data.get("state") or data.get("status") or "running").lower()  # Either spelling          # read state
    return {
        "state": STATE_MAP.get(raw, "running"),  # Unknown -> running, so it never fakes done        # state
        "message": (  # First field actually WRITTEN for a user; never `result`                      # message
            data.get("userMessage") or data.get("progress")
            or data.get("message") or "Working..."
        ),
        "output": data.get("result"),  # Raw by assumption -> support only, never the browser        # output
    }


def _from_device_run_state(data: dict, baseline: str) -> dict:
    """Interpret RAW device run-state fields.

    What this function does:
        - Two steps: (1) the gate -- is a FRESH result from our trigger back yet? -- and
          only then (2) the outcome -- did the detection/remediation scripts succeed?

    Why it exists:
        - Assumes the fields are at the TOP LEVEL of the dict. If an agent nests them (e.g.
          under data["value"][0]), unwrap in the agent before returning.

    Security and production notes:
        1. Every script output field is collected into `output` and NEVER into `message`.
           The script's own error text is the most likely place to carry internal paths and
           server names.
        2. The last branch fails CLOSED: an unrecognised state pair is logged and reported
           as failed. Never say "Complete" for something we did not understand.

    Args:
        data: The raw device run-state report.
        baseline: Trigger-time cut-off; a report older than this is not ours.

    Returns:
        {state, message, output}.

    Example:
        >>> _from_device_run_state({"detectionState": "success",
        ...     "lastStateUpdateDateTime": ""}, "")["state"]
        'done'
    """
    detection = data.get("detectionState")  # Did the detection script find a problem?               # detection
    remediation = data.get("remediationState")  # Did the fix script run, and succeed?               # remediation
    last_updated = data.get("lastStateUpdateDateTime")  # When the device last reported              # report time
    # Everything the device printed, kept together. Goes to conversations.job_output for
    # support; never to the browser.
    raw_output = (  # First non-empty script output/error, in usefulness order                       # raw output
        data.get("postRemediationDetectionScriptOutput")
        or data.get("preRemediationDetectionScriptOutput")
        or data.get("remediationScriptError")
        or data.get("preRemediationDetectionScriptError")
    )
    # If an agent provides a field written FOR the end user, prefer it over our generic
    # wording (see the note in the module docstring).
    user_message = data.get("userMessage")  # Written for a user, so safe to show                    # user msg

    # (1) Gate: no fresh row yet (the job was already triggered, so we can wait), or
    # detection still running -> keep polling.
    if not is_newer(last_updated, baseline) or detection in TRANSIENT_DETECTION:  # Stale or in flight  # gate
        return {
            "state": "running",  # Keep polling; the caller drops this trace row                     # state
            "message": f"Working... ({detection or 'queued'})",  # Our own wording only              # message
            "output": None,  # Nothing final to keep yet                                             # output
        }

    # (2) Outcome -- the row is fresh and detection is terminal
    # (detection in {success, fail, scriptError, notApplicable}).

    # Hard failures: a script crashed, or remediation ran but didn't resolve it. The
    # script's own error text is the most likely place to carry internal paths and server
    # names, so it goes to `output`, never into the message.
    if detection == "scriptError" or remediation in (  # A script crashed on the device              # crashed?
        "remediationFailed", "scriptError"
    ):
        return {
            "state": "failed",  # The flow escalates and leaves the ticket open                      # state
            "message": "Script error on the device",  # Our own wording; no script text              # message
            "output": raw_output,  # The crash text -- support only                                  # output
        }
    if detection == "notApplicable":  # The fix does not apply to this machine                       # n/a?
        return {
            "state": "failed",  # Still a failure from the user's point of view                      # state
            "message": "This fix doesn't apply to your device",  # Our own wording                   # message
            "output": raw_output,  # Whatever the script printed -- support only                     # output
        }

    # Success #1: remediation actually fixed it (takes priority -- true even if the
    # pre-remediation detectionState still reads 'fail').
    if remediation == "success":  # Checked BEFORE detection, deliberately                           # fixed?
        return {
            "state": "done",  # The flow asks the user to confirm                                    # state
            "message": user_message or "The issue was fixed on your device.",  # Safe line           # message
            "output": raw_output,  # Support only                                                    # output
        }

    # Success #2: detection found nothing wrong (healthy). Covers a 'skipped' remediation
    # state and detect-only policies where remediation is 'unknown'.
    if detection == "success":  # Nothing was wrong in the first place                               # healthy?
        return {
            "state": "done",  # The flow asks the user to confirm                                    # state
            "message": user_message or "No issues were found on your device.",  # Safe line          # message
            "output": raw_output,  # Support only                                                    # output
        }

    # Everything left = an issue was FOUND but NOT fixed (detect-only, skipped, or an
    # unrecognised state). Never say "Complete" -- surface it.
    logger.warning(  # Names the exact pair, so a new device state is discoverable                   # log warn
        "Unresolved/unknown remediation states: detection=%s remediation=%s",
        detection, remediation,
    )
    return {
        "state": "failed",  # Fails CLOSED: a false success is the worst possible outcome            # state
        "message": "We found an issue but couldn't fix it automatically.",  # Honest line            # message
        "output": raw_output,  # Support only                                                        # output
    }
