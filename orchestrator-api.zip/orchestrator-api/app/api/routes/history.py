####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The two read-only controllers: the sidebar list and one session's transcript.                    #
#   1. GET /sessions/{user_id}          -> a user's most recent sessions, newest first.            #
#   2. GET /conversations/{user_id}/{session_id} -> that session's messages, in display order.     #
#                                                                                                  #
# Source:-                                                                                         #
#   - fastapi supplies the router, Depends and HTTPException.                                      #
#   - app.api.schemas supplies the two response models, which drop any undeclared field.           #
#   - app.deps.get_history_service injects the service plus its per-request DB connection.         #
####################################################################################################
"""History controllers: the read-only session and transcript queries.

What this module is:
    - Two GET endpoints, each calling exactly one HistoryService method.

Why this exists:
    - These are the only two endpoints that touch no agent and no flow, so they need no
      timer, no trace and no fallback payload -- a failure here is simply a 500.

Security and production notes:
    1. Both are scoped by the user_id in the path, and every repository query below binds
       it, so one user's id cannot read another user's history.
    2. Both declare a response_model, so an internal field added to a service return value
       would be dropped rather than shipped.
"""

# ============================================ Imports =============================================
from fastapi import APIRouter, Depends, HTTPException  # Router, injection, error responses          # fastapi

from app.api.schemas import SessionListResponse, TranscriptResponse  # The leakage guards            # schemas
from app.core.config import logger  # Records the unexpected failures                                # config
from app.deps import get_history_service  # Injects the service + its DB connection                  # deps
from app.services import HistoryService  # Type of the injected service                              # services

# ============================================= Router =============================================
router = APIRouter(tags=["history"])  # Mounted under Settings.API_PREFIX by main.py                 # router


# ========================================== Session list ==========================================
@router.get("/sessions/{user_id}", response_model=SessionListResponse)
def get_sessions(
    user_id: str,
    service: HistoryService = Depends(get_history_service),
):
    """List a user's most recent sessions (up to 20), newest first.

    What this endpoint does:
        - Calls HistoryService.list_sessions and returns it, or logs and raises a 500.

    Why it exists:
        - This is the frontend's left panel. It carries no message content, so rendering
          the sidebar never ships a user's conversation text.

    Security and production notes:
        1. The cap of 20 is applied in the repository, so this endpoint cannot become an
           unbounded read however many sessions a user accumulates.
        2. The `except` logs with a traceback and returns a FIXED detail string -- no
           driver or SQL text reaches the caller.

    Args:
        user_id: Owner whose sessions to list; taken from the path.
        service: Injected HistoryService, holding this request's DB connection.

    Returns:
        {"sessions": [...]} validated through SessionListResponse.

    Raises:
        HTTPException: 500 when the read fails.
    """
    try:  # One service call; nothing else belongs in a controller                                   # read try
        return service.list_sessions(user_id)  # Capped at 20 by the repository                      # list
    except Exception:  # A read failure is simply a 500 -- there is no useful fallback               # read failed
        logger.exception("get_sessions failed user_id=%s", user_id)  # Traceback for us              # log error
        raise HTTPException(status_code=500, detail="Failed to load sessions")  # Fixed text         # raise 500


# =========================================== Transcript ===========================================
@router.get(
    "/conversations/{user_id}/{session_id}", response_model=TranscriptResponse
)
def get_conversation(
    user_id: str,
    session_id: str,
    service: HistoryService = Depends(get_history_service),
):
    """Return the session's messages as a flat list of {role, content}.

    What this endpoint does:
        - Rejects a blank session_id with a 400, then calls
          HistoryService.get_transcript, or logs and raises a 500.

    Why it exists:
        - The frontend renders one continuous thread, so it wants the session's turns
          already flattened rather than nested per conversation.

    Security and production notes:
        1. Reads conversation_turns, which holds the EXACT text shown to the user. Raw
           device output (job_output) and agent JSON live in other columns and can never
           appear here.
        2. Scoped by the path's user_id, which every repository query binds.

    Args:
        user_id: Owner of the session; taken from the path.
        session_id: The session whose transcript to return; taken from the path.
        service: Injected HistoryService, holding this request's DB connection.

    Returns:
        The transcript dict validated through TranscriptResponse.

    Raises:
        HTTPException: 400 for a blank session_id, 500 when the read fails.
    """
    if not session_id:  # A blank path segment is the caller's mistake, not ours                     # have id?
        raise HTTPException(status_code=400, detail="session_id is required")  # -> 400              # raise 400
    try:  # One service call; nothing else belongs in a controller                                   # read try
        return service.get_transcript(user_id, session_id)  # One flat [{role, content}] list        # read
    except Exception:  # A read failure is simply a 500 -- there is no useful fallback               # read failed
        logger.exception("get_conversation failed user_id=%s", user_id)  # Traceback for us          # log error
        raise HTTPException(status_code=500, detail="Failed to load conversations")  # Fixed text    # raise 500
