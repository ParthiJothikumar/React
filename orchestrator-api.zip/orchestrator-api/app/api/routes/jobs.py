####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The one controller behind GET /jobs/status -- the poll that advances a running device job.       #
#   1. Call JobService.advance_job and return its payload unchanged.                               #
#   2. Let NotFound (404) and UpstreamUnavailable (502) through, so the FE gets the right code.    #
#   3. Turn anything else into a 500 with a fixed detail string.                                   #
#                                                                                                  #
# Source:-                                                                                         #
#   - fastapi supplies the router, Depends and HTTPException.                                      #
#   - app.api.schemas.ChatResponse is the shared response shape -- and the leakage guard.          #
#   - app.deps.get_job_service injects the service plus its per-request DB connection.             #
####################################################################################################
"""Job controller: the poll that advances a running device job.

What this module is:
    - One GET endpoint calling exactly one JobService method.

Why this exists:
    - There is no backend queue: the frontend's ~30s poll is what drives a device job
      forward, and this is where that poll lands. The reaper calls the same service method
      directly, without going through HTTP.

Security and production notes:
    1. UpstreamUnavailable is re-raised deliberately so it maps to 502 rather than 500 --
       "the agent cannot answer", not "we are broken".
    2. The response goes through ChatResponse, so job_output can never leak into a poll
       response even if a service return value were to change.
"""

# ============================================ Imports =============================================
from fastapi import APIRouter, Depends, HTTPException  # Router, injection, error responses          # fastapi

from app.api.schemas import ChatResponse  # Shared response shape, and the leakage guard             # schemas
from app.core.config import logger  # Records the unexpected failures                                # config
from app.core.errors import NotFound, UpstreamUnavailable  # The two we deliberately re-raise        # errors
from app.deps import get_job_service  # Injects the service + its DB connection                      # deps
from app.services import JobService  # Type of the injected service                                  # services

# ============================================= Router =============================================
router = APIRouter(tags=["jobs"])  # Mounted under Settings.API_PREFIX by main.py                    # router


# =========================================== Job status ===========================================
@router.get("/jobs/status", response_model=ChatResponse)
def job_status(
    user_id: str,
    conversation_id: str,
    session_id: str = None,
    service: JobService = Depends(get_job_service),
):
    """The FE spinner polls this every ~30s to advance a running device job.

    What this endpoint does:
        - Calls JobService.advance_job. Re-raises NotFound and UpstreamUnavailable so
          main.py maps them; turns anything else into a 500.

    Why it exists:
        - `done` in the response is what tells the frontend to stop polling. Everything
          about WHEN a job advances, and who wins a race to advance it, is in JobService --
          this controller only carries the answer out.

    Security and production notes:
        1. UpstreamUnavailable means the diagnostics/troubleshoot agent cannot answer at
           all -- a 502 says that, where a blanket 500 would blame us.
        2. Unlike the chat endpoints there is NO fallback payload here: a poll that cannot
           be answered should surface as an error the FE can retry, not as a fabricated
           "still working" that would spin forever.

    Args:
        user_id: Owner of the conversation; a query parameter.
        conversation_id: The conversation whose job to advance; a query parameter.
        session_id: Echoed into the payload; optional.
        service: Injected JobService, holding this request's DB connection.

    Returns:
        The job payload validated through ChatResponse.

    Raises:
        NotFound: The conversation does not exist. -> 404 via main.py
        UpstreamUnavailable: The agent cannot answer at all. -> 502 via main.py
        HTTPException: 500 for anything else.
    """
    try:  # One service call; nothing else belongs in a controller                                   # poll try
        return service.advance_job(user_id, conversation_id, session_id)  # Timed inside             # advance
    except (NotFound, UpstreamUnavailable):  # Both already have the right status mapped             # mapped errs
        # UpstreamUnavailable means the diagnostics/troubleshoot agent cannot answer at
        # all -- a 502 says that, where a blanket 500 would blame us.
        raise  # main.py's handlers turn these into 404 and 502                                      # re-raise
    except Exception:  # Our own bug, or something unmapped                                          # poll failed
        logger.exception("job_status failed conv_id=%s", conversation_id)  # Traceback for us        # log error
        raise HTTPException(status_code=500, detail="Failed to read job status")  # Fixed text       # raise 500
