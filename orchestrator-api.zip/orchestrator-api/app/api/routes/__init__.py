####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Aggregates the app's three routers into the single `router` main.py mounts.                      #
#   1. Include the chat, jobs and history routers, so the set of endpoints reads as one list.      #
#   2. Serve the service banner at the prefix root (/api/).                                        #
#                                                                                                  #
# Source:-                                                                                         #
#   - fastapi.APIRouter is the aggregation primitive; the three sibling modules supply the         #
#       routers themselves. No prefix is applied here -- main.py owns that.                        #
####################################################################################################
"""The app's routers, aggregated into one.

What this package is:
    - One `router` object built from three modules:

        chat.py      POST /chat, POST /chat/continue
        jobs.py      GET  /jobs/status
        history.py   GET  /sessions/{user_id}, GET /conversations/{user_id}/{session_id}

Why this exists:
    - main.py includes `router` below under Settings.API_PREFIX, so every path here is
      served beneath /api. One module per group of endpoints, so adding an endpoint touches
      one file and the set of endpoints is readable from this list.

Security and production notes:
    1. No prefix is applied here. main.py owns that, which is what lets API_PREFIX move by
       configuration without touching a single route declaration.
"""

# ============================================ Imports =============================================
from fastapi import APIRouter  # The aggregation primitive                                           # fastapi

from app.api.routes import chat, history, jobs  # The three controller modules                       # controllers

# ======================================== Router assembly =========================================
router = APIRouter()  # The single object main.py mounts under Settings.API_PREFIX                   # root router
router.include_router(chat.router)  # POST /chat, POST /chat/continue                                # chat routes
router.include_router(jobs.router)  # GET /jobs/status                                               # job routes
router.include_router(history.router)  # GET /sessions/..., GET /conversations/...                   # history routes


# ========================================= Service banner =========================================
@router.get("/")
def read_root():
    """Service banner at the prefix root (/api/).

    What this endpoint does:
        - Returns a fixed one-key dict naming the service.

    Why it exists:
        - Kept for the callers and smoke checks that already use it -- the frontend's only
          call today is this one.

    Security and production notes:
        1. The App Service health probe uses /health instead -- see main.py -- because a
           probe should not depend on the prefix, and this endpoint's path moves with it.
        2. Touches no database and no agent, so it is safe to call at any rate.

    Returns:
        {"message": "IT Support Orchestrator API"}.

    Example:
        >>> read_root()
        {'message': 'IT Support Orchestrator API'}
    """
    return {"message": "IT Support Orchestrator API"}  # Fixed banner; no state is read              # banner
