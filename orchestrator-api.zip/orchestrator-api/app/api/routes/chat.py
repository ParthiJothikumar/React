####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The two chat controllers: start a conversation, and continue an existing one.                    #
#   1. POST /chat          -> ChatService.start_chat, with the ticket-aware failure payload.       #
#   2. POST /chat/continue -> ChatService.continue_chat, keeping the conversation on a failure.    #
#   3. Decide what a failure LOOKS LIKE: an assistant bubble, not a raw HTTP 500.                  #
#                                                                                                  #
# Source:-                                                                                         #
#   - fastapi supplies the router, Depends and HTTPException.                                      #
#   - app.api.responses supplies the three failure/ended payloads; app.api.schemas the models.     #
#   - app.core.errors supplies the three domain errors these controllers branch on.                #
#   - app.deps.get_chat_service injects the service plus its per-request DB connection.            #
####################################################################################################
"""Chat controllers: starting a conversation and continuing one.

What this module is:
    - Two POST endpoints, each calling exactly one ChatService method and choosing a
      response shape for each outcome.

Why this exists:
    - A failed chat turn is a PRESENTATION problem as much as an error: the frontend
      renders a bubble, so a raw 500 would leave the user staring at a broken page. These
      controllers decide which of the three payloads in api/responses.py fits.

Security and production notes:
    1. THE RETRY DECISION IS THE IMPORTANT ONE HERE. On a failed first turn we check
       exc.incident_id: if a ticket already exists, the user is handed the number instead of
       being told to try again -- because starting over is what opened a SECOND incident.
    2. On /chat/continue a failure reports exc.stage with done=False, so the frontend KEEPS
       the conversation. Claiming DONE there used to throw away a working conversation.
    3. NotFound is re-raised so it becomes a genuine 404; everything else is caught and
       turned into a friendly bubble, so no traceback ever reaches a browser.
"""

# ============================================ Imports =============================================
from fastapi import APIRouter, Depends, HTTPException  # Router, injection, error responses          # fastapi

from app.api.responses import (  # The three payloads a non-happy path can return                    # responses
    ended_chat_response,  # Finished normally: a 200 with done=True, error=False                     # payload
    escalated_chat_response,  # Failed, but a ticket already exists -- no retry ask                  # payload
    fallback_chat_response,  # Failed with nothing created -- a retry is right                       # payload
)
from app.api.schemas import ChatRequest, ChatResponse, ContinueChatRequest  # Models + guard         # schemas
from app.core.config import logger  # Records every failure with a traceback                         # config
from app.core.errors import ConversationEnded, NotFound, TurnFailed  # The three we branch on        # errors
from app.deps import get_chat_service  # Injects the service + its DB connection                     # deps
from app.services import ChatService  # Type of the injected service                                 # services

# ============================================= Router =============================================
router = APIRouter(tags=["chat"])  # Mounted under Settings.API_PREFIX by main.py                    # router


# =========================================== Start chat ===========================================
@router.post("/chat", response_model=ChatResponse)
def chat(
    payload: ChatRequest,
    service: ChatService = Depends(get_chat_service),
):
    """Start a new chat session and run the first turn.

    What this endpoint does:
        - Calls ChatService.start_chat. On TurnFailed it returns the escalated payload when
          a ticket already exists, otherwise the plain fallback. NotFound is re-raised.

    Why it exists:
        - On a server-side failure returns the fallback message instead of a raw 500, so
          the frontend renders an assistant bubble rather than choking.

    Security and production notes:
        1. `exc.incident_id` is the whole point of the TurnFailed branch. A real ticket
           exists, so we give them the number and do NOT invite a retry -- starting over is
           what produced duplicate ServiceNow incidents.
        2. When there is no incident, nothing was created anywhere -- no ticket, no row,
           nothing in the history -- so a retry starts genuinely fresh and is the right
           thing to ask for.

    Args:
        payload: Validated ChatRequest (user_id plus the opening message).
        service: Injected ChatService, holding this request's DB connection.

    Returns:
        A ChatResponse-shaped dict, whichever path was taken.

    Raises:
        NotFound: Re-raised so main.py maps it to 404.
    """
    try:  # One service call; nothing else belongs in a controller                                   # turn try
        return service.start_chat(payload.user_id, payload.message)  # The happy path                # start
    except ConversationEnded as exc:  # Not reachable today -- see the note below                    # ended
        # Unreachable today (a new chat starts at stage=None, which always has a
        # handler). Handled the same way as in /chat/continue so the two endpoints
        # behave identically if the flow ever gains a terminal first turn.
        return ended_chat_response(payload.user_id, None, str(exc))  # Author-written text           # ended reply
    except NotFound:  # A genuine client error, not something to dress up                            # not found
        raise  # client error -> 404 via the handler in main.py                                      # re-raise
    except TurnFailed as exc:  # The turn broke; what we say depends on the ticket                   # turn failed
        logger.exception(  # Traceback for us; the user sees only a safe bubble                      # log error
            "chat failed user_id=%s incident_id=%s", payload.user_id, exc.incident_id
        )
        if exc.incident_id:  # A REAL ticket exists -- do not ask them to start over                 # have ticket?
            # A real ticket exists. Give them the number, don't invite a retry.
            return escalated_chat_response(payload.user_id, exc.incident_id)  # No retry ask         # escalated
        # Nothing was created anywhere -- no ticket, no row, nothing in the history --
        # so a retry starts genuinely fresh and is the right thing to ask for.
        return fallback_chat_response(payload.user_id)  # done=True, stage=DONE by default           # fallback
    except Exception:  # Anything the service did not wrap in TurnFailed                             # unknown
        logger.exception("chat failed user_id=%s", payload.user_id)  # Traceback for us              # log error
        return fallback_chat_response(payload.user_id)  # Still a friendly bubble, not a 500         # fallback


# ========================================= Continue chat ==========================================
@router.post("/chat/continue", response_model=ChatResponse)
def continue_chat(
    payload: ContinueChatRequest,
    service: ChatService = Depends(get_chat_service),
):
    """Continue an ACTIVE conversation in a session by session_id.

    What this endpoint does:
        - Requires session_id (422 without it), then calls ChatService.continue_chat. On
          ConversationEnded it returns the ended payload; on TurnFailed it returns the
          fallback carrying the REAL stage with done=False. NotFound is re-raised.

    Why it exists:
        - `conversation_id` is still accepted on the request for older frontend builds, but
          the conversation is resolved from session_id only -- so a missing session_id is a
          422 rather than a silent lookup failure.

    Security and production notes:
        1. The TurnFailed branch reports exc.stage with done=False, so the FE KEEPS the
           conversation and the user can resend the same message. Claiming DONE here used
           to throw away a working conversation -- and produce a duplicate ServiceNow
           incident when the user started over.
        2. ConversationEnded is answered with a 200, not a 409: the FE needs done=True to
           reset itself, and a 409 carries no stage, no done flag and no messages. See
           ended_chat_response.

    Args:
        payload: Validated ContinueChatRequest (user_id, message, session_id).
        service: Injected ChatService, holding this request's DB connection.

    Returns:
        A ChatResponse-shaped dict, whichever path was taken.

    Raises:
        HTTPException: 422 when session_id is missing.
        NotFound: Re-raised so main.py maps it to 404.
    """
    if payload.session_id is None:  # The conversation is resolved from session_id only              # have id?
        raise HTTPException(  # A request we cannot act on at all                                    # raise 422
            status_code=422, detail="session_id or conversation_id is required"
        )
    try:  # One service call; nothing else belongs in a controller                                   # turn try
        return service.continue_chat(  # The happy path                                              # continue
            payload.user_id, payload.session_id, payload.message
        )
    except ConversationEnded as exc:  # Finished normally -- NOT a failure                           # ended
        # The conversation is finished -- not a failure. Return the normal shape with
        # done=True so the FE resets to a new chat, instead of a 409 it would have to
        # special-case. See ended_chat_response.
        return ended_chat_response(payload.user_id, payload.session_id, str(exc))  # 200, error=False  # ended reply
    except NotFound:  # A genuine client error, not something to dress up                            # not found
        raise  # the session/conversation genuinely doesn't exist -> 404 via main.py                 # re-raise
    except TurnFailed as exc:  # The conversation SURVIVED -- keep it and let them retry             # turn failed
        # The conversation survived -- report its real stage with done=False so the FE
        # keeps it and the user can resend the same message.
        logger.exception(  # Traceback for us; the user sees only a safe bubble                      # log error
            "continue_chat failed session_id=%s stage=%s",
            payload.session_id, exc.stage,
        )
        return fallback_chat_response(
            payload.user_id,
            session_id=payload.session_id,  # The session is still valid                             # session id
            conversation_id=exc.conversation_id,  # And so is the conversation                       # conv id
            stage=exc.stage,  # The REAL stage: only the service still knew it                       # true stage
            done=False,  # So the FE keeps the conversation instead of resetting                     # keep chat
        )
    except Exception:  # Anything the service did not wrap in TurnFailed                             # unknown
        logger.exception("continue_chat failed session_id=%s", payload.session_id)  # Traceback      # log error
        return fallback_chat_response(payload.user_id, session_id=payload.session_id)  # Friendly bubble  # fallback
