####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Package marker and map for `app.api` -- the only package that knows HTTP exists.                 #
#   1. Declare app.api as a package and name the three pieces inside it.                           #
#   2. Record what a controller is allowed to do: validate, call ONE service, shape a response.    #
#   3. Record that routes are declared WITHOUT the prefix, so it can move by configuration.        #
#                                                                                                  #
# Source:-                                                                                         #
#   - Nothing is imported here; the routers are aggregated in routes/__init__.py instead, so this  #
#       file stays a map rather than a second place that has to be kept in step.                   #
####################################################################################################
"""The HTTP edge -- the only package in the app that knows HTTP exists.

What this package is:
    - Three pieces:

        routes/       the controllers, one module per group of endpoints
        responses.py  the payloads returned when a turn fails or a chat has ended
        schemas.py    request models + response models (the data-leakage guard)

Why this exists:
    - A controller does three things and nothing else: validate the request shape, call ONE
      service method, and turn the result -- or a domain error from core/errors.py -- into a
      response. All sequencing and business policy lives in services/ and domain/, which is
      what keeps them testable and reusable without a web server.
    - The service (and its per-request DB connection) arrives via Depends, so there is no
      connection handling here either: deps.get_db() closes it after the response.

Security and production notes:
    1. schemas.py is a SECURITY control, not documentation: FastAPI serialises the return
       value through the declared response model and drops anything not listed, so an
       internal field cannot leak by accident. See its module docstring.
    2. ROUTES ARE DEFINED WITHOUT THE PREFIX. main.py applies Settings.API_PREFIX (default
       "/api"), so `@router.post("/chat")` is served as POST /api/chat. Keeping the prefix
       out of the route declarations is what lets it move by configuration -- it was
       /workflow while the Functions host mounted the whole app there.

Example:
    >>> from app.api.routes import router  # doctest: +SKIP
"""
