####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# Request and response models -- and the response models are a DATA-LEAKAGE GUARD.                 #
#   1. Bound every inbound string, so an unbounded body cannot reach the DB or the agents.         #
#   2. Declare exactly what each endpoint may return; FastAPI drops everything else.               #
#   3. Keep the session/transcript shapes the frontend reads in one reviewable place.              #
#                                                                                                  #
# Source:-                                                                                         #
#   - pydantic (BaseModel / Field) does the validation, the length bounds and the serialisation    #
#       filtering; typing (List / Optional) types the collections and the nullable fields.         #
####################################################################################################
"""Request and response models (Pydantic).

What this module is:
    - Three request models and five response models, one per endpoint shape.

Why this exists:
    - The response models are a security control, not documentation. FastAPI serialises the
      return value THROUGH the declared model and drops anything not listed, so a field
      that should never reach the browser cannot leak by accident -- e.g. if `flow_vars`
      (which holds last_error, kb_id and incident_id) were ever added to a payload dict, it
      would be stripped here rather than shipped.

Security and production notes:
    1. Keep every field a controller returns declared below, including the error fields on
       the fallback path: once response_model is set, a MISSING required field becomes a
       500. That is the one way this guard can bite you.
    2. Every inbound string is length-bounded. `message` is forwarded verbatim to the
       agents and stored, so an unbounded one is both a storage and a cost problem.
"""

# ============================================ Imports =============================================
from typing import List, Optional  # Collection and nullable field types                             # stdlib typing

from pydantic import BaseModel, Field  # Validation, length bounds, response filtering               # pydantic


# ========================================= Request models =========================================
class ChatRequest(BaseModel):
    """Body of POST /chat -- the first turn of a brand-new conversation."""

    user_id: str = Field(min_length=1, max_length=200)  # Matches the NVARCHAR(200) column           # user id
    # Bounded because the column is NVARCHAR(MAX) but user_id is NVARCHAR(200), and an
    # unbounded message is forwarded verbatim to the agents.
    message: str = Field(min_length=1, max_length=8000)  # Forwarded verbatim to the agents          # message


class ContinueChatRequest(BaseModel):
    """Body of POST /chat/continue -- one more turn on an existing conversation."""

    user_id: str = Field(min_length=1, max_length=200)  # Matches the NVARCHAR(200) column           # user id
    message: str = Field(min_length=1, max_length=8000)  # Forwarded verbatim to the agents          # message
    session_id: Optional[str] = Field(default=None, max_length=200)  # The controller requires it    # session id
    # Accepted for backwards compatibility with older frontend builds; the service
    # resolves the conversation from session_id only.
    conversation_id: Optional[str] = Field(default=None, max_length=200)  # Accepted, then ignored   # legacy


# ======================================== Response models =========================================
class ChatResponse(BaseModel):
    """What /chat, /chat/continue and /jobs/status return.

    What this class is:
        - The single response shape for all three command endpoints, so the frontend has
          one rendering path.

    Security and production notes:
        1. This is the leakage guard: anything a controller returns that is NOT listed here
           is dropped before serialisation. flow_vars, last_error and job_output are all
           absent deliberately.
        2. Every field has a default, so a controller that omits one cannot turn a handled
           failure into a 500.
    """

    user_id: str  # Echoed so the FE can key its state without tracking it                           # user id
    session_id: Optional[str] = None  # None on a failed first turn: nothing was saved               # session id
    conversation_id: Optional[str] = None  # None when no conversation was ever created              # conv id
    stage: Optional[str] = None  # Internal flow state; the FE should branch on done/error           # stage
    done: bool = False  # The FE's "reset and start a new chat" signal                               # done flag
    messages: List[str] = []  # One bubble per line, already filtered of blanks                      # bubbles
    answer: str = ""  # The same content as one string                                               # answer
    # Set only on the fallback path, so the FE can render an error bubble.
    error: bool = False  # Distinguishes "failed" from "completed normally"                          # error flag


class SessionSummary(BaseModel):
    """One row of the frontend's left panel. No message content.

    What this class is:
        - The sidebar row: ids, the title and the two timestamps.

    Why it exists:
        - The field names match the sessions table columns, because list_recent() returns
          rows keyed by column name and they are validated straight into this model. So
          renaming a column here renames the JSON field the frontend receives --
          created_at/updated_at became started_at/last_updated_at.

    Security and production notes:
        1. Deliberately carries NO message content, so rendering the sidebar never ships a
           user's conversation text. The FE fetches transcripts per session instead.
    """

    id: Optional[str] = None  # Primary key of the session row                                       # id
    session_id: Optional[str] = None  # Same value; kept as its own column for the FE                # session id
    current_conversation_id: Optional[str] = None  # What clicking this row opens                    # current conv
    title: Optional[str] = None  # First write wins, so a chat keeps its name                        # title
    started_at: Optional[str] = None  # Written once, when the session was created                   # started at
    last_updated_at: Optional[str] = None  # The sidebar's sort key                                  # updated at


class SessionListResponse(BaseModel):
    """What GET /sessions/{user_id} returns: the sidebar, newest first."""

    sessions: List[SessionSummary] = []  # Up to 20, capped by the repository                        # sidebar


class TranscriptTurn(BaseModel):
    """One message of a replayed transcript, exactly as the user saw it."""

    role: str  # "user" or "assistant"                                                               # role
    content: str  # The EXACT text shown, post-translation -- never agent JSON                       # content


class TranscriptResponse(BaseModel):
    """What GET /conversations/{user_id}/{session_id} returns: one flat thread."""

    user_id: str  # Echoed so the FE can key its state                                               # user id
    session_id: Optional[str] = None  # Which session this transcript belongs to                     # session id
    conversations: List[TranscriptTurn] = []  # Flat and in display order                            # messages
