####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The payloads returned when a turn fails, or when a conversation has already ended.               #
#   1. fallback_chat_response(): a failed turn, shaped like a normal assistant bubble.             #
#   2. escalated_chat_response(): a failed turn where a ticket ALREADY exists -- no retry ask.     #
#   3. ended_chat_response(): a conversation that finished normally. A 200, not a 409.             #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.core.constants.DONE is the stage every one of these reports, because it is the           #
#       frontend's existing "start a new chat" signal -- no invented "ERROR" stage.                #
####################################################################################################
"""The payloads returned when a turn fails, or when a conversation has already ended.

What this module is:
    - Two fixed message strings and three functions that build a ChatResponse-shaped dict.

Why this exists:
    - These are PRESENTATION decisions -- what a user sees when something breaks -- which is
      why they live in the api layer and not in services/. The services raise a domain
      error; this module decides that a failed turn should look like a normal assistant
      bubble rather than a raw HTTP 500.

Security and production notes:
    1. Every message here is author-written. No exception text, agent output or SQL error
       is ever interpolated into one, so nothing internal reaches the browser.
    2. Whether the user is asked to RETRY is the important decision in this file. Asking
       for a retry when a ticket already exists is what produced duplicate ServiceNow
       incidents -- see ESCALATED_MESSAGE.
"""

# ============================================ Imports =============================================
from app.core.constants import DONE  # The stage all three report; the FE's "new chat" cue           # constants

# ========================================== Fixed lines ===========================================
FALLBACK_MESSAGE = (  # Generic failure: nothing was created, so a retry is genuinely right          # fallback
    "Sorry, something went wrong on our side and I couldn't process that just now. "
    "Please try again in a moment."
)

# Used when a ServiceNow ticket was ALREADY raised before the turn failed. Telling that
# user to "try again" is what produced duplicate tickets: they would start over and a
# second incident would be opened for the same problem. Handing them the number and
# saying they need not start again removes the reason to retry.
ESCALATED_MESSAGE = (  # Deliberately does NOT ask for a retry                                       # escalated
    "Something went wrong on our side before I could finish. Your ticket {incident} has "
    "already been raised and the support team will follow up -- you can track it in "
    "ServiceNow. You don't need to start again."
)


# ======================================== Failure payloads ========================================
def fallback_chat_response(
    user_id, session_id=None, conversation_id=None, *, stage=DONE, done: bool = True
) -> dict:
    """Safe chat payload returned when a turn fails unexpectedly.

    What this function does:
        - Builds a ChatResponse-shaped dict carrying FALLBACK_MESSAGE, with error=True and
          whatever stage/done the caller passes.

    Why it exists:
        - The defaults describe a FIRST turn that failed (POST /chat): nothing was saved, so
          there is no conversation to continue and the FE must start fresh.
        - /chat/continue passes the real stage with done=False, because there a failure
          leaves the conversation untouched and the user can just resend the same message.
          Claiming DONE there used to throw away a working conversation -- and produce a
          duplicate ServiceNow incident when the user started over.
        - Shaped like a normal /chat response so the frontend renders it as an assistant
          bubble (with error=True) instead of choking on a raw HTTP 500. Client errors
          (404/409/422) are still raised normally so the FE can handle them.

    Security and production notes:
        1. stage is DONE, not a made-up "ERROR". Two reasons:
             * it agrees with done=True. A turn that failed left NOTHING saved -- no
               conversation row, and session_id is None -- so there is genuinely nothing to
               continue. DONE is the frontend's existing signal for "start a new chat",
               which is exactly the right recovery.
             * "ERROR" was not a real stage: absent from core/constants.py, impossible for
               the flow to produce, and unhandled by it. A frontend keying on
               stage == "DONE" would have missed it and shown a dead conversation with no
               way forward.
        2. error=True is what distinguishes "failed" from "completed normally", so the FE
           shows the error wording rather than a normal ending. The FE should branch on
           done/error -- never on the stage string, which is internal flow state.

    Args:
        user_id: The caller's id, echoed back.
        session_id: The session if one exists; None on a failed first turn.
        conversation_id: The conversation if one exists; None on a failed first turn.
        stage: The stage to report. /chat/continue passes the REAL stage.
        done: False from /chat/continue, so the FE keeps the conversation.

    Returns:
        A ChatResponse-shaped dict with error=True.

    Example:
        >>> fallback_chat_response("u1")["done"]
        True
    """
    return {
        "user_id": user_id,  # Echoed so the FE can key its state                                    # user id
        "session_id": session_id,  # None on a failed first turn: nothing was saved                  # session id
        "conversation_id": conversation_id,  # None when no conversation exists                      # conv id
        "stage": stage,  # DONE by default; the real stage on the continue path                      # stage
        "done": done,  # True -> the FE resets; False -> it keeps the conversation                   # done flag
        "error": True,  # Style it as an error, not a normal ending                                  # error flag
        "messages": [FALLBACK_MESSAGE],  # Author-written; no internal detail                        # bubble
        "answer": FALLBACK_MESSAGE,  # Same content as one string                                    # answer
    }


def escalated_chat_response(user_id, incident_id) -> dict:
    """Failure payload for when a ticket already exists.

    What this function does:
        - Builds the same shape as fallback_chat_response, but with ESCALATED_MESSAGE and
          the real incident number interpolated in.

    Why it exists:
        - Same shape as any other chat response, so the FE renders it as an assistant
          bubble. done=True because a failed first turn saved nothing -- there is no
          conversation to continue -- but the message deliberately does NOT ask the user to
          retry, because the work is already in ServiceNow's hands.

    Security and production notes:
        1. The only interpolated value is the incident number, which is a ServiceNow
           identifier the user is entitled to see -- never an exception message.
        2. error stays True: something did go wrong, and the FE should style it as such.

    Args:
        user_id: The caller's id, echoed back.
        incident_id: The ServiceNow incident number that already exists.

    Returns:
        A ChatResponse-shaped dict with error=True and no retry request.

    Example:
        >>> escalated_chat_response("u1", "INC001")["error"]
        True
    """
    message = ESCALATED_MESSAGE.format(incident=incident_id)  # Only the number is injected          # build line
    return {
        "user_id": user_id,  # Echoed so the FE can key its state                                    # user id
        "session_id": None,  # A failed first turn saved nothing                                     # session id
        "conversation_id": None,  # A failed first turn saved nothing                                # conv id
        "stage": DONE,  # The FE's existing "start a new chat" signal                                # stage
        "done": True,  # There is genuinely nothing to continue                                      # done flag
        "error": True,  # Something did go wrong; style it as such                                   # error flag
        "messages": [message],  # Carries the real ticket number, and no retry ask                   # bubble
        "answer": message,  # Same content as one string                                             # answer
    }


# ========================================= Ended payload ==========================================
def ended_chat_response(user_id, session_id, message: str) -> dict:
    """Payload for a conversation that has already finished.

    What this function does:
        - Builds the same shape with error=False, carrying the domain error's own text.

    Why it exists:
        - Deliberately NOT an error and NOT a 409. The conversation completed normally --
          there is simply nothing left to continue -- so error=False and the message is the
          domain error's own text, which is author-written and safe to display.
        - Why a 200 rather than the 409 this used to be: the frontend needs done=True to
          reset itself and start a new chat. A 409 carries only {"detail": ...} -- no stage,
          no done flag, no messages -- so the FE would need a separate branch to recover,
          and an unhandled one leaves the user at a dead end. One response shape keeps the
          FE's rendering path single.

    Security and production notes:
        1. `message` is ConversationEnded's own text, which is author-written (see
           core/errors.py). That is the ONLY reason it is safe to pass straight through.

    Args:
        user_id: The caller's id, echoed back.
        session_id: The session that has finished.
        message: The domain error's author-written text.

    Returns:
        A ChatResponse-shaped dict with done=True and error=False.

    Example:
        >>> ended_chat_response("u1", "s1", "This conversation has ended.")["error"]
        False
    """
    return {
        "user_id": user_id,  # Echoed so the FE can key its state                                    # user id
        "session_id": session_id,  # The session that just finished                                  # session id
        "conversation_id": None,  # Nothing left to continue                                         # conv id
        "stage": DONE,  # The FE's existing "start a new chat" signal                                # stage
        "done": True,  # Reset and open a fresh chat                                                 # done flag
        "error": False,  # This is a NORMAL ending, not a failure                                    # error flag
        "messages": [message],  # The domain error's own author-written text                         # bubble
        "answer": message,  # Same content as one string                                             # answer
    }
