﻿"""The troubleshoot agent: fix it on the user's machine.

The same ASYNC two-operation contract as the diagnostics agent -- start() triggers and
returns, status() reports -- but reached by two different routes, which is why start()
takes more than one set of arguments:

    after diagnostics   the user answered "yes, proceed", so we have the kb_id and the
                        summary and the script is whatever this agent decides fits
    straight from       the second classification agent already collected the inputs a
    classification      known script needs, so script_name and script_params arrive
                        filled in and no diagnosis step happened at all

CONTRACT (was: POST /start and GET /status on the troubleshoot Function App)
    start(...)  -> job_id      triggers the run and RETURNS IMMEDIATELY
    status(job_id) -> dict     how is that run going

START MUST NOT WAIT: it triggers, hands back an id, and is done. The frontend polls and
the reaper sweep finishes off jobs whose user closed the tab. An implementation that
waited would hold a worker for the length of a device repair.

The job_id is yours -- the orchestrator stores it and hands it back to status(), never
parses it. status() may return raw run-state fields or {"state": ...}; app/domain/run_state.py
collapses either into {state, message, output} and decides what the user may see. And
never fabricate a result: raise instead. Telling someone their machine was repaired when
nothing ran is the one failure this app is built to avoid.

NOTE ON WHAT RUNS THE SCRIPT. Until this agent has a mechanism of its own, both device
agents pointed at the same service. Whether troubleshooting ends up on Intune
proactive remediation like diagnostics, or on Arc Run Command (see
script-automation/arc_runner.py in the wider repo), is this agent's business and changes
nothing above these two methods -- which is the point of the seam.
"""
from app.agents.base import Agent


class TroubleshootAgent(Agent):
    """Starts a remediation run on a device and reports how it is going."""

    label = "troubleshoot"

    def start(
        self, conversation_id: str, *, device_id: str, kb_id=None, summary: str = "",
        script_name: str = "", script_params: dict = None,
    ) -> str:
        """Trigger a remediation run and return its job_id. Does NOT wait for it.

        device_id      which machine to work on -- always supplied by the orchestrator
        kb_id          the article the classification agents settled on
        summary        what the user described (the post-diagnostics route)
        script_name    the script the second classification agent named (the U3 route)
        script_params  the inputs it collected from the user for that script

        Both routes are legitimate; between kb_id/summary and script_name/script_params
        you will always have one pair filled in.
        """
        return self._call(
            action="start",
            conversation_id=conversation_id,
            device_id=device_id,
            kb_id=kb_id,
            summary=summary,
            script_name=script_name,
            script_params=script_params or {},
        )

    def status(self, job_id: str) -> dict:
        """Report on a run started by this agent. Polled every ~30s until terminal."""
        return self._call(action="status", job_id=job_id)
