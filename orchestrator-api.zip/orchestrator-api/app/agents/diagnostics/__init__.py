"""The diagnostics agent. See main.py -- DiagnosticsAgent."""
