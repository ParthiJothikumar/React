﻿"""The diagnostics agent: find out what is actually wrong with the user's machine.

An ASYNC agent, and the reason the flow has RUNNING stages at all. A real run means a
script executing on the user's device and reporting back, which takes 3-15 minutes, so
this agent has two operations rather than one:

CONTRACT (was: POST /start and GET /status on the diagnostics Function App)
    start(...)  -> job_id      triggers the run and RETURNS IMMEDIATELY
    status(job_id) -> dict     how is that run going

    start   was {"conversation_id", "input": "<a JSON string of kb_id/summary/device_id>"}
            and is now those values as arguments -- no JSON string to build or parse.
    status  was GET ?job_id=... and is now the same value as an argument.

START MUST NOT WAIT. Whatever runs the script may block for minutes; this method may not.
It triggers, hands back an id, and is done. The orchestrator stores that id, the frontend
polls, and the reaper sweep finishes off jobs whose user closed the tab -- see
app/domain/jobs.py and app/workers/reaper.py. An implementation that waited would hold a
worker (and a user's request) for the length of a device repair.

THE job_id IS YOURS. The orchestrator only stores it and hands it back to status(); it
never parses it. Make it whatever identifies a run to you -- the previous implementation
used "<script_id>:<device_id>", which is also the id of the Intune run-state record, so
nothing had to be kept between the two calls.

WHAT status() SHOULD RETURN. Either shape works:
    * the RAW device/run-state fields (detectionState, remediationState,
      lastStateUpdateDateTime, pre/postRemediationDetectionScriptOutput, ...), or
    * {"state": "running"|"done"|"failed", "userMessage": ..., "result": ...}
app/domain/run_state.py collapses both into {state, message, output} and decides what a user may see.
That interpretation deliberately stays with the caller: `message` is shown to the user and
written to the transcript, `output` is raw device text kept for support only, and the
scripts belong to another team and can change without our code changing -- so their output
cannot be treated as display text.

NEVER FABRICATE A RESULT. There is no simulation mode here and no fallback when something
is unconfigured: raise instead. A previous version faked "No issues found; Outlook profile
repaired" whenever a setting was missing, which told real users their machine was fixed
while nothing had run -- and resolved their ServiceNow incident when they confirmed. A
visible failure is always better than a silent lie.
"""
from app.agents.base import Agent


class DiagnosticsAgent(Agent):
    """Starts a diagnostic run on a device and reports how it is going."""

    label = "diagnostics"

    def start(
        self, conversation_id: str, *, device_id: str, kb_id, summary: str = ""
    ) -> str:
        """Trigger a diagnostic run and return its job_id. Does NOT wait for it.

        device_id  which machine to work on. The orchestrator always sends one, because
                   guessing the machine is the worst failure available here.
        kb_id      the article the classification agents settled on
        summary    what the user described, for agents that need more than the kb_id
        """
        return self._call(
            action="start",
            conversation_id=conversation_id,
            device_id=device_id,
            kb_id=kb_id,
            summary=summary,
        )
    

    def status(self, job_id: str) -> dict:
        """Report on a run started by this agent. Polled every ~30s until terminal."""
        return self._call(action="status", job_id=job_id)
