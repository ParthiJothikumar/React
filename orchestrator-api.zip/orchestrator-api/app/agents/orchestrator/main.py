####################################################################################################
# Project name      : IT Support Orchestrator API -- Azure App Service (FastAPI)                   #
# Business owner    : <fill: business owner / team>                                                #
# Notebook Author   : <fill: author name / team>                                                   #
# Date              : <fill: date>                                                                 #
#                                                                                                  #
# Purpose of file:                                                                                 #
# The ORCHESTRATOR agent: decide what KIND of message the user just sent.                          #
#   1. classify(): the contract the flow calls -- conversation_id + message -> issue_type.         #
#   2. _respond(): the ONE outbound Foundry call; hands back the agent's JSON object.              #
#   3. _json_object(): decode that object ONCE, from whichever accessor the SDK populated.         #
#   4. Fail LOUDLY: no agent configured, a failed call and a non-JSON reply all raise.             #
#                                                                                                  #
# Source:-                                                                                         #
#   - app.agents.base.Agent supplies the injected collaborators (settings, foundry, timeout,       #
#       trace, logger) and traced(), which records this call's agent_calls row.                    #
#   - app.clients.foundry.FoundryClient arrives as self._foundry: the process-wide, lazily         #
#       built OpenAI-compatible client the Responses API is called on.                             #
#   - json decodes the schema's object when the SDK hands it over as a document, not a dict.       #
#   - app.core.errors.UpstreamUnavailable is what every failure in this module becomes.            #
#   - os.environ supplies ORCHESTRATOR_AGENT_NAME -- this agent's own configuration.               #
####################################################################################################
"""The orchestrator agent -- what KIND of message is this?

What this module is:
    - OrchestratorAgent. classify(conversation_id, message) returns
      {"issue_type": "greeting" | "non_it" | "non_outlook_it" | "outlook_it"}.

Why this exists:
    - It is the first agent every conversation reaches, and the only one that decides
      whether a message is support work at all. Its answer routes the whole turn -- a
      greeting gets a re-prompt, a non-Outlook IT problem gets a ticket and a handover, an
      Outlook problem enters classification -- so it returns one label and nothing else.

    - CONTRACT (was: POST to the orchestrator Function App)

          request   conversation_id, message   <- the old {"conversation_id", "message"} body
          response  {"issue_type": "greeting" | "non_it" | "non_outlook_it" | "outlook_it"}

      `message` is in ENGLISH: the flow translates the user's text before calling, so this
      agent (and every other) sees one language whatever the user typed.

    - HOW IT IS IMPLEMENTED: one call to the Azure AI Foundry Responses API, against the
      agent named by ORCHESTRATOR_AGENT_NAME, bound to the user's Foundry conversation:

          responses.create(input=message, conversation=<conversation_id>,
                           extra_body={"agent": {"type": "agent_reference", "name": ...}})

    - THE AGENT ANSWERS WITH A JSON OBJECT, NOT WITH TEXT. It is configured in the portal
      with a JSON schema (structured output) whose category property is an ENUM of exactly
      the four labels in app/core/constants.py -- ISSUE_GREETING ("greeting"), ISSUE_NON_IT
      ("non_it"), ISSUE_NON_OUTLOOK_IT ("non_outlook_it") and ISSUE_OUTLOOK_IT
      ("outlook_it").

      So there is NO parsing and no text handling in this module. _json_object() turns the
      reply into a dict exactly once -- taking the SDK's already-decoded object where there
      is one, and decoding the document it was serialised into where there is not -- and
      _call() then reads one property off that dict. Nothing above _json_object() ever sees
      a string, which is the point: a reply that is not a JSON object is a misconfigured
      agent, not something to interpret.

    - THE CLASSIFICATION PROMPT IS NOT HERE. It lives on the agent in the Foundry portal,
      where the team that owns the wording and the schema can change them without a deploy
      -- this module sends the message and reads the category back out.

    - WHY THE CALL IS BOUND TO `conversation`. The turn is persisted server-side, so a user
      whose second message is just "outlook" is understood as answering our re-prompt
      rather than as another non-issue. That is the whole reason classify() takes a
      conversation_id it never otherwise looks at.

    - WHERE THE CONFIGURATION LIVES. Which Foundry agent this class talks to is read HERE,
      not in core/config.py -- that is the point of the folder-per-agent seam (see
      agents/__init__.py). The name may also be passed to the constructor, so a test never
      touches the environment.

Security and production notes:
    1. The category is handed on EXACTLY as the schema emitted it: not normalised, and not
       re-checked against constants.VALID_ISSUE_TYPES. The enum is the guarantee, and the
       drift guard is the FLOW's (domain/flow.py logs an unexpected value and fails closed
       to non_it) -- re-checking it here would hide a discoverable warning behind a 502.
    2. RAISING IS CORRECT HERE -- there is no safe default for "we don't know what this
       message is", because the two branches downstream open a ServiceNow ticket. Every
       failure becomes UpstreamUnavailable and the caller turns it into the user-facing
       fallback bubble.
    3. The reply is never shown to the user by this module and never logged verbatim: it
       can quote the user's own words, and these lines can be forwarded off-tenant. Only
       the SDK exception TYPE and the object's PROPERTY NAMES are logged -- names, never
       values.

Example:
    >>> OrchestratorAgent(agent_name="orchestrator").classify("conv_1", "outlook won't open")  # doctest: +SKIP
    {'issue_type': 'outlook_it'}
"""

# ============================================ Imports =============================================
import json  # Decode the schema's object when the SDK hands over a document                        # stdlib json
import os  # ORCHESTRATOR_AGENT_NAME: this agent's own configuration                                # stdlib os

from app.agents.base import Agent  # Injected collaborators, traced(), the _call hook               # base
from app.core.config import logger  # Shared logger; the only place a failure is described          # config
from app.core.errors import UpstreamUnavailable  # What every failure here becomes (-> 502)         # errors

# ========================================= Configuration ==========================================
# The environment variable / App Service Application Setting naming the Foundry agent this
# class calls. Deliberately NOT on the Settings class: nothing above agents/ names an
# individual agent, so an agent's own backend is configured in its own folder -- see the
# "-- agents --" note in .env.example and the module docstring above.
AGENT_NAME_SETTING = "ORCHESTRATOR_AGENT_NAME"  # Read once per request in __init__                 # setting name

# The property the agent's JSON schema carries the category in. Rename the property in the
# Foundry portal and this is the single line that has to follow it.
#
# It is spelled the same as the field the FLOW reads (domain/flow.py:
# response.get("issue_type")), but the two are not the same thing: this one is the schema's
# name and can change with the schema, while "issue_type" in the returned dict is the
# CONTRACT and cannot -- which is why _call below writes that key as a literal.
ISSUE_TYPE_FIELD = "issue_type"  # The schema's category property                                   # json field


# ======================================= Orchestrator agent =======================================
class OrchestratorAgent(Agent):
    """Classifies one user message into an issue type.

    What this class is:
        - One public method, classify(), over one outbound Foundry call whose JSON answer
          is decoded once and read for a single property.

    Why it exists:
        - So "is this support work at all?" is answered in one place, by the team that owns
          the classification prompt and its schema, and the flow only has to read one field.

    Security and production notes:
        1. Built PER REQUEST in deps.py, because it holds that request's CallTrace -- so
           the only state worth caching here is the agent name, resolved in __init__.
        2. It holds no conversation state: the history lives on the Foundry conversation,
           so two workers serving alternate turns of the same chat behave identically.

    Example:
        >>> OrchestratorAgent(agent_name="orchestrator").label
        'orchestrator'
    """

    label = "orchestrator"  # Written to agent_calls.agent and used in every log line               # trace label

    # Set once per WORKER PROCESS the first time we find no agent name configured. A class
    # attribute on purpose: the agents are rebuilt per request, so a per-instance flag would
    # repeat the same warning on every turn of every conversation.
    _warned_unconfigured = False  # One warning per worker, not one per turn                        # warn once

    def __init__(self, *, agent_name: str = "", **kwargs) -> None:
        """Adopt the base collaborators and resolve which Foundry agent to call.

        What this method does:
            - Passes every injected collaborator up to Agent, then records the Foundry agent
              name: the constructor argument if given, otherwise ORCHESTRATOR_AGENT_NAME.

        Why it exists:
            - `agent_name` wins when given, so a test can construct this with a name and no
              environment at all. Resolving it ONCE here rather than per call means the value
              is fixed for the life of the request, and an App Setting edited mid-flight
              cannot change which agent answers turn two of a live conversation.

        Security and production notes:
            1. A MISSING name is not an error here. Construction happens per request in
               deps.py, and the app must still boot and serve /health with an empty
               configuration -- so the failure is raised at the CALL, where it is one
               conversation's problem rather than the whole worker's.

        Args:
            agent_name: The Foundry agent to call; falls back to the environment.
            **kwargs: The base collaborators (settings, foundry, timeout, trace, log_factory).

        Returns:
            None.

        Example:
            >>> OrchestratorAgent(agent_name=" orchestrator ")._agent_name
            'orchestrator'
        """
        super().__init__(**kwargs)  # settings, foundry, timeout, trace, logger                     # base init
        # The constructor argument wins; the environment is the fallback. Stripped, because
        # an App Setting pasted with a trailing space would otherwise be a 404 from Foundry.
        self._agent_name = (agent_name or os.getenv(AGENT_NAME_SETTING, "")).strip()                # agent name

    # ====================================== Public contract =======================================
    def classify(self, conversation_id: str, message: str) -> dict:
        """Classify the user's message. Returns the agent's response dict.

        What this method does:
            - Hands the two contract fields to _call and returns what it produced.

        Why it exists:
            - THIS IS THE CONTRACT the flow calls, and it is deliberately the whole of it:
              one method, two arguments, one field back. conversation_id is the Foundry
              conversation -- the greeting loop needs it, because a user whose second message
              is just "outlook" is answering our re-prompt, and without that history it reads
              as another non-issue.
            - It stays a thin wrapper around _call (rather than being _call) because that is
              the shape every agent in agents/ has: the public method holds the error POLICY
              the flow depends on, and _call holds the implementation. This agent's policy is
              "raise" -- see note 2 in the module docstring.

        Args:
            conversation_id: The Foundry conversation id, also our correlation id.
            message: The user's message, already translated to the working language.

        Returns:
            {"issue_type": "greeting" | "non_it" | "non_outlook_it" | "outlook_it"}.

        Raises:
            UpstreamUnavailable: No agent configured, the call failed, or the JSON carried
                no category.

        Example:
            >>> flow_orchestrator.classify("conv_1", "hi")  # doctest: +SKIP
            {'issue_type': 'greeting'}
        """
        return self._call(conversation_id=conversation_id, message=message)                         # one call

    # ======================================= Implementation =======================================
    def _call(self, *, conversation_id: str, message: str) -> dict:
        """Ask the Foundry agent for one category and read it off its JSON answer.

        What this method does:
            - Makes the outbound call, reads ISSUE_TYPE_FIELD off the object that comes
              back, and returns the single-field dict the contract promises.

        Why it exists:
            - KEYWORD-ONLY, and with no **kwargs, so a caller that sends a field this agent
              does not accept is a TypeError at the call site. That is exactly what the HTTP
              body used to hide, as a key the far end silently ignored.
            - There is no parsing in here because there is nothing to parse: _respond hands
              back a dict, and reading a category is `payload.get(...)`.

        Security and production notes:
            1. The value is passed on VERBATIM -- see note 1 in the module docstring. The
               flow owns the drift guard, so an unexpected enum value is logged there with
               the value itself rather than becoming a silent 502 here.
            2. The failure line logs the object's PROPERTY NAMES, never its values: a value
               can quote the user's own words. Names are what identify the fault anyway --
               a renamed schema property shows up as `keys=['category']`.

        Args:
            conversation_id: The Foundry conversation id, also our correlation id.
            message: The user's message, already in the working language.

        Returns:
            {"issue_type": <the category exactly as the schema emitted it>}.

        Raises:
            UpstreamUnavailable: No agent configured, the call failed, the reply was not a
                JSON object, or that object carried no category.

        Example:
            >>> agent._call(conversation_id="conv_1", message="hi")  # doctest: +SKIP
            {'issue_type': 'greeting'}
        """
        payload = self._respond(conversation_id, message)  # The agent's JSON object                # call agent
        issue_type = payload.get(ISSUE_TYPE_FIELD)  # One property; nothing is parsed               # read field
        if not isinstance(issue_type, str) or not issue_type:  # Absent, null or ""                 # got one?
            logger.error(  # Property NAMES only -- a value can quote the user                      # log error
                "orchestrator agent returned JSON with no usable %s conv_id=%s keys=%s",
                ISSUE_TYPE_FIELD, conversation_id, sorted(payload),
            )
            raise UpstreamUnavailable("orchestrator agent returned no issue_type")                  # raise 502
        # "issue_type" is written as a LITERAL, not as ISSUE_TYPE_FIELD: the key on the way
        # out is the contract the flow reads, so it must not move if the schema's property
        # is renamed in the portal. The two are spelled the same today and mean different
        # things -- see the note on ISSUE_TYPE_FIELD above.
        return {"issue_type": issue_type}  # Verbatim: the flow owns the drift guard                # return label

    def _respond(self, conversation_id: str, message: str) -> dict:
        """Make the ONE outbound Foundry call and hand back its JSON object.

        What this method does:
            - Refuses early when there is nothing to call, then runs responses.create()
              inside traced(), converts any SDK failure into UpstreamUnavailable, and
              returns the reply decoded by _json_object().

        Why it exists:
            - Only the CALL and the decode are inside traced(), so the agent_calls row
              measures the agent rather than our own work (see agents/base.py). The row is
              written whether the call returns or raises, so a failure is recorded with its
              error rather than vanishing -- and because the DECODE is inside the block, a
              reply that ignored the schema is recorded as a failed call too, which is
              exactly what you want to see in the table.

        Security and production notes:
            1. An unconfigured agent fails with the SETTING NAME rather than with whatever
               the SDK says about an empty agent reference -- the difference between a
               five-minute fix and an afternoon.
            2. `timeout` is passed per call, from Settings.AGENT_HTTP_TIMEOUT. The shared
               client's own timeout bounds conversations.create(), which is sub-second; an
               agent call is not, so it must carry its own -- see the note on
               FOUNDRY_HTTP_TIMEOUT in core/config.py.
            3. The SDK exception TYPE and message go to the log and, via __cause__, into
               agent_calls.error_text. The user only ever sees the flow's fallback bubble.

        Args:
            conversation_id: The Foundry conversation the turn is recorded against.
            message: The user's message, sent as the agent's input verbatim.

        Returns:
            The schema's object, as a dict.

        Raises:
            UpstreamUnavailable: No agent name, no Foundry client, the call failed, or the
                reply was not a JSON object.

        Example:
            >>> agent._respond("conv_1", "hi")  # doctest: +SKIP
            {'issue_type': 'greeting'}
        """
        if not self._agent_name:  # Nothing to call -- fail with the REASON, not an SDK error       # configured?
            if not type(self)._warned_unconfigured:  # Once per worker, not once per turn           # warned?
                type(self)._warned_unconfigured = True  # Class-level: see the attribute            # mark warned
                logger.warning(  # Name the setting, so the fix is the log line itself              # log warn
                    "%s is not set: the orchestrator agent cannot classify anything, so "
                    "every chat turn will fail with the fallback message",
                    AGENT_NAME_SETTING,
                )
            raise UpstreamUnavailable(f"{AGENT_NAME_SETTING} is not configured")                    # raise 502
        if self._foundry is None:  # Only reachable if something built us without deps.py           # have client?
            raise UpstreamUnavailable("orchestrator agent has no Foundry client")                   # raise 502

        with self.traced({"conversation_id": conversation_id, "message": message}) as call:
            try:  # The one outbound call; the row is written either way                            # call try
                response = self._foundry.openai.responses.create(  # Responses API                  # ask agent
                    input=message,  # Already English: the flow translates before calling           # the input
                    conversation=conversation_id,  # Server-side history: the greeting loop         # history
                    extra_body={  # Which Foundry agent answers this turn                           # which agent
                        "agent": {
                            "type": "agent_reference",  # Refer to a PUBLISHED agent by name        # by name
                            "name": self._agent_name,  # From the environment, see __init__         # agent name
                        }
                    },
                    # Per-call ceiling from Settings.AGENT_HTTP_TIMEOUT. The shared client's
                    # own timeout bounds conversations.create(), which is sub-second; an
                    # agent call is not, so it must pass its own -- see core/config.py.
                    timeout=self._timeout,  # This agent's budget for ONE call                      # timeout
                )
            except Exception as exc:  # Timeout, auth, 429, or a failed lazy client build           # call failed
                logger.error(  # Name the SDK type; the generic 502 body will not                   # log error
                    "orchestrator agent call failed conv_id=%s (%s): %s",
                    conversation_id, type(exc).__name__, exc,
                )
                raise UpstreamUnavailable("orchestrator agent call failed") from exc                # raise 502
            payload = _json_object(response)  # The schema's object, decoded ONCE                   # read json
            call.response = payload  # Stored on the row; capped by tracing._field                  # trace it
        return payload  # A dict: nothing above this line handles a string                          # return json


# ======================================== Internal helpers ========================================
def _json_object(response) -> dict:
    """The agent's JSON object, however the SDK handed it over.

    What this function does:
        - Returns response.output_parsed when the SDK already decoded the schema's object;
          otherwise decodes response.output_text, which is that same object serialised.

    Why it exists:
        - This is the ONE place the reply becomes a dict, which is what keeps the rest of
          the module free of text handling. Both accessors are read because which one is
          populated depends on how the call was made -- the SDK's parse() helper decodes
          for you and fills output_parsed, while create() carries the document in
          output_text -- and neither choice should reach _call.

    Security and production notes:
        1. A reply that is not a JSON OBJECT means the schema was not applied to this call:
           the agent's structured output is off in the portal, or ORCHESTRATOR_AGENT_NAME
           points at the wrong agent. It RAISES -- it is never mined for a category,
           because one guessed out of prose opens a ticket in the wrong queue or drops a
           real Outlook issue into the re-prompt loop.
        2. The undecodable text is NOT logged: it can quote the user's own words, and these
           lines can be forwarded off-tenant. json's ValueError is kept on __cause__ (and
           so reaches agent_calls.error_text), and it names the position it failed at,
           which is what a diagnosis actually needs.

    Args:
        response: The SDK's Responses API result.

    Returns:
        The schema's object, as a dict.

    Raises:
        UpstreamUnavailable: The reply was not a JSON object.

    Example:
        >>> _json_object(type("R", (), {"output_text": '{"issue_type": "greeting"}'})())
        {'issue_type': 'greeting'}
    """
    parsed = getattr(response, "output_parsed", None)  # Already a dict, if the SDK did it          # decoded?
    if isinstance(parsed, dict):  # Structured output the SDK unpacked for us                       # got a dict?
        return parsed  # Nothing to decode: use it as it stands                                     # use it
    try:  # Otherwise output_text IS the JSON document the schema produced                          # decode try
        payload = json.loads(getattr(response, "output_text", "") or "")                            # decode
    except ValueError as exc:  # Not JSON at all -> the schema was not applied                      # bad json
        raise UpstreamUnavailable("orchestrator agent did not return JSON") from exc                # raise 502
    if not isinstance(payload, dict):  # A string, a list, a number: not this schema                # an object?
        raise UpstreamUnavailable("orchestrator agent did not return a JSON object")                # raise 502
    return payload  # The schema's object; _call reads one property off it                          # return json
