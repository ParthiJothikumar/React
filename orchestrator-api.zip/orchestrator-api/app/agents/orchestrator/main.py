"""The orchestrator agent: what KIND of message is this?

The first agent every conversation reaches, and the only one that decides whether a
message is support work at all. Its answer routes the whole turn -- a greeting gets a
re-prompt, a non-Outlook IT problem gets a ticket and a handover, an Outlook problem
enters classification -- so it returns one label and nothing else.

CONTRACT (was: POST to the orchestrator Function App)
    request   conversation_id, message      <- the old {"conversation_id", "message"} body
    response  {"issue_type": "greeting" | "non_it" | "non_outlook_it" | "outlook_it"}

`message` is in ENGLISH: the flow translates the user's text before calling, so this
agent (and every other) sees one language whatever the user typed.

The caller validates that label against constants.VALID_ISSUE_TYPES and treats anything
unexpected as non_it, so drift in the agent's wording can never silently create an
incident. That check stays in the flow: this agent reports what it decided, and what to
do about an answer we don't recognise is the flow's policy to set.

Raising is correct here -- there is no safe default for "we don't know what this message
is". The flow's caller turns it into the user-facing fallback bubble.
"""
from app.agents.base import Agent


class OrchestratorAgent(Agent):
    """Classifies one user message into an issue type."""

    label = "orchestrator"

    def classify(self, conversation_id: str, message: str) -> dict:
        """Classify the user's message. Returns the agent's response dict.

        conversation_id is the Foundry conversation: the greeting loop needs it, because
        a user whose second message is just "outlook" is answering our re-prompt, and
        without that history it reads as another non-issue.
        """
        return self._call(conversation_id=conversation_id, message=message)
