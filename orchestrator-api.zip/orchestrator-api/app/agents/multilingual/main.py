﻿"""The multilingual agent: detect the user's language, and translate both ways.

Used on every turn. The flow translates the inbound message into the default language
before anything else runs -- so the yes/no checks AND every other agent see one language
whatever the user typed -- and translates the outgoing lines back just before they reach
the frontend. The stored transcript keeps the ORIGINAL text the user wrote.

CONTRACT (was: POST to the multilingual Function App)
    detect     agent="detect", message=<text>
               -> {"code": "fr", "supported": true}
    translate  agent="translate", lang=<ISO target>, message=<text>
               -> {"reply": "<text in the target language>"}

STATELESS -- no conversation_id. This agent creates its own context per call and must
never touch the user's Foundry conversation: dropping translation turns into the
conversation the other agents read would corrupt their history.

EVERY METHOD DEGRADES, NEVER RAISES. A translation outage must not break a conversation,
so a failure returns the original text (or the previous language) and the turn carries on
in whatever language it already had. That policy is why these methods wrap _call instead
of being it -- it is the promise app/domain/flow.py is built on.

BEFORE THIS AGENT IS IMPLEMENTED, that same policy means the app runs English-only rather
than failing: the first NotImplementedError is logged once per worker and translation is
then skipped. This mirrors what an unset MULTILINGUAL_AGENT_URL used to do.
"""
from app.agents.base import Agent
from app.core.config import logger


class MultilingualAgent(Agent):
    """Detects the user's language and translates messages in both directions."""

    label = "multilingual"

    # Set once per WORKER PROCESS, not per request, the first time _call reports it is
    # not implemented. A class attribute on purpose: the agents are rebuilt per request,
    # so a per-instance flag would log the same line on every turn of every conversation.
    _unavailable = False

    def __init__(self, *, default_lang: str = "en", **kwargs):
        super().__init__(**kwargs)
        # The language the flow works in internally. Outgoing messages are NOT translated
        # when the detected language equals this one.
        self._default_lang = default_lang

    @property
    def enabled(self) -> bool:
        """False once we know translation isn't available -- every method then no-ops."""
        return not type(self)._unavailable

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------
    def detect(self, text: str, fallback: str = "") -> str:
        """Detect the user's language (ISO code). Called every turn.

        Keeps `fallback` -- the language detected on a previous turn, or the default when
        there is none -- if the text is empty, the language is unsupported, detection is
        low-confidence, or the call fails. So a short reply like "ok" can never flip the
        conversation's language or break the turn.
        """
        fallback_lang = fallback or self._default_lang
        if not text or not text.strip():
            return fallback_lang
        response = self._safe_call(agent="detect", message=text)
        if not response.get("supported"):
            # Unsupported (or nothing came back) -> stay where we were.
            return fallback_lang
        return (response.get("code") or fallback_lang).strip()

    def to_english(self, text: str, lang: str) -> str:
        """Translate an inbound user message into the default language.

        No-op when the text is empty or the user is already writing in the default
        language. Returns the original text on failure, so an outage never blocks the
        conversation -- the flow then reads the user's own words, which for "yes"/"no" is
        usually still right.
        """
        if not text or not text.strip() or not lang or lang == self._default_lang:
            return text
        response = self._safe_call(
            agent="translate", lang=self._default_lang, message=text
        )
        return response.get("reply") or text

    def translate_messages(self, messages: list, lang: str) -> list:
        """Translate each outgoing message into `lang`, right before it goes out.

        Per message, so the frontend can still render each as its own bubble. No-ops when
        `lang` is the default. A per-message failure keeps THAT message's original text
        rather than abandoning the rest, so a partial outage degrades one bubble instead
        of the whole reply.
        """
        if not lang or lang == self._default_lang:
            return messages
        out = []
        for message in messages:
            if not message or not message.strip():
                out.append(message)
                continue
            response = self._safe_call(
                agent="translate", lang=lang, message=message
            )
            out.append(response.get("reply") or message)
        return out

    # -----------------------------------------------------------------------
    # Internals
    # -----------------------------------------------------------------------
    def _safe_call(self, **payload) -> dict:
        """One call, or {} if translation is unavailable. Never raises.

        Returning {} rather than raising is what lets each method above express its own
        fallback (keep the previous language / keep the original text) in one line.
        """
        if not self.enabled:
            return {}
        try:
            return self._call(**payload) or {}
        except NotImplementedError:
            # The agent has not been built yet. Log ONCE per worker and stop calling, so
            # an English-only deployment does not repeat this line on every turn.
            type(self)._unavailable = True
            logger.warning(
                "multilingual agent is not implemented yet; conversations will run in "
                "'%s' with no translation", self._default_lang,
            )
            return {}
        except Exception:
            logger.exception("multilingual %s failed", payload.get("agent"))
            return {}
